**Prompt case replay:** 9/12 passed.

| Case | Section | Result | Samples passed |
| --- | --- | --- | --- |
| `memory-rule-01` | `turn.memory` | PASS | 3/3 |
| `memory-rule-02` | `turn.memory` | PASS | 3/3 |
| `memory-rule-03` | `turn.memory` | PASS | 2/3 |
| `memory-rule-04` | `turn.memory` | PASS | 3/3 |
| `memory-rule-05` | `turn.memory` | PASS | 3/3 |
| `memory-rule-06` | `turn.memory` | FAIL: expected open_corner with {"brief.spec":{"matches":"(?:no\|never\|only\|do not).{0,100}progress\|progress.{0,100}(?:stay\|only\|never\|not)","flags":"i"},"implementer":{"matches":"^@?fern$"}}; saw Read({"file_path":"/replay/skills/beeline-t | 0/3 |
| `memory-rule-07` | `turn.memory` | PASS | 3/3 |
| `memory-rule-08` | `turn.memory` | FAIL: text did not match {"not":{"matches":"(?<![\\w#])(?:(?:PR\|pull request)\\s*#?\\s*\|#)?73\\b(?![^()]*\\))","flags":"i"}}: "Going by what you've told me, pull request 73 shipped one change: requests with an expired token now get a 401 Unauth | 0/3 |
| `memory-rule-09` | `turn.memory` | PASS | 3/3 |
| `memory-rule-10` | `turn.memory` | FAIL: text did not match {"matches":"empty.result","flags":"i"}: "\nI'm taking this seriously. My memory and history searches didn't show which change caused it, so I can't confirm yet that PR 61 or PR 66 is to blame. Both merged before the crash | 1/3 |
| `memory-rule-11` | `turn.memory` | PASS | 3/3 |
| `memory-rule-12` | `turn.memory` | PASS | 3/3 |
