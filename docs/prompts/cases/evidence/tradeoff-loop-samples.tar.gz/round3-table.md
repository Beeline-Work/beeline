
> buzzy@0.0.0 prompt-cases
> node --import tsx scripts/prompt-cases.ts --grade /tmp/jellybean-tradeoff/round3

**Prompt case replay:** 51/52 passed.

| Case | Section | Result | Samples passed |
| --- | --- | --- | --- |
| `android-uses-leased-emulator` | `place` | PASS | 3/3 |
| `authority-refuses-credential-file` | `authority` | PASS | 3/3 |
| `brief-missing-asks-commander` | `turn.brief` | PASS | 3/3 |
| `checkout-names-commit` | `turn.checkout` | PASS | 3/3 |
| `checks-reads-reviewer-wake` | `corner` | PASS | 3/3 |
| `checks-turn-quiet-on-green` | `turn.checks` | PASS | 3/3 |
| `contract-pr-body-sections` | `corner` | PASS | 3/3 |
| `corners-opens-named-corner` | `work` | PASS | 3/3 |
| `corners-orders-exact-address` | `turn.corners` | PASS | 3/3 |
| `dm-choice-not-merge-authority` | `authority` | PASS | 3/3 |
| `dm-place-no-tag` | `place` | PASS | 3/3 |
| `feedback-reports-tool-error` | `work` | PASS | 3/3 |
| `files-reads-attachment` | `tools` | PASS | 3/3 |
| `finish-orders-then-ends` | `talking` | PASS | 3/3 |
| `github-app-only-access` | `tools` | PASS | 3/3 |
| `github-general-repository-guidance` | `place` | PASS | 3/3 |
| `github-personal-api-precedence` | `tools` | PASS | 2/3 |
| `handover-tags-not-new-corner` | `talking` | FAIL: no alternative passed: expected order with {"*":{"contains":"juniper"}}; saw Read({"file_path":"/replay/skills/beeline-corners-and-merging/SKILL.md"}), report({"status":"needs_decision","text":"needs-decision: Dana asked me to hand this cor | 1/3 |
| `identity-introduces-as-agent` | `identity` | PASS | 3/3 |
| `implementer-reviewer-does-not-push` | `corner` | PASS | 3/3 |
| `land-merges-after-pass` | `turn.land` | PASS | 3/3 |
| `machine-host-runs-locally` | `place` | PASS | 3/3 |
| `members-exact-handle` | `turn.members` | PASS | 3/3 |
| `memory-answers-from-note` | `turn.memory` | PASS | 3/3 |
| `memory-cap-explains-exit-137` | `place` | PASS | 2/2 |
| `merge-no-self-review` | `corner` | PASS | 1/1 |
| `objective-is-not-authority` | `turn.objective` | PASS | 1/1 |
| `prepare-runs-first` | `corner` | PASS | 1/1 |
| `proactive-offers-fix` | `work` | PASS | 1/1 |
| `push-checks-remote-branch` | `corner` | PASS | 1/1 |
| `refused-artifact-load-skill` | `tools` | PASS | 1/1 |
| `rename-generated-corner` | `turn.rename` | PASS | 1/1 |
| `reply-silent-on-empty-schedule` | `replying` | PASS | 1/1 |
| `replying-answers-nudged-question` | `replying` | PASS | 1/1 |
| `repo-less-posts-artifact` | `place` | PASS | 1/1 |
| `repo-less-reports-done` | `replying` | PASS | 1/1 |
| `resume-uses-card-answer` | `turn.resume` | PASS | 1/1 |
| `review-findings-not-commits` | `corner` | PASS | 1/1 |
| `reviewer-target-current-head` | `turn.reviewer-target` | PASS | 1/1 |
| `room-place-no-writes` | `place` | PASS | 1/1 |
| `session-in-turn-identity` | `turn.session` | PASS | 1/1 |
| `squire-busy-request-capability` | `tools` | PASS | 1/1 |
| `squire-drive-starts-drive` | `tools` | PASS | 1/1 |
| `squire-long-history-host-recovery` | `tools` | PASS | 1/1 |
| `tagging-no-stray-handle` | `talking` | PASS | 1/1 |
| `task-answers-newest-message` | `turn.task` | PASS | 1/1 |
| `tools-connects-service` | `tools` | PASS | 1/1 |
| `transcript-answers-from-history` | `turn.transcript` | PASS | 1/1 |
| `truth-no-claimed-restart` | `work` | PASS | 1/1 |
| `voice-stays-out-of-commits` | `identity` | PASS | 1/1 |
| `workspace-core-loaded-first` | `turn.workspace-core` | PASS | 1/1 |
| `worktree-knows-branch` | `place` | PASS | 1/1 |
