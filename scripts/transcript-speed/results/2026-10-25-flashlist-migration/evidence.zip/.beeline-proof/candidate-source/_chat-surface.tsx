import { useDesktopParentRoom } from '@/buzz/use-desktop-parent-room';
import { DesktopRoomListToggle } from '@/components/buzz/DesktopRoomListToggle';
import { useDesktopLayout, setDesktopPaneOpen } from '@/buzz/desktop-layout-state';
import { ErrorBanner } from '@/components/buzz/ErrorBanner';
import { MonolithRequestTimeoutError } from '@/auth/monolith-session';
import { CornerActionsSheet } from '@/components/buzz/CornerActionsSheet';
import { RepositoryOnboardingCard } from './RepositoryOnboardingCard';
import { showVoiceJoinError } from '@/buzz/voice-update';
import { useUntaggedMessageHints } from '@/buzz/use-untagged-message-hints';
import { focusComposerSelection } from '@/buzz/composer-selection';
import { HullDialogActions } from '@/components/buzz/HullDialog';
import { useTextDraft } from '@/buzz/use-text-draft';
import { HumanProfile } from '../human-profile';
import BuzzMembers from '../members';
/** Room and corner conversation surface. */
import React, {
  useEffect,
  useLayoutEffect,
  useState,
  useRef,
  useCallback,
  useMemo,
  type MutableRefObject,
} from 'react';
import { Buffer } from 'buffer';
import { transcriptBylineOpeners } from '@/buzz/message-dates';
import {
  View,
  Text,
  Keyboard,
  Pressable,
  ScrollView,
  Share,
  TextInput,
  TouchableOpacity,
  Platform,
  AppState,
  AccessibilityInfo,
  type ViewProps,
  type ViewToken,
} from 'react-native';
import { StyleSheet, useUnistyles } from 'react-native-unistyles';
import { PhoneTranscriptList } from '@/components/buzz/PhoneTranscriptList';
import type { PhoneTranscriptListRef } from '@/components/buzz/PhoneTranscriptList.types';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as Notifications from 'expo-notifications';
import {
  KeyboardAvoidingView,
  useKeyboardState,
  useReanimatedKeyboardAnimation,
} from 'react-native-keyboard-controller';
import Animated, { useAnimatedStyle } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  useFocusEffect,
  useLocalSearchParams,
  useNavigation,
  router,
  type Href,
} from 'expo-router';
import { loadBuzzIdentity, getEffectiveRelayUrl } from '@/auth/buzz-identity-storage';
import { getBuzzRuntimeConfig } from '@/buzz/runtime-config';
import { sharedLiveConnection } from '@/sync/transport/live-connection';
import { readGitHubAccess, updateGitHubAccess, useGitHubAccess, writeGitHubAccess } from '@/buzz/github-access-surface';
import { githubInstallationRedirectUri } from '@/auth/github-auth-session';
import { useGitHubInstallationSession } from '@/auth/github-installation-host';
import { Modal } from '@/modal';
import { leaveRoomWithConfirmation } from '@/buzz/room-leave';
import { BuzzRigTransport } from '@/sync/transport';
import {
  publishViewerConversation,
  removeViewerConversation,
  type ViewerMessage,
} from '@/buzz/viewer-conversation';
import {
  type ChannelRole,
  type RoomRepository,
  type RoomView,
  type GitHubInstallationAccess,
  type MessageReactionEmoji,
  type ChatListItem,
  type SurfaceCacheAddress,
  AGENT_PRESENCE_STALE_MS,
  isWorkspaceView,
} from '@beeline/buzz-client';
import {
  cornerDisplayName,
  cornerShortTitle,
  directMessageTitle,
  roomTitle,
  type AgentComposerCommand,
  type WorkflowRunSummaryView,
  type WorkspaceView,
} from '@beeline/api-contract/phone';
import {
  createRoomMessageProjector,
  conversationIdentityByPubkey,
  displayRoomMessages,
  mergeDisplayPages,
  roomViewTranscriptMessages,
  type ChatDisplayMessage,
  memberAgent,
  workspaceRailItem,
} from '@/buzz/room-view-presentation';
import {
  buildChannelReferenceIndex,
  isUnavailableChannelReferenceError,
  resolveCornerFromList,
  type ChannelReferenceIndex,
  type ChannelReferenceTarget,
} from '@/buzz/channel-reference';
import { pushOpenBuzzChannelId, releaseOpenBuzzChannelId } from '@/buzz/open-room-tracker';
import { dismissPresentedNotificationsForChannel } from '@/push/presented-notifications';
import { afterInteractions } from '@/buzz/defer-interaction';
import { cancelScheduledAnimationFrame, scheduleAnimationFrame } from '@/buzz/host-scheduler';
import {
  activeChannelAtCursor,
  channelSuggestionCandidates,
  filterChannelSuggestions,
  replaceActiveChannel,
  type ChannelSuggestion,
} from '@/buzz/channel-suggestions';
import { planComposerFill, type ComposerMention } from '@/buzz/composer-fill';
import { roomStarterIntro, roomStarterPrompts } from '@/buzz/starter-prompts';
import { agentPairingCommand } from '@/buzz/agent-pairing-command';
import { buildTurnActivity } from '@/buzz/activity-timeline';
import { cornerObjectiveItems } from '@/buzz/corner-context';
import { continuedSpeakerIds, ledgerSpeakerKey } from '@/buzz/ledger-attribution';
import { publishFailurePresentation } from '@/buzz/publish-failure';
import { ledgerStamp } from '@/buzz/relative-time';
import { cornerProposalDecision } from '@/buzz/corner-proposal';
import { CHANGES_LABEL, CORNER_LABEL, ROOM_LABEL } from '@/buzz/vocabulary';
import { buildSpeechLexicon } from '@/buzz/speech-lexicon';
import {
  COMPOSER_ACK_BOUND_MS,
  STEER_RECEIVED_VISIBLE_MS,
  hasComposerAckReceipt,
  selectComposerAckPresentation,
  type ComposerAckPresentation,
} from '@/buzz/room-indicators';
import { formatTerminalTurnOverlay, type TurnVerb } from '@/buzz/turn-clock';
import { TurnBandSlot, TurnSettledLine } from '@/components/buzz/TurnProgressLine';
import { useCornerHeaderItem, useRoomCorners } from '@/buzz/use-room-corners';
import { roomOpenCornerRows } from '@/buzz/room-corner-store';
import { DesktopRoomInspector } from '@/components/DesktopRoomInspector';
import { openExternalUrl } from '@/utils/open-external-url';
import { openAppSignIn } from '@/buzz/app-sign-in';
import { AgentSignInCard } from '@/components/buzz/AgentSignInCard';
import { openArtifactInBrowserOrExplain } from '@/buzz/artifact-link';
import { subscribeDesktopArtifact } from '@/buzz/desktop-artifact-pane';
import { subscribeDesktopComputer } from '@/buzz/desktop-computer-pane';
import { ComputerSessionCard } from '@/components/buzz/ComputerSession';
import { RoomRepositorySubtitle } from '@/components/buzz/RoomRepositorySubtitle';
import { ROOM_SLUG_HINT, roomNameEntry, validRoomSlug } from '@/buzz/room-name';
import {
  desktopComposerKeyAction,
  desktopWorkPaneVisibleContent,
  initialDesktopWorkPaneState,
  desktopDraftKey,
  transitionDesktopWorkPane,
  type DesktopWorkPaneEvent,
  type DesktopWorkPanePrimary,
} from '@/buzz/desktop-workbench-state';
import { useRoomSendFrame } from '@/buzz/room-send-frame';
import { mobileSurfaceCache, surfaceAddress } from '@/buzz/surface-storage';
import { useChatList } from '@/buzz/chat-list-store';
import { useRoomRepoReplacementGuard } from '@/buzz/room-repo-replacement';
import { liveDraftMessages, projectActiveTurnStream } from '@/buzz/live-turn-stream';
import {
  activeMentionAtCursor,
  CHANNEL_MENTION_HANDLE,
  CHANNEL_MENTION_PUBKEY,
  filterMentionCandidates,
  formatRoomParticipantTotal,
  mentionedAgentPubkey,
  orderRoomRoster,
  recordMentionPick,
  replaceActiveMention,
  resolveComposerMentions,
  selectedMentionAgentPubkey,
  shouldReadWorkspaceRoster,
  SYSTEM_MENTION_HANDLE,
  SYSTEM_MENTION_PUBKEY,
} from '@/buzz/room-participants';
import { resolveAgentDisplayIdentity, resolvePendingAgentDisplay } from '@/buzz/agent-display';
import {
  cornerDisplayState,
  cornerHeaderAgent,
  roomIsArchived,
  roomViewParentId,
} from '@/buzz/corner-display-state';
import {
  directMessageHeaderIdentity,
  fallbackMemberHandle,
  fallbackMemberName,
  personIdentityLabel,
} from '@/buzz/member-display';
import {
  directMessageAgentHeaderMeta,
  directMessageHeaderPresence,
} from '@/buzz/direct-message-header-presence';
import {
  createCommunityInviteUrl,
  resolveCommunityInvitePublicOrigin,
} from '@/buzz/community-invite';
import { MemberPickerSheet, type MemberPickerCandidate } from '@/components/buzz/MemberPickerSheet';
import { normalizedRoomRole } from '@/buzz/room-management';
import {
  looksLikeCornerOpenIntent,
  GITHUB_REPOSITORY_SELECTION_INSTRUCTION,
  githubFullNameFromInput,
  githubRepositoryLinkagePlan,
  roomRepoChipLabel,
  type RepoCandidate,
} from '@/buzz/room-repo-picker';
import {
  OwnerGrantNeededCard,
  ownerGrantShareMessage,
  type OwnerGrantNeeded,
} from '@/components/buzz/OwnerGrantNeededCard';
import { StarPromptCard, useStarPrompt } from '@/components/buzz/StarPromptCard';
import { selectWorkingAgents } from '@/buzz/room-indicators';
import {
  roomBottomChromeStyles,
  TURN_LINE_BAR_MARGIN_BOTTOM,
  TURN_LINE_BOX_HEIGHT,
  TURN_LINE_ROW_MIN_HEIGHT,
} from '@/buzz/room-bottom-chrome';
import {
  phoneTranscriptTailPadding,
  roomOpenLandsOnTail,
  shouldFollowDesktopTail,
  useScrollFollowOnArrival,
  useScrollFollowOnLayoutChange,
} from '@/buzz/room-scroll-follow';
import {
  desktopTranscriptList,
  phoneTranscriptList,
  requestMessageJump,
  useTranscriptScrollController,
} from '@/buzz/transcript-scroll-controller';
import {
  loadActiveCommunityId,
  saveActiveCommunityId,
  saveLastViewedChannel,
} from '@/buzz/community-storage';
import {
  createChatAttachmentUploader,
  formatAttachmentSize,
  MAX_MESSAGE_ATTACHMENTS,
  pastedImageAttachment,
  pickedPhotoAttachments,
  type PickedChatAttachment,
} from '@/buzz/chat-attachment';
import {
  availableSlashVerbs,
  availableCornerAppCommands,
  availableAgentMentionCommands,
  fastModeCommandState,
  FAST_MODE_COMMAND,
  slashVerbQuery,
  agentMentionSlashQuery,
  insertAgentSlashCommand,
  type BuiltInSlashVerbId,
  type FastModeCommandState,
} from '@/buzz/slash-verbs';
import {
  cachedChannelKind,
  channelHeaderTitle,
  resolveCornerViewAgentPubkey,
  type ChannelKind,
} from '@/buzz/corner-session';
import {
  messageJumpHref,
  chatBackAction,
  cornerOpenAction,
  cornerHref,
  resolveMentionDirectMessageAction,
  roomCornersHref,
  roomHref,
  type ChatStackRoute,
} from '@/buzz/corner-navigation';
import { isNearChatBottom } from '@/buzz/chat-scroll';
import {
  agentActivityReplyExcerpt,
  beginReplyTarget,
  canBeginReply,
  prepareMessageReply,
  type MessageReplyDisplayTarget,
  type MessageReplyTarget,
} from '@/buzz/message-reply';
import {
  answerPrefillCandidate,
  planAnswerPrefill,
  planReplyPrefill,
  type ComposerPrefill,
  type ComposerPrefillPlan,
} from '@/buzz/composer-prefill';
import { roomComposerTagHandles, splitComposerTags } from '@/buzz/composer-tags';
import {
  composerBottomPadding,
  mentionKeyboardAction,
  transcriptKeyboardDismissMode,
} from '@/buzz/composer-keyboard';
import { copyEntireTurn } from '@/buzz/message-copy';
import { storeTempText } from '@/sync/persistence';
import { useRoomMessageRenderItem } from '@/buzz/room-message-cell';
import type { RoomMessagePresentation, RoomMessageRenderContext } from '@/buzz/room-message-cell';
import { arrivalFlashTiming, landingFlashesArrival } from '@/buzz/room-arrival-flash';
import {
  createTranscriptRowFolder,
  foldTranscriptRows,
  hostRowIndex,
  useRoomMessageStore,
} from '@/buzz/room-message-store';
import { roomMessageRecord, useRoomMessageRecords, writeRoomBookmark } from '@/buzz/room-message-records';
import {
  markRoomOpen,
  useRoomSurfaceSession,
  type RoomSurfaceSessionBindings,
  type UseRoomSurfaceSessionResult,
} from './useRoomSurfaceSession';
import {
  GitHubEventCard,
  NotificationLifecycleCard,
  DaemonFactCard,
  GrantRequestCard,
  SquireApprovalCard,
  ConnectorOfferCard,
  AppSignInCard,
  ChoiceCard,
  WalletCards,
  agentCommandTranscriptMessage,
  OrdinaryLedgerMessage,
  TargetBranchProposalCard,
  WritePermissionCard,
} from './RoomMessageVariants';
import {
  monolithPhoneOperation,
  phoneOperationFailureReason,
} from '@/sync/transport/monolith-operation';
import { isWorkspaceManagerRole } from '@/buzz/workspace-role';
import { useWorkspaceRecords, workspaceRecordScope, workspaceRows } from '@/buzz/workspace-records';
import { promptAndReportMessageIssue, reportIssueToastCopy } from '@/buzz/report-message-issue';
import { useCopiedToast } from '@/components/buzz/CopiedToast';
import {
  formatForwardedMessage,
  forwardMessageToRoom,
  forwardTargets,
  resolveForwardTargetRoom,
  type ForwardTarget,
} from '@/buzz/message-forward';
import { visibleTranscriptWindow } from '@/buzz/transcript-presentation';
import { useArtifactReturn } from '@/buzz/use-artifact-return';
import {
  EMPTY_TRANSCRIPT_ARRIVAL_STATE,
  observeTranscriptArrivals,
} from '@/buzz/transcript-motion';
import {
  boundaryRowIndex,
  countsAsUnread,
  messageBoundaryIds,
  newestTranscriptRowId,
} from '@/buzz/room-new-message-boundary';
import { pinnedTailReadReport } from '@/buzz/read-cursor-advance';
import { useNewMessageControl, useUnreadLineControl } from '@/buzz/use-new-message-control';
import { RoomUnreadControls } from '@/components/buzz/RoomUnreadControls';
import { TranscriptScrubber } from '@/components/buzz/TranscriptScrubber';
import { usePhoneUnderfillHistory } from '@/buzz/phone-underfill-history';
import { createTranscriptCardMotionStore } from '@/components/buzz/transcript-card-motion-context';
import {
  isAgentTurnActive,
  nextAgentPresenceTransitionAt,
  nextAgentTurnExpiryAt,
  activeMentionCandidates,
  AGENT_PRESENCE_BACKGROUND_GRACE_MS,
} from '@/buzz/agent-presence';
import {
  sameElementRefs,
  sameMessageRefMap,
  sameRecordValueMap,
  sameSelectedMembers,
  sameStringSet,
  shallowEqualRecord,
  useStable,
  useScopedCallbacks,
} from '@/buzz/use-stable';
import { BuzzCommunityShell } from '@/components/buzz/CommunityRail';
import { Typography } from '@/constants/Typography';
import { CornerObjectiveLine } from '@/components/buzz/CornerObjectiveLine';
import { useRoomWorkflowRun } from '@/buzz/use-room-workflow-run';
import { workflowRunHref } from '@/buzz/workflow-run-copy';
import { openCornerBriefViewer } from '@/components/buzz/corner-brief-viewer';
import { CornerStatusLine } from '@/components/buzz/CornerStatusLine';
import { TurnProgressLine } from '@/components/buzz/TurnProgressLine';
import { AttachmentPickerSheet } from '@/components/buzz/AttachmentPickerSheet';
import { ForwardMessagePickerSheet } from '@/components/buzz/ForwardMessagePickerSheet';
import { ForwardCornerSheet } from '@/components/buzz/ForwardCornerSheet';
import { CornerOpenedMarkers } from '@/components/buzz/CornerOpenedMarker';
import { MessageReactionStrip } from '@/components/buzz/MessageReactionStrip';
import {
  HULL_SHEET_INSET,
  HullActionSheetCancel,
  HullActionSheetModal,
  HullActionSheetRow,
} from '@/components/buzz/HullActionSheet';
import { useRoomRepositoryChoice } from '@/components/buzz/RoomRepositoryChoice';
import { CHEVRON_BACK_SIZE, ChevronGlyph } from '@/components/buzz/ChevronGlyph';
import { CornerGlyph } from '@/components/buzz/CornerGlyph';
import { OverflowGlyph } from '@/components/buzz/OverflowGlyph';
import {
  RoomReviewerActions,
  RoomReviewerSurfaceNotice,
} from '@/components/buzz/RoomReviewerActions';
import { EmptyLedgerState, cornerNeedsStarter, type EmptyLedgerVariant } from '@/components/buzz/EmptyLedgerState';
import {
  CornerHeaderAgentText,
  HeaderIdentitySlot,
  HeaderMetaCaps,
  HeaderMetaRow,
} from '@/components/buzz/HeaderLadder';
import { ChannelHeaderTitle } from '@/components/buzz/ChannelHeaderTitle';
import { HullDialog, HullDialogInput } from '@/components/buzz/HullDialog';
import type { ChannelHeaderKind } from '@/buzz/channel-header-title';
import {
  newCornerOpenAttempt,
  openRandomNamedCorner,
  type CornerOpenAttempt,
} from '@/buzz/open-random-corner';
import { alertCornerOpenFailure } from '@/buzz/room-list-new-corner';
import { cornerOpenTappedAgain } from '@/buzz/corner-open-status';
import { forwardMessageToNewCorner, takeCornerComposerDraft } from '@/buzz/message-corner-forward';
import { roomMemberManagementState } from '@/buzz/room-member-management';
import { connectorOfferCeremonyRoute } from '@/buzz/connector-offer-ceremony';
import { useVoiceCall } from '@/buzz/use-voice-call';
import { VoiceCallCard } from '@/components/buzz/VoiceCallCard';
import { useIsDesktop } from '@/utils/responsive';
import { isDesktopShell } from '@/utils/isDesktopShell';
import {
  LEDGER_MARGINALIA_WIDTH,
  LedgerHistoryLine,
  LedgerRoomUpdate,
  LedgerSystemLine,
} from '@/components/buzz/Ledger';
import { IdentityMark } from '@/components/buzz/IdentityMark';
import {
  ChannelSuggestionMenu,
  MentionSuggestionMenu,
} from '@/components/buzz/MentionSuggestionMenu';
import { DirectMessageHeaderIdentity } from '@/components/buzz/DirectMessageHeaderIdentity';
import { RoomRosterSheet, type RoomRosterParticipant } from '@/components/buzz/RoomRosterSheet';
import { RepoPicker } from '@/components/buzz/RepoPicker';
import { SlashVerbPicker } from '@/components/buzz/SlashVerbPicker';
import { CreatePollSheet, type PollDraft } from '@/components/buzz/CreatePollSheet';
import { CornerAppRow } from '@/components/buzz/CornerAppScreen';
import { Button } from '@/components/buzz/Button';
import { SurfaceGlyphLoader } from '@/components/buzz/SurfaceGlyphLoader';
import {
  COMPOSER_MAX_INPUT_HEIGHT,
  COMPOSER_SINGLE_LINE_INPUT_HEIGHT,
  ConversationComposer,
  type DictatedSend,
} from '@/components/buzz/ConversationComposer';
import { subscribeDesktopWorkCorner } from '@/buzz/desktop-work-pane';

type RoomMemberOption = RoomRosterParticipant;
type MessageShortcut = {
  text: string;
  replyTarget?: MessageReplyTarget;
  viewer?: Omit<ViewerMessage, 'text'>;
};
const NO_SELECTED_MENTIONS: ReadonlyMap<string, string> = new Map();
/**
 * The reserved `@channel` autocomplete row: tags every human in the Room (the
 * parent Room, for a corner) except the author, never an agent. It is not a
 * roster member — `CHANNEL_MENTION_PUBKEY` is a sentinel, never a real
 * identity — so it rides alongside `roomParticipants` only inside the
 * mention menu's own candidate list.
 */
const CHANNEL_MENTION_OPTION: RoomMemberOption = {
  pubkey: CHANNEL_MENTION_PUBKEY,
  name: 'channel',
  handle: CHANNEL_MENTION_HANDLE,
  kind: 'person',
};

/**
 * The reserved `@system` autocomplete row: the feedback loop's report token,
 * offered in every Room, corner and DM. Picking it inserts `@system ` like any
 * mention, but System is never a member, so `SYSTEM_MENTION_PUBKEY` is a
 * sentinel that never reaches a send's mention list.
 */
const SYSTEM_MENTION_OPTION: RoomMemberOption = {
  pubkey: SYSTEM_MENTION_PUBKEY,
  name: 'System',
  handle: SYSTEM_MENTION_HANDLE,
  kind: 'person',
};

const COMPOSER_MIN_HEIGHT = COMPOSER_SINGLE_LINE_INPUT_HEIGHT;
const COMPOSER_MAX_HEIGHT = COMPOSER_MAX_INPUT_HEIGHT;
// How close to the visual bottom counts as "already reading the newest end"
// for the layout-change tail snap (C97): offset 0 when native is inverted,
// or content height minus viewport height on the ordinary desktop list.
const TAIL_PIN_THRESHOLD = 50;
// Rows the inverted phone list draws in its first render (FlatList's
// `initialNumToRender`). A source landing scrolls only to a row this close to
// the newest end; the store narrows the window for one further back.
const PHONE_FIRST_RENDER_ROWS = 10;
// Open on the tail of a long transcript instead of the full history, then
// page older messages in as the reader scrolls up.
const INITIAL_MESSAGE_WINDOW = 30;
// A corner's opening/progress prose is its audit trail. The cold tail already
// reads this many records; reveal that complete bounded page when its parent
// relation resolves instead of silently starting a reader 30 rows mid-story.
const INITIAL_CORNER_MESSAGE_WINDOW = 200;
/**
 * Every header control draws its mark in a 44 box; the extra 4 all round
 * carries the touch area over Material's 48dp floor without moving a pixel of
 * chrome. One slop for all of them: the trailing pair used to take a 14 slop
 * that grew a 44 box into a 72 one, so two controls parted by a spacing step
 * of bare slab overlapped each other in the hit layer. The Room pair's boxes
 * now touch (same as the Room-list pair); 4 of slop each way overlaps 8 in
 * the hit layer, which a 14 slop would have doubled.
 */
const HEADER_EDGE_HIT_SLOP = { top: 4, bottom: 4, left: 4, right: 4 } as const;
/**
 * Every trailing header mark is DRAWN at this size inside its own 44pt box.
 * One size for the pair is what makes the corners door and the overflow
 * control read as siblings, and a shape centred on its own box needs no
 * hand-tuned vertical correction to sit level with the mark beside it.
 * 28 matches the Room-list pair so the two screens share one chrome.
 */
const HEADER_MARK_SIZE = 28;

/**
 * The voice a transcript entry belongs to, or `null` for anything that is not
 * one, is decided by THE shared projection helper (`buzz/ledger-attribution.ts`
 * — Rooms and corners alike). This screen only supplies its roster union:
 * registered agents from the server-indexed roster.
 */
const knownAgentPubkeysFor = (agentByPubkey: Map<string, unknown>): Set<string> =>
  new Set(agentByPubkey.keys());

function durableFactLine(message: ChatDisplayMessage): string {
  const turn = buildTurnActivity(message.activity ?? []);
  const step =
    message.durableFact?.kind === 'failure'
      ? [...turn.steps].reverse().find((candidate) => candidate.outcome === 'failure')
      : turn.steps.at(-1);
  const glyph = message.durableFact?.kind === 'failure' ? '✗' : '✓';
  const label = step?.label ?? (message.durableFact?.kind === 'merge' ? 'change merged' : 'action');
  return `${glyph} ${label}${step?.reason ? ` · ${step.reason}` : ''}`;
}

export function BuzzChatSurface({
  session,
  bindingsRef,
}: {
  session: UseRoomSurfaceSessionResult;
  bindingsRef: MutableRefObject<RoomSurfaceSessionBindings>;
}) {
  const { theme } = useUnistyles();
  const isDesktop = useIsDesktop();
  // `parent`/`title` are hints, not authority: every surface that opens a
  // corner already knows both, so passing them makes the header correct on the
  // first frame instead of one server round trip later. The screen's own reads
  // still run and still win.
  const {
    channelId,
    notificationResponseId,
    notificationTarget,
    notificationMessageId,
    communityId,
    parent,
    title,
    returnTo,
  } = useLocalSearchParams<{
    channelId: string;
    notificationResponseId?: string;
    notificationTarget?: string;
    notificationMessageId?: string;
    communityId?: string;
    parent?: string;
    title?: string;
    returnTo?: string;
  }>();
  const decodedId = channelId ? decodeURIComponent(channelId) : '';
  const messageAnchorId = (notificationMessageId ?? notificationTarget ?? '').trim();
  const allowOlderHistoryRef = useRef(false);
  useEffect(() => {
    allowOlderHistoryRef.current = Boolean(messageAnchorId);
  }, [decodedId, messageAnchorId]);
  const { availableWidth: desktopAvailableWidth } = useDesktopLayout();
  // Desktop chrome and the work pane follow the live window, not the
  // monitor. `isDesktopPlatform()` is true for every browser, and
  // `screen.availWidth` is the display — either one sizes a phone tab as a
  // desktop shell and a narrowed desktop window as a 3-column wide layout.
  // A packaged Tauri window keeps the desktop experience at every width.
  const desktopExperience = isDesktop || isDesktopShell();
  const [profileKind, setProfileKind] = useState<'human' | 'agent'>('agent');
  const [profileAgentId, setProfileAgentId] = useState<string | null>(null);
  useEffect(() => {
    setProfileAgentId(null);
  }, [decodedId]);
  const routeParentChannelId = parent?.trim() || undefined;
  const routeCommunityId = communityId?.trim() || undefined;
  const routeChannelTitle = title?.trim() || undefined;
  const cornerReturnTarget =
    returnTo === 'room-list' || returnTo === 'corners' ? returnTo : undefined;
  const insets = useSafeAreaInsets();
  const readOnlyFooterInset =
    Platform.OS === 'android'
      ? { marginBottom: insets.bottom }
      : { paddingBottom: Math.max(insets.bottom, 8) };
  const navigation = useNavigation();
  const flatListRef = useRef<PhoneTranscriptListRef>(null);
  // The phone list's row keys, and the keys of the rows it has laid out. Each
  // window's rows get their own keys (`transcriptWindowId`, set below): the
  // list caches a row's position by key, and a row kept from the rows a new
  // window replaced would keep its old position.
  const transcriptWindowIdRef = useRef(0);
  const phoneRowKey = (rowId: string) => `${transcriptWindowIdRef.current}:${rowId}`;
  const [measuredPhoneRowKeys] = useState(() => new Set<string>());
  const [phoneScrollList] = useState(() =>
    phoneTranscriptList(
      () => flatListRef.current,
      (rowId) => measuredPhoneRowKeys.has(phoneRowKey(rowId)),
    ),
  );
  const [desktopScrollList] = useState(() =>
    desktopTranscriptList(
      () => desktopScrollNodeRef.current,
      (rowId) => desktopRowNodesRef.current.get(rowId),
    ),
  );
  // The only code that moves the transcript list
  // (`buzz/transcript-scroll-controller.ts`). Features below ask it for a
  // destination: the newest end, a message, or the first unread row. It also
  // holds the tail pin and the drag state. Declared before the
  // transcript-arrival projection so arrivals decide against the pre-append
  // view; its callbacks read the latest render.
  const scrollController = useTranscriptScrollController<ChatDisplayMessage>({
    list: () => (desktopTranscript ? desktopScrollList : phoneScrollList),
    rows: () => transcriptMessagesRef.current,
    rowIndex: (destination, rows) =>
      destination.kind === 'firstUnread'
        ? boundaryRowIndex(rows, destination.messageId)
        : hostRowIndex(rows, transcriptHostIdsRef.current, destination.messageId),
    canScrollTo: (destination, index) =>
      destination.kind !== 'message' ||
      !destination.jump ||
      messageJumpCanScrollTo(destination.messageId, index),
    onUnreachable: (destination) => {
      if (destination.kind === 'firstUnread') {
        const residentIndex = boundaryRowIndex(foldedMessages, destination.messageId);
        if (residentIndex >= 0) {
          revealTranscriptThrough(foldedMessages.length - residentIndex);
        } else if (transcriptHistoryStatus === 'idle') {
          loadOlderTranscriptMessages();
        }
        return;
      }
      // Loading: the row lands when it arrives. Error: the retry line shows.
      // Missing: the room stays at its newest rows under a short note.
      if (
        destination.jump &&
        transcriptJump?.messageId === destination.messageId &&
        transcriptJump.status === 'missing'
      ) {
        scrollController.cancel();
      }
    },
    onScrolled: (destination) => {
      if (destination.kind !== 'message' || !destination.jump) return;
      endTranscriptJump();
    },
    onLanded: (destination, rowId) => {
      if (scrollController.isHoldingLanding()) {
        heldLandingFromOldestRef.current =
          phoneContentHeightRef.current - phoneScrollOffsetRef.current;
        heldLandingShortRef.current = phoneContentHeightRef.current < phoneListHeightRef.current;
      }
      // The landing is COMPLETE here — the row is on screen, which is the same
      // rule the badge runs on. A flash fired at row mount or at the first
      // scroll would burn off behind the fold while the list was still
      // measuring, and the reader who followed the notification would arrive
      // to nothing.
      if (destination.kind === 'message' && destination.jump) raiseSourceLandingFlash(rowId);
      if (
        destination.kind === 'firstUnread' &&
        landingFlashesArrival({
          landedBoundaryId: destination.messageId,
          messageAnchorId: messageAnchorIdRef.current,
        })
      ) {
        raiseArrivalFlash(destination.messageId);
      }
    },
    // A detached window grows newer rows below a landed jump target (the
    // short-list fill, a later page). The target stays where it landed until
    // the reader moves the list.
    holdsLanding: (destination) =>
      destination.kind === 'message' && destination.jump && anchoredSegmentActive,
    // A jump the reader left (a drag, the newest disc, a send, another jump)
    // drops its own read so it cannot move them later. Only its own: a read
    // for another message belongs to the request that replaced this one.
    onCancelled: (destination) => {
      if (
        destination.kind === 'message' &&
        destination.jump &&
        transcriptJump?.messageId === destination.messageId
      )
        endTranscriptJump();
    },
  });
  // The phone list's cell. The list learns a row's position from the cell's
  // layout. That can come after a landing's last scroll and visibility report,
  // with the row off screen, so the landing runs again on it.
  const [PhoneTranscriptCell] = useState(
    () =>
      function PhoneTranscriptCell({
        cellKey,
        index: _index,
        item: _item,
        onLayout,
        ...props
      }: ViewProps & { cellKey: string; index: number; item: ChatDisplayMessage }) {
        return (
          <View
            {...props}
            onLayout={(event) => {
              onLayout?.(event);
              measuredPhoneRowKeys.add(cellKey);
              if (scrollController.isLanding()) scrollController.observeLayout();
            }}
          />
        );
      },
  );
  const handledNotificationAnchorRef = useRef<string | null>(null);
  const composerRef = useRef<TextInput>(null);
  // React state can lag the final Android native text event when the user
  // immediately taps send. Keep the authoritative in-flight draft beside the
  // native TextInput so an @mention never drops trailing text.
  const inputTextRef = useRef('');
  // A successful send replaces the native input. Advance this ref before any
  // asynchronous React update so an event already queued by the consumed
  // native field cannot put its text back into the next draft.
  const composerInputRevisionRef = useRef(0);
  // The picker knows the exact agent key, whereas text-only lookup is a
  // fallback for manually typed mentions. Keep that identity through trailing
  // typing so an async roster refresh cannot turn a selected agent into an
  // unaddressed plain Room message.
  const selectedAgentMentionsRef = useRef(new Map<string, string>());
  const selectedMentionsRef = useRef(new Map<string, string>());
  // When each agent was last told about, so a standing offline condition is
  const sendInFlightRef = useRef(false);
  const roomMessageProjectorRef = useRef<ReturnType<typeof createRoomMessageProjector> | null>(
    null,
  );
  const roomMessageProjector =
    roomMessageProjectorRef.current ??
    (roomMessageProjectorRef.current = createRoomMessageProjector());

  // Publish the open conversation to the foreground notification policy. The
  // root notification handler runs outside the React tree, so it reads this
  // tracker instead of route state. Synchronous, no relay work.
  const [pushMuted, setPushMuted] = useState(false);
  const [pushMuteWorking, setPushMuteWorking] = useState(false);
  const togglePushMute = async () => {
    if (pushMuteWorking) return;
    const previous = pushMuted;
    setPushMuteWorking(true);
    setPushMuted(!previous);
    try {
      const result = await monolithPhoneOperation('updateRoomPushState', {
        roomId: decodedId,
        muted: !previous,
      });
      setPushMuted(result.muted);
    } catch (error) {
      setPushMuted(previous);
      setMembershipError(`Could not update notifications: ${String(error)}`);
    } finally {
      setPushMuteWorking(false);
    }
  };
  const isFocused = useCallback(() => navigation.isFocused(), [navigation]);
  useFocusEffect(
    useCallback(() => {
      pushOpenBuzzChannelId(decodedId || null);
      // The live socket tells the server this Room is on screen, once on
      // arrival and once on leaving; the server ends the view when the
      // socket closes, so nothing repeats while the reader stays here.
      let releaseView: (() => void) | undefined;
      const updateViewing = (viewing: boolean) => {
        if (!decodedId) return;
        if (viewing) releaseView ??= sharedLiveConnection().view(decodedId);
        else {
          releaseView?.();
          releaseView = undefined;
        }
      };
      updateViewing(AppState.currentState === 'active');
      const viewingState = AppState.addEventListener('change', (state) =>
        updateViewing(state === 'active'),
      );
      const dismiss = () => {
        if (AppState.currentState !== 'active') return;
        void dismissPresentedNotificationsForChannel(decodedId, Notifications, Platform.OS).catch(
          (error) => {
            console.log('Failed to dismiss notifications for opened conversation:', error);
          },
        );
      };
      dismiss();
      const appState = AppState.addEventListener('change', dismiss);
      const received = Notifications.addNotificationReceivedListener(dismiss);
      return () => {
        viewingState.remove();
        updateViewing(false);
        releaseOpenBuzzChannelId(decodedId || null);
        appState.remove();
        received.remove();
      };
    }, [decodedId]),
  );

  const {
    transport,
    adoptTransport: setSessionTransport,
    roomClient,
    roomSurface,
    messageRecordScope,
    applyRoomRepositoryResult,
    clearRoomRepository,
    applyRoomMessageResult,
    applyPendingAgentCommands,
    applyRoomName,
    applyRoomReviewers,
    firstUnreadMessageId,
    advanceReadCursor,
    acknowledgeReadMark,
    liveOverlays,
    liveDraftStore,
    userPubkey,
    heartbeatPresences,
    presenceReconnectGrace,
    presenceNow,
    setPresenceNow,
    hydrationFailed: transcriptHydrationFailed,
    hydrationError: transcriptHydrationError,
    retryHydration,
    refreshSignal,
    outbox,
  } = session;
  useEffect(() => {
    return navigation.addListener('beforeRemove', () => {
      liveDraftStore.setActive(false);
    });
  }, [liveDraftStore, navigation]);
  useLayoutEffect(() => {
    if (!roomSurface) return;
    markRoomOpen('layout-chrome', roomSurface.messages.at(-1)?.id);
  }, [roomSurface]);
  // The Room read carries the viewer's mute; a toggle answers with its own.
  const hasRoomSurface = roomSurface !== null;
  const viewerPushMuted = roomSurface?.viewer.pushMuted === true;
  useEffect(() => {
    if (hasRoomSurface) setPushMuted(viewerPushMuted);
  }, [hasRoomSurface, viewerPushMuted]);
  const [inputText, setInputText, composerDraft] = useTextDraft(
    `composer:${decodedId}`,
    '',
    userPubkey || null,
    desktopExperience ? desktopDraftKey(decodedId) : undefined,
  );
  const activeComposerDraftRef = useRef(composerDraft);
  activeComposerDraftRef.current = composerDraft;
  const [composerInputRevision, setComposerInputRevision] = useState(0);
  const initialWorkPaneStateRef = useRef(initialDesktopWorkPaneState(desktopAvailableWidth));
  const [desktopWorkPane, setDesktopWorkPane] = useState(initialWorkPaneStateRef.current);
  const desktopWorkPaneRef = useRef(desktopWorkPane);
  const desktopWorkPaneContent = desktopWorkPaneVisibleContent(desktopWorkPane);
  useEffect(() => {
    setDesktopPaneOpen(Boolean(desktopExperience && desktopWorkPaneContent));
    return () => setDesktopPaneOpen(false);
  }, [desktopExperience, Boolean(desktopWorkPaneContent)]);
  const [desktopDeliveryState, setDesktopDeliveryState] = useState<
    'sending' | 'delivered' | 'failed' | null
  >(null);
  const [replyTarget, setReplyTarget] = useState<MessageReplyTarget | null>(null);
  const [turnChromeTopInset, setTurnChromeTopInset] = useState(0);
  const [composerHeight, setComposerHeight] = useState(COMPOSER_MIN_HEIGHT);
  const [inputSelection, setInputSelection] = useState({ start: 0, end: 0 });
  const [highlightedMentionIndex, setHighlightedMentionIndex] = useState(0);
  const [dismissedMentionKey, setDismissedMentionKey] = useState<string | null>(null);
  const [highlightedSlashVerbIndex, setHighlightedSlashVerbIndex] = useState(0);
  const [dismissedSlashText, setDismissedSlashText] = useState<string | null>(null);
  /** Per-Room+agent command lists (undefined = unresolved, empty = advertises none). */
  const [agentCommandsByScope, setAgentCommandsByScope] = useState<
    Record<string, readonly AgentComposerCommand[]>
  >({});
  /** Per-Room+agent Fast mode toggle (undefined = unread, null = not offered to this viewer). */
  const [agentFastModeByScope, setAgentFastModeByScope] = useState<
    Record<string, FastModeCommandState | null>
  >({});
  const [agentCanLoginByScope, setAgentCanLoginByScope] = useState<Record<string, boolean>>({});
  const [sending, setSending] = useState(false);
  const [cornerProposalAction, setCornerProposalAction] = useState<{
    messageId: string;
    decision: 'open' | 'cancel';
  } | null>(null);
  const failedOutboxIds = outbox.failedIds;
  const [pendingAttachments, setPendingAttachments] = useState<PickedChatAttachment[]>([]);
  // Paste/drop and Enter can land in one browser event batch. Keep the staged
  // files current synchronously so dispatch does not read the previous render
  // and then clear a screenshot it never uploaded.
  const pendingAttachmentsRef = useRef<PickedChatAttachment[]>([]);
  const replacePendingAttachments = useCallback(
    (
      update:
        PickedChatAttachment[] | ((current: PickedChatAttachment[]) => PickedChatAttachment[]),
    ) => {
      const next = typeof update === 'function' ? update(pendingAttachmentsRef.current) : update;
      pendingAttachmentsRef.current = next;
      setPendingAttachments(next);
    },
    [],
  );
  // Staged photos and files start uploading as soon as they land in the
  // composer, so send only waits for whatever is still in flight.
  const [attachmentUploader] = useState(createChatAttachmentUploader);
  // Each row shows its own upload state, so redraw whenever one changes.
  const [, setAttachmentUploadRevision] = useState(0);
  useEffect(
    () =>
      attachmentUploader.subscribe(() => setAttachmentUploadRevision((revision) => revision + 1)),
    [attachmentUploader],
  );
  useEffect(() => {
    attachmentUploader.retain(pendingAttachments);
    if (!transport || pendingAttachments.length === 0) return;
    void transport
      .ensureClient()
      .then((client) =>
        attachmentUploader.start(
          client,
          pendingAttachments.filter((attachment) =>
            pendingAttachmentsRef.current.includes(attachment),
          ),
        ),
      )
      .catch(() => undefined);
  }, [attachmentUploader, pendingAttachments, transport]);
  const [attachmentPickerVisible, setAttachmentPickerVisible] = useState(false);
  const [messageActionsTarget, setMessageActionsTarget] = useState<ChatDisplayMessage | null>(null);
  const [optimisticReactions, setOptimisticReactions] = useState<Record<string, ChatDisplayMessage['reactions']>>({});
  const optimisticReactionsRef = useRef(optimisticReactions);
  optimisticReactionsRef.current = optimisticReactions;
  const [optimisticDeletes, setOptimisticDeletes] = useState<Record<string, true>>({});
  const reactingRef = useRef(new Set<string>());
  const { showCopied: showReportToast, toast: reportToast } =
    useCopiedToast('message-report-toast');
  const [forwardTarget, setForwardTarget] = useState<ChatDisplayMessage | null>(null);
  const [forwardRooms, setForwardRooms] = useState<readonly ForwardTarget[] | null>(null);
  const [forwardBusyRoomId, setForwardBusyRoomId] = useState<string | null>(null);
  const [forwardError, setForwardError] = useState<string | null>(null);
  // What this corner inherited from the Room it was opened out of: the task
  // the daemon recorded on its create event, and the bounded window of Room
  // conversation that preceded it. Corner-only; a Room never reads it.
  const [addingMembers, setAddingMembers] = useState(false);
  /** The shared `/workspace/:id` entry behind bylines and member and mention pickers. */
  const [workspaceRosterEntry, setWorkspaceRoster] = useState<WorkspaceView | null>(null);
  const [workspaceRosterAddress, setWorkspaceRosterAddress] = useState<SurfaceCacheAddress | null>(null);
  // The entry's rows select the shared Workspace records, which every
  // roster write reaches; the entry supplies only the ids and header.
  const workspaceRosterScope = workspaceRosterAddress
    ? workspaceRecordScope(workspaceRosterAddress.relayOrigin, workspaceRosterAddress.viewerPubkey,
      String(workspaceRosterAddress.params?.workspaceId))
    : null;
  const workspaceRosterRecords = useWorkspaceRecords(workspaceRosterScope);
  const workspaceRoster = useMemo<WorkspaceView | null>(() => workspaceRosterEntry && workspaceRosterScope
    ? {
        ...workspaceRosterEntry,
        members: workspaceRows(workspaceRosterScope,
          workspaceRosterEntry.members.map((member) => member.identity.pubkey)),
        agents: workspaceRows(workspaceRosterScope,
          workspaceRosterEntry.agents.map((agent) => agent.identity.pubkey)),
      }
    : workspaceRosterEntry,
  // eslint-disable-next-line react-hooks/exhaustive-deps -- the records version re-selects the rows
  [workspaceRosterEntry, workspaceRosterScope, workspaceRosterRecords]);
  const workspaceRosterScopeRef = useRef<string | null>(null);
  // The repo this Room owns, or `null` for a chat-only Room. Corners never
  // read this — a corner has no room-repository binding of its own; the
  // daemon resolves its working repo from its parent Room instead.
  const [showRoomRepoPicker, setShowRoomRepoPicker] = useState(false);
  const [roomRepoBusy, setRoomRepoBusy] = useState(false);
  const [roomRepoListLoading, setRoomRepoListLoading] = useState(false);
  const [roomRepoError, setRoomRepoError] = useState<string | null>(null);
  const [roomRepoNotice, setRoomRepoNotice] = useState<string | null>(null);
  // Typed "the App does not cover this repository yet" state: rendered as a
  // share-with-owner CTA, never an error wall. `uncoveredOwners` feeds the
  // paste-flow plan so a foreign repo plans the share path instead of a
  // doomed self-connect.
  const [ownerGrant, setOwnerGrant] = useState<OwnerGrantNeeded | null>(null);
  const uncoveredOwnersRef = useRef<Set<string>>(new Set());
  const [cornerOpenRepoPrompt, setCornerOpenRepoPrompt] = useState(false);
  const [roomRepoAccessIssue, setRoomRepoAccessIssue] = useState<{
    fullName: string;
    reason: 'revoked' | 'not_granted';
    installationId?: number;
  } | null>(null);
  const [rosterVisible, setRosterVisible] = useState(false);
  const closeRoster = useCallback(() => setRosterVisible(false), []);
  const [roomActionsVisible, setRoomActionsVisible] = useState(false);
  const [cornerActionsVisible, setCornerActionsVisible] = useState(false);
  const [dmActionsVisible, setDmActionsVisible] = useState(false);
  const [renameEditing, setRenameEditing] = useState(false);
  const [renameDraft, setRenameDraft, renameTextDraft] = useTextDraft(
    `rename:${decodedId}`,
    '',
    userPubkey || null,
  );
  const [renameBusy, setRenameBusy] = useState(false);
  const [renameError, setRenameError] = useState<string | null>(null);
  const [openingRandomCorner, setOpeningRandomCorner] = useState(false);
  const [forwardCornerPrompt, setForwardCornerPrompt] = useState<ChatDisplayMessage | null>(null);
  const [participantPickerVisible, setParticipantPickerVisible] = useState(false);
  const [participantPickerKind, setParticipantPickerKind] = useState<'person' | 'agent' | null>(
    null,
  );
  const [membershipError, setMembershipError] = useState<string | null>(null);
  const [memberInviteBusy, setMemberInviteBusy] = useState(false);
  const [agentConnectVisible, setAgentConnectVisible] = useState(false);
  const [agentPairCommand, setAgentPairCommand] = useState<string | null>(null);
  const [agentPairBusy, setAgentPairBusy] = useState(false);
  const [agentPairError, setAgentPairError] = useState<string | null>(null);
  const [membershipActionPubkey, setMembershipActionPubkey] = useState<string | null>(null);
  const [roomLifecycleBusy, setRoomLifecycleBusy] = useState(false);
  const directMessage = roomSurface?.directMessage ?? null;
  // Hoisted above the pane handlers that need it in their dependency arrays.
  const isDirectMessage = Boolean(directMessage);
  const [composerFocused, setComposerFocused] = useState(false);
  const [createPollVisible, setCreatePollVisible] = useState(false);
  const [createPollBusy, setCreatePollBusy] = useState(false);
  const [permissionActionId, setPermissionActionId] = useState<string | null>(null);
  const [grantActionId, setGrantActionId] = useState<string | null>(null);
  const [connectorOfferActionId, setConnectorOfferActionId] = useState<string | null>(null);
  const [appSignInActionId, setAppSignInActionId] = useState<string | null>(null);
  const [choiceActionId, setChoiceActionId] = useState<string | null>(null);
  /** Proposal currently being confirmed, and the last refusal/failure text. */
  const [targetBranchActionId, setTargetBranchActionId] = useState<string | null>(null);
  const [targetBranchNotice, setTargetBranchNotice] = useState<{
    proposalId: string;
    text: string;
  } | null>(null);
  // Armed the instant a message this client believes addresses an agent is
  // sent, so the composer never shows dead air waiting on the real WORKING
  // receipt (API write + pickup + receipt + refetch). See
  // `selectComposerAckState`.
  const [pendingAck, setPendingAck] = useState<{ sentAt: number; requestId?: string } | null>(null);
  const [receivedSteer, setReceivedSteer] = useState<{
    agentPubkey: string;
    turnRequestId: string;
    receivedAt: number;
  } | null>(null);

  useLayoutEffect(() => {
    inputTextRef.current = inputText;
  }, [inputText]);
  useEffect(() => {
    setDesktopDeliveryState(null);
  }, [decodedId, userPubkey]);

  const stagedComposerFocusRef = useRef<{ start: number; end: number } | null>(null);
  useEffect(() => {
    // A corner opened by a swipe-right forward arrives with that forward ready
    // in its composer and the cursor after it.
    const staged = takeCornerComposerDraft(decodedId);
    if (staged === undefined) return;
    const selection = { start: staged.length, end: staged.length };
    inputTextRef.current = staged;
    setInputText(staged);
    setInputSelection(selection);
    // The forward ends with the author's @handle; the cursor after it should
    // not reopen the mention menu.
    const mention = activeMentionAtCursor(staged, staged.length);
    setDismissedMentionKey(mention ? `${staged}:${mention.start}:${mention.end}` : null);
    stagedComposerFocusRef.current = selection;
  }, [decodedId]);

  const composerMounted = Boolean(roomSurface);
  useEffect(() => {
    // The composer mounts only once the new corner has loaded, so the staged
    // forward's cursor waits for it.
    const fullSelection = stagedComposerFocusRef.current;
    if (!composerMounted || !fullSelection) return;
    stagedComposerFocusRef.current = null;
    scheduleAnimationFrame(() => {
      focusComposerSelection(composerRef.current, fullSelection, Platform.OS);
    });
  }, [composerMounted, decodedId]);

  const commitDesktopWorkPane = useCallback((event: DesktopWorkPaneEvent) => {
    const transition = transitionDesktopWorkPane(desktopWorkPaneRef.current, event);
    desktopWorkPaneRef.current = transition.state;
    setDesktopWorkPane(transition.state);
    return transition;
  }, []);

  useEffect(() => {
    if (!desktopExperience) return;
    commitDesktopWorkPane({ type: 'resize', width: desktopAvailableWidth });
  }, [commitDesktopWorkPane, desktopExperience, desktopAvailableWidth]);

  // The second pane belongs to the view it opened beside: switching rooms
  // closes it. Declared before the corner subscription so a rail corner that
  // switched rooms opens after this close, not before it.
  useEffect(() => {
    commitDesktopWorkPane({ type: 'close' });
  }, [commitDesktopWorkPane, decodedId]);

  const cacheViewerPubkey = userPubkey;
  const isArchived = roomIsArchived(roomSurface?.room);
  const surfaceParentId = roomSurface ? roomViewParentId(roomSurface) : undefined;
  const parentChannelId = surfaceParentId ?? routeParentChannelId;
  const desktopWorkRoomId = parentChannelId ?? decodedId;
  const needsDesktopParentRoom = desktopExperience && !isDirectMessage && Boolean(desktopWorkPaneContent);
  const desktopParentRoom = useDesktopParentRoom(needsDesktopParentRoom, parentChannelId, roomClient);
  const desktopWorkRoom = parentChannelId ? desktopParentRoom : roomSurface;
  const currentComputerSession = desktopWorkPaneContent?.kind === 'computer'
    ? (roomSurface?.messages.find((message) => message.computerSession?.id === desktopWorkPaneContent.session.id)?.computerSession
      ?? desktopWorkRoom?.messages.find((message) => message.computerSession?.id === desktopWorkPaneContent.session.id)?.computerSession)
    : undefined;
  const displayedDesktopWorkPaneContent = desktopWorkPaneContent?.kind === 'computer' && currentComputerSession
    ? { ...desktopWorkPaneContent, session: { ...currentComputerSession, access: desktopWorkPaneContent.session.access } }
    : desktopWorkPaneContent;
  // A direct message has no second pane: artifacts open in the full-screen
  // viewer and the transcript keeps the width.
  const desktopWorkPaneMounted =
    desktopExperience && !isDirectMessage && desktopWorkPaneContent ? desktopWorkRoom : null;
  const channelKind: ChannelKind = roomSurface
    ? surfaceParentId
      ? 'corner'
      : 'room'
    : routeParentChannelId
      ? 'corner'
      : 'unknown';
  const isCorner = Boolean(parentChannelId);
  useEffect(() => {
    if (!isCorner && firstUnreadMessageId) allowOlderHistoryRef.current = true;
  }, [firstUnreadMessageId, isCorner]);
  const resolvedChannelName = roomSurface?.room.name ?? routeChannelTitle ?? null;
  const activeCommunityId = roomSurface?.room.workspaceId ?? routeCommunityId ?? null;
  // The DM header, the repository-change guard, mentions and forwarding read
  // the app-level Room list, which stays live while this Room is open.
  const [chatListRelayUrl, setChatListRelayUrl] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    void getEffectiveRelayUrl().then((url) => {
      if (!cancelled) setChatListRelayUrl(url);
    });
    return () => {
      cancelled = true;
    };
  }, []);
  const chatListKey = useMemo(
    () =>
      chatListRelayUrl && userPubkey && activeCommunityId
      ? { relayUrl: chatListRelayUrl, viewerPubkey: userPubkey, workspaceId: activeCommunityId }
      : null,
    [activeCommunityId, chatListRelayUrl, userPubkey],
  );
  const githubScope = chatListRelayUrl && userPubkey
    ? { relay: chatListRelayUrl, viewer: userPubkey } : null;
  const githubAccess = useGitHubAccess(githubScope);
  const roomRepoCandidates = githubAccess?.candidates ?? [];
  const githubInstallations = githubAccess?.installations ?? [];
  const workspaceChatList = useChatList(chatListKey, { transcriptRoomId: decodedId });
  const workspaceChats = useMemo<readonly ChatListItem[]>(
    () => workspaceChatList?.chats ?? [],
    [workspaceChatList],
  );
  const viewerIsAgent = roomSurface?.viewer.identity.kind === 'agent';
  const { captureSend: captureUntaggedSend, hintMessageIds, endVisit: endUntaggedHintVisit } = useUntaggedMessageHints({
    roomId: decodedId,
    viewerPubkey: userPubkey,
    active: isFocused,
    viewerKind: roomSurface?.viewer.identity.kind,
    isDirectMessage,
    hasAgentMembers: Boolean(roomSurface?.members.some(member => member.identity.kind === 'agent')),
  });
  useFocusEffect(useCallback(() => () => endUntaggedHintVisit(), [endUntaggedHintVisit]));
  const roomVoiceAgents = useMemo(() => roomSurface?.members
    .filter(member => member.identity.kind === 'agent').map(member => member.identity) ?? [], [roomSurface?.members]);
  const voice = useVoiceCall(decodedId, Boolean(roomSurface?.viewer.permissions.send && !viewerIsAgent && !isArchived && !isCorner), roomVoiceAgents);
  useEffect(() => { if (voice.error && !voice.quotaExhausted && !voice.error.startsWith('Calls resume at ')) showVoiceJoinError(voice.error); }, [voice.error, voice.quotaExhausted]);
  // The SERVER's statement of who is reading, so the phone's requester test and
  // the server's own are the same comparison over the same namespace.
  const viewerPubkey = roomSurface?.viewer.identity.pubkey;
  const canManageWorkspace = roomSurface?.viewer.permissions.manage ?? false;
  const canRenameTitle = isCorner
    ? !viewerIsAgent && !isArchived
    : Boolean(!isDirectMessage && !viewerIsAgent && canManageWorkspace);
  const communities = useMemo(
    () =>
      roomSurface && activeCommunityId
        ? [
            workspaceRailItem({
              id: activeCommunityId,
              name: roomSurface.parent?.name ?? roomSurface.room.name,
              visibility: 'invite-only',
              role: roomSurface.viewer.role,
              updatedAt: roomSurface.room.updatedAt ?? 0,
            }),
          ]
        : [],
    [activeCommunityId, roomSurface?.parent, roomSurface?.room, roomSurface?.viewer.role],
  );
  const cornerTask = surfaceParentId ? roomSurface?.room.about : undefined;
  const roomRepository = useMemo<RoomRepository | null>(() => {
    if (isCorner || !roomSurface?.repository || !activeCommunityId) return null;
    const repository = roomSurface.repository;
    return {
      channelId: decodedId,
      communityId: activeCommunityId,
      binding: {
        key: repository.key,
        name: repository.name,
        remote: repository.remote,
        localOnly: false,
        ...(repository.githubInstallationId
          ? { githubInstallationId: repository.githubInstallationId }
          : {}),
      },
      targetBranch: repository.targetBranch,
      githubEventsEnabled: repository.githubEventsEnabled,
      allowAutoMerge: repository.allowAutoMerge,
      source: 'config',
    };
  }, [activeCommunityId, decodedId, isCorner, roomSurface?.repository]);
  const roomRepositoryState = roomSurface?.repositoryResolution;
  // A loaded surface with no repository field is not enough to prompt. The
  // indexer distinguishes a proven empty Room from an unverified binding,
  // including bindings authored by a predecessor key.
  const roomRepositoryResolved = roomRepositoryState === 'none';
  useEffect(() => {
    // A stale cached `none` response can briefly open the lazy prompt before a
    // fresh server read discovers a binding it cannot verify. Do not leave the
    // stronger, fresh fact painted as the false "not linked" banner.
    if (roomRepositoryState !== 'none' && !roomRepoAccessIssue) {
      setCornerOpenRepoPrompt(false);
    }
  }, [roomRepoAccessIssue, roomRepositoryState]);
  const serverTailRows = useMemo(
    () => (roomSurface ? roomViewTranscriptMessages(roomSurface) : []),
    [roomSurface?.messages, roomSurface?.toolRows],
  );
  // Resolve references only within the Room family returned by this surface.
  const rawChannelReferenceIndex = useMemo<ChannelReferenceIndex>(() => {
    return buildChannelReferenceIndex(
      [
        ...workspaceChats
          .filter((item) => !item.directMessage)
          .map((item) => ({ channelId: item.room.id, name: item.room.name }))
          .sort((left, right) => left.channelId.localeCompare(right.channelId)),
        ...(roomSurface?.parent
          ? [{ channelId: roomSurface.parent.id, name: roomSurface.parent.name }]
          : []),
        ...(parentChannelId
          ? []
          : [{ channelId: decodedId, name: resolvedChannelName || routeChannelTitle || '' }]),
      ].filter((room): room is { channelId: string; name: string } => room !== null),
      [
        ...(parentChannelId
          ? [
              {
                channelId: decodedId,
                parentChannelId,
                name: resolvedChannelName || routeChannelTitle || '',
              },
            ]
          : []),
      ],
    );
  }, [
    decodedId,
    parentChannelId,
    resolvedChannelName,
    roomSurface?.parent,
    routeChannelTitle,
    workspaceChats,
  ]);
  // Room previews change on each arrival; links depend only on ids and names.
  const channelReferenceIndex = useStable(rawChannelReferenceIndex, (previous, next) =>
    previous.rooms.length === next.rooms.length &&
    previous.corners.length === next.corners.length &&
    previous.rooms.every((room, index) => shallowEqualRecord(room, next.rooms[index]!)) &&
    previous.corners.every((corner, index) => shallowEqualRecord(corner, next.corners[index]!)),
  );
  const desktopWorkPanePrimary: DesktopWorkPanePrimary = isDirectMessage
    ? 'direct-message'
    : isCorner
      ? 'corner'
      : 'room';
  // A corner always opens in the primary view; the second pane is for artifacts.
  const openDesktopCorner = useCallback(
    (roomId: string, cornerId: string) => {
      const transition = commitDesktopWorkPane({
        type: 'open-corner',
        cornerId,
        primary: desktopWorkPanePrimary,
      });
      if (transition.placement === 'primary') router.push(cornerHref(cornerId, roomId));
    },
    [commitDesktopWorkPane, desktopWorkPanePrimary],
  );
  // Background stack screens stay mounted, so only the focused one listens.
  useFocusEffect(useCallback(() => {
    if (!desktopExperience || !isFocused()) return;
    return subscribeDesktopWorkCorner(({ roomId, cornerId }) => {
      if (roomId !== desktopWorkRoomId) return false;
      openDesktopCorner(roomId, cornerId);
      return true;
    });
  }, [desktopExperience, desktopWorkRoomId, isFocused, openDesktopCorner]));
  // The work pane and the Room route are siblings, so an artifact Open press
  // arrives as a module event. It replaces whatever the pane showed. When the
  // pane cannot take it, the card opens the full-screen viewer instead.
  useFocusEffect(useCallback(() => {
    if (!desktopExperience || !isFocused()) return;
    return subscribeDesktopArtifact(
      (artifact) =>
        commitDesktopWorkPane({ type: 'open-artifact', artifact, primary: desktopWorkPanePrimary })
          .placement === 'pane',
    );
  }, [commitDesktopWorkPane, desktopExperience, desktopWorkPanePrimary, isFocused]));
  useFocusEffect(useCallback(() => {
    if (!desktopExperience || !isFocused()) return;
    return subscribeDesktopComputer((session) =>
      commitDesktopWorkPane({ type: 'open-computer', session, primary: desktopWorkPanePrimary })
        .placement === 'pane',
    );
  }, [commitDesktopWorkPane, desktopExperience, desktopWorkPanePrimary, isFocused]));
  /** Navigate to exactly the referenced Room/Corner through the existing
   * conventions; a reference to the transcript you are already in is a no-op. */
  const openingChannelReferenceRef = useRef<string | null>(null);
  const handleOpenChannelReference = useCallback(
    async (target: ChannelReferenceTarget, text?: string) => {
      if (target.kind === 'room' && (!target.channelId || target.channelId === decodedId)) return;
      if (target.kind === 'corner' && target.channelId === decodedId) return;
      if (openingChannelReferenceRef.current) return;
      const referenceLabel = text ?? 'this destination';
      if (!roomClient) {
        Modal.alert(
          'Destination unavailable',
          `Beeline is still connecting. Try ${referenceLabel} again in a moment.`,
        );
        return;
      }
      const lock =
        target.kind === 'corner'
          ? (target.channelId ?? `pending:${target.parentChannelId}:${target.name ?? text ?? ''}`)
          : target.channelId;
      openingChannelReferenceRef.current = lock;
      try {
        let resolved = target;
        if (resolved.kind === 'corner' && !resolved.channelId) {
          const list = await roomClient.corners(resolved.parentChannelId);
          const found = resolveCornerFromList(
            text ?? '',
            { id: list.room.id, name: list.room.name },
            list.corners.map((item) => ({ id: item.corner.id, name: item.corner.name })),
          );
          if (!found) {
            Modal.alert(
              'Access denied',
              `${referenceLabel} is unavailable or you no longer have access.`,
            );
            return;
          }
          resolved = found;
        }
        if (!resolved.channelId || resolved.channelId === decodedId) return;
        // The destination's own Room read is the authorization verdict. A
        // preflight here doubled the request for every successful open.
        if (resolved.kind === 'corner')
          openDesktopCorner(resolved.parentChannelId, resolved.channelId);
        else router.push(roomHref(resolved.channelId));
      } catch (error) {
        if (isUnavailableChannelReferenceError(error)) {
          Modal.alert(
            'Access denied',
            `${referenceLabel} is unavailable or you no longer have access.`,
          );
        } else {
          Modal.alert(
            'Could not open destination',
            `Beeline could not verify access to ${referenceLabel}. Check your connection and try again.`,
          );
        }
      } finally {
        openingChannelReferenceRef.current = null;
      }
    },
    [decodedId, openDesktopCorner, roomClient],
  );
  const handleOpenProfile = useCallback(
    (agentId: string, kind: 'human' | 'agent' = 'agent') => {
      if (agentId === cacheViewerPubkey) {
        router.push('/beeline/settings' as Href);
        return;
      }
      setProfileKind(kind);
      if (!activeCommunityId) return;
      if (desktopExperience) setProfileAgentId(agentId);
      else
        router.push(
          kind === 'human'
            ? ({
                pathname: '/beeline/human-profile',
                params: { communityId: activeCommunityId, memberId: agentId },
              } as Href)
            : ({
                pathname: '/beeline/agent-profile',
                params: { communityId: activeCommunityId, agentId, roomId:decodedId },
              } as Href),
        );
    },
    [activeCommunityId, desktopExperience, cacheViewerPubkey,decodedId],
  );
  const openingMentionRef = useRef<string | null>(null);
  const handleOpenMention = useCallback(
    async (participantId: string) => {
      if (participantId === cacheViewerPubkey || openingMentionRef.current) return;
      if (!transport || !activeCommunityId) {
        Modal.alert(
          'Could not open direct message',
          'Beeline is still connecting. Try the mention again in a moment.',
        );
        return;
      }
      openingMentionRef.current = participantId;
      try {
        const action = await resolveMentionDirectMessageAction(
          (workspaceId, memberId) => transport.resolveDirectMessage(workspaceId, memberId),
          activeCommunityId,
          participantId,
          decodedId,
        );
        if (action.type === 'open-room') router.push(roomHref(action.channelId));
      } catch (reason) {
        Modal.alert(
          'Could not open direct message',
          reason instanceof Error ? reason.message : String(reason),
        );
      } finally {
        openingMentionRef.current = null;
      }
    },
    [activeCommunityId, cacheViewerPubkey, decodedId, transport],
  );
  // The cold-open deadline bounds the single authenticated Room request.
  // A rejected request surfaces through `onStepFailed('transcript')` below.
  // Older pages loaded on demand via "scroll up" pagination. Kept out of the
  // shared cache (which bounds to the recent tail) and merged in only here.
  // History stays as verbatim server rows in page-lifetime partitions. It is
  // converted to render props only below, never persisted as a derived
  // transcript or folded into the current Room response.
  const {
    rows: serverHistoryRows,
    positions: transcriptPositions,
    attached: historyAttached,
    windowId: transcriptWindowId,
    jump: transcriptJump,
    newerStatus: transcriptNewerStatus,
    loadNewer: loadNewerTranscriptMessages,
    fill: fillTranscript,
    fillStatus: transcriptFillStatus,
    retryNewer: retryNewerTranscriptMessages,
    endJump: endTranscriptJump,
    loadLatest: loadLatestTranscriptMessages,
    jumpTo: jumpToTranscriptMessage,
    visibleMessageCount,
    status: transcriptHistoryStatus,
    loadOlder: loadOlderHistory,
    retryOlder: retryOlderHistory,
    revealThrough: revealTranscriptThrough,
    reset: resetTranscriptHistory,
  } = useRoomMessageStore({
    roomId: decodedId,
    tailMessages: roomSurface?.room.id === decodedId ? roomSurface.messages : undefined,
    roomClient,
    enabled: Boolean(cacheViewerPubkey),
    initialVisibleCount: isCorner ? INITIAL_CORNER_MESSAGE_WINDOW : INITIAL_MESSAGE_WINDOW,
  });
  const [tailRows, historyRows] = useRoomMessageRecords(messageRecordScope, decodedId, [
    serverTailRows, serverHistoryRows,
  ]);
  const cachedMessages = useMemo(
    () => (cacheViewerPubkey ? roomMessageProjector.project(tailRows, cacheViewerPubkey) : []),
    [cacheViewerPubkey, roomMessageProjector, tailRows],
  );
  const committedMessageIds = useMemo(
    () => new Set(cachedMessages.map((message) => message.id)),
    [cachedMessages],
  );
  const liveMessages = useMemo<ChatDisplayMessage[]>(
    () =>
      roomSurface
        ? liveDraftMessages(liveOverlays, [...tailRows, ...historyRows], roomSurface.latestAgentTurns)
        : [],
    [historyRows, liveOverlays, roomSurface, tailRows],
  );
  // A detached window (a jump target far from the newest rows) shows only its
  // own rows until `loadNewer` walks it back to the live tail.
  transcriptWindowIdRef.current = transcriptWindowId;
  const anchoredSegmentActive = !historyAttached;
  const olderMessages = useMemo(
    () => (cacheViewerPubkey ? displayRoomMessages(historyRows, cacheViewerPubkey) : []),
    [cacheViewerPubkey, historyRows],
  );
  const durableMessages = useMemo(
    () =>
      anchoredSegmentActive
        ? olderMessages
        : mergeDisplayPages(olderMessages, cachedMessages, liveMessages),
    [anchoredSegmentActive, cachedMessages, liveMessages, olderMessages],
  );
  const {
    frame: roomSendFrame,
    append: addMessages,
    reconcile: reconcileOptimistic,
    remove: removeOptimistic,
    clear: clearOptimistic,
  } = useRoomSendFrame(durableMessages, committedMessageIds);
  bindingsRef.current = {
    resetTranscript: () => {
      roomMessageProjector.reset();
      resetTranscriptHistory();
      clearOptimistic();
    },
    restoreOutboxMessages: addMessages,
    dismissOptimisticMessage: removeOptimistic,
    // A newly indexed working lease can be newer than the screen's prior
    // clock. Re-evaluate it at RoomView application time, as this screen did
    // before the surface lifecycle moved into useRoomSurfaceSession.
    observeRoomSurface: () => undefined,
  };
  useLayoutEffect(() => {
    const records = outbox.current()?.list() ?? [];
    if (records.length === 0 || !userPubkey) return;
    addMessages(records.map((record) => displayRoomMessages([record.row], userPubkey)[0]!));
  }, [addMessages, outbox, userPubkey]);
  // All four display partitions share the same chronological merge. A durable
  // outbox row may be older than the current server tail after an interrupted
  // publish, so it must never claim the inverted list's newest slot.
  const combinedMessages = useMemo(
    () =>
      anchoredSegmentActive
        ? durableMessages
        : mergeDisplayPages(durableMessages, roomSendFrame.optimistic),
    [anchoredSegmentActive, durableMessages, roomSendFrame.optimistic],
  );
  // Current server message authors refresh the same membership roster that
  // drives Room and corner bylines, mention suggestions, and mention glossing.
  // Rebuilt from every live message, so keep the previous map while no
  // identity changed: the agent/person lookups and the row renderer hang off it.
  const conversationIdentities = useStable(
    useMemo(
      () => conversationIdentityByPubkey(roomSurface?.members ?? [], combinedMessages),
      [combinedMessages, roomSurface?.members],
    ),
    sameRecordValueMap,
  );
  // Open on the tail; older history reveals from what's already resident here
  // first, then pages in from the server once that's exhausted.
  // A corner turn's per-call activity rows read back as one collapsed group
  // per turn; the window and paging count those groups, not the raw rows.
  // Same-verb system lines and adjacent GitHub lifecycle rows fold into one.
  const unreadLine = useUnreadLineControl({
    roomId: decodedId,
    firstUnreadMessageId: isCorner ? null : firstUnreadMessageId,
    enabled: !isCorner,
  });
  const { dividerMessageId: firstNewMessageId } = unreadLine;
  const foldRoomRows = useMemo(createTranscriptRowFolder, [decodedId, messageRecordScope]);
  const foldedTranscript = useMemo(
    () => foldRoomRows(combinedMessages, firstNewMessageId),
    [combinedMessages, firstNewMessageId, foldRoomRows],
  );
  const foldedMessages = foldedTranscript.rows;
  // Every message id, folded ones included, to the id of the row that shows it.
  const transcriptHostIdsRef = useRef(foldedTranscript.hostIds);
  transcriptHostIdsRef.current = foldedTranscript.hostIds;
  const arrivalMessages = useMemo(() => {
    if (!anchoredSegmentActive) return foldedMessages;
    const tail = mergeDisplayPages(cachedMessages, liveMessages, roomSendFrame.optimistic);
    return foldTranscriptRows(tail, null).rows;
  }, [
    anchoredSegmentActive,
    cachedMessages,
    foldedMessages,
    liveMessages,
    roomSendFrame.optimistic,
  ]);
  const transcriptArrivalStateRef = useRef(EMPTY_TRANSCRIPT_ARRIVAL_STATE);
  const transcriptCardMotionStore = useMemo(createTranscriptCardMotionStore, [decodedId]);
  const transcriptArrivalObservation = useMemo(() => {
    return observeTranscriptArrivals(transcriptArrivalStateRef.current, {
      surfaceId: decodedId,
      hydrated: Boolean(roomSurface),
      // A fold can gain a new durable fact without changing its host row id.
      // Observe every represented id so that arrival still joins the queue.
      ids: arrivalMessages.flatMap(messageBoundaryIds),
    });
  }, [arrivalMessages, decodedId, roomSurface]);
  const arrivingCardIds = useStable(transcriptArrivalObservation.arrivingIds, sameStringSet);
  useEffect(() => {
    // Keep the comparison anchored to the last committed transcript. Mutating
    // this ref during render makes React's development double-render consume a
    // live arrival before the card ever reaches the screen.
    transcriptArrivalStateRef.current = transcriptArrivalObservation.state;
  }, [transcriptArrivalObservation.state]);
  const unprojectedMessages = useMemo(
    () => visibleTranscriptWindow(foldedMessages, visibleMessageCount),
    [foldedMessages, visibleMessageCount],
  );
  // The immutable summary stored on the corner Room is the objective for its
  // entire lifecycle; it names the empty transcript. Mutable plans never rewrite it.
  const cornerObjective = useMemo(
    () =>
      cornerObjectiveItems({
        ...(cornerTask ? { task: cornerTask } : {}),
        ...(resolvedChannelName ? { cornerName: resolvedChannelName } : {}),
      }),
    [cornerTask, resolvedChannelName],
  );
  // The same objective as one line, for the inscription under the header and
  // for the empty state's steering copy — derived once so the two never drift.
  const cornerObjectiveText = useMemo(() => cornerObjective.join(' '), [cornerObjective]);
  // The brief's latest revision opens full-screen in the artifact viewer, from
  // the objective line and from a "revised the corner brief" system line. No
  // brief, no link.
  const cornerBrief = roomSurface?.cornerBrief;
  const openCurrentBrief = useMemo(
    () => (cornerBrief ? () => openCornerBriefViewer(cornerBrief) : undefined),
    [cornerBrief],
  );
  // A live workflow run in this corner: one line under the objective, → its run page.
  const {
    workflow: roomWorkflowRun,
    otherLiveRuns: roomOtherLiveRuns,
  } = useRoomWorkflowRun(isCorner ? decodedId : undefined);
  const openRoomWorkflowRun = useCallback((run: WorkflowRunSummaryView) => {
    router.push(workflowRunHref(run));
  }, []);

  const loadOlderTranscriptMessages = useCallback(() => {
    const visibleRowCount = visibleTranscriptWindow(foldedMessages, Number.MAX_SAFE_INTEGER).length;
    loadOlderHistory(visibleRowCount);
  }, [foldedMessages, loadOlderHistory]);
  const loadOlderTranscriptIfReaderAsked = useCallback(() => {
    if (!allowOlderHistoryRef.current) return;
    loadOlderTranscriptMessages();
  }, [loadOlderTranscriptMessages]);
  const retryOlderTranscriptMessages = useCallback(() => {
    retryOlderHistory(visibleTranscriptWindow(foldedMessages, Number.MAX_SAFE_INTEGER).length);
  }, [foldedMessages, retryOlderHistory]);
  const retryTranscriptJump = useCallback(() => {
    if (!transcriptJump) return;
    requestMessageJump(scrollController, transcriptJump.messageId, jumpToTranscriptMessage);
  }, [jumpToTranscriptMessage, scrollController, transcriptJump]);
  // Lines at the newest end of the transcript, beside the composer, where the
  // reader of a notification is looking. A jump never covers the room.
  const transcriptForwardLine =
    transcriptJump?.status === 'error' ? (
      <LedgerHistoryLine
        text="Couldn't locate message · tap to retry"
        onPress={retryTranscriptJump}
      />
    ) : transcriptJump?.status === 'missing' ? (
      <LedgerHistoryLine text="That message is no longer available" />
    ) : transcriptNewerStatus === 'error' ? (
      <LedgerHistoryLine
        text="Couldn't load later messages · tap to retry"
        onPress={retryNewerTranscriptMessages}
      />
    ) : transcriptNewerStatus === 'loading' ? (
      <LedgerHistoryLine text="Loading later messages…" />
    ) : null;
  const transcriptHistoryLine =
    transcriptHistoryStatus === 'loading' ? (
      <LedgerHistoryLine text="Loading earlier messages…" />
    ) : transcriptHistoryStatus === 'error' ? (
      <LedgerHistoryLine
        text="Couldn't load earlier messages · tap to retry"
        onPress={retryOlderTranscriptMessages}
      />
    ) : transcriptHistoryStatus === 'complete' ? (
      <LedgerHistoryLine text={isCorner ? 'Beginning of corner' : `Beginning of ${ROOM_LABEL}`} />
    ) : null;
  const rawAvailableAgents = useMemo(
    () =>
      (roomSurface?.members ?? [])
        .filter((member) => member.identity.kind === 'agent')
        .map((member) =>
          memberAgent(
            {
              ...member,
              identity: conversationIdentities.get(member.identity.pubkey) ?? member.identity,
            },
            roomSurface?.room.workspaceId ?? '',
          ),
        ),
    [conversationIdentities, roomSurface?.members, roomSurface?.room.workspaceId],
  );
  const availableAgents = useStable(rawAvailableAgents, (previous, next) =>
    previous.length === next.length &&
    previous.every((agent, index) => shallowEqualRecord(agent, next[index]!)),
  );
  const rawAvailablePeople = useMemo(
    () =>
      (roomSurface?.members ?? [])
        .filter((member) => member.identity.kind === 'human')
        .map((member) => ({
          pubkey: member.identity.pubkey,
          role: member.role,
          identity: conversationIdentities.get(member.identity.pubkey) ?? member.identity,
        })),
    [conversationIdentities, roomSurface?.members],
  );
  const availablePeople = useStable(rawAvailablePeople, sameSelectedMembers);
  const selectedMembersRaw = useMemo(
    () =>
      (roomSurface?.members ?? []).map((member) => {
        const identity = conversationIdentities.get(member.identity.pubkey) ?? member.identity;
        return {
          pubkey: identity.pubkey,
          role: member.role,
          kind: identity.kind,
          identity: {
            kind: identity.kind,
            displayName: identity.name,
            handle: identity.handle,
          },
        };
      }),
    [conversationIdentities, roomSurface?.members],
  );
  // The membership projection rebuilds every wrapper object on each snapshot
  // commit. Downstream memos (memberOptions, roomParticipants) and ultimately
  // renderItem's dependency array only care about the VALUE, so preserve the
  // previous reference until a member/role/identity actually moved.
  const selectedMembers = useStable(selectedMembersRaw, sameSelectedMembers);
  const roomMembers = useMemo(
    () => selectedMembers.map((member) => ({ pubkey: member.pubkey, role: member.role })),
    [selectedMembers],
  );
  const roomMemberPubkeys = useMemo(
    () => new Set<string>(roomMembers.map((member) => member.pubkey)),
    [roomMembers],
  );
  // Only message text shapes the lexicon, so a presence tick that rebuilds the
  // message array does not re-prime the recogniser.
  const speechMessageText = useStable(
    durableMessages
      .filter((message) => !message.isSystemNotice && !message.deleted)
      .map((message) => message.text),
    sameElementRefs,
  );
  const speechHints = useMemo(
    () =>
      buildSpeechLexicon({
        roomName: resolvedChannelName,
        parentRoomName: roomSurface?.parent?.name,
        repositoryName: roomSurface?.repository?.name,
        memberNames: selectedMembers.map((member) => member.identity.displayName),
        memberHandles: selectedMembers.map((member) => member.identity.handle),
        messages: speechMessageText,
      }),
    [
      resolvedChannelName,
      roomSurface?.parent?.name,
      roomSurface?.repository?.name,
      selectedMembers,
      speechMessageText,
    ],
  );
  const rawPersonProfiles = useMemo(
    () =>
      (roomSurface?.members ?? [])
        .filter((member) => member.identity.kind === 'human')
        .map((member) => {
          const identity = conversationIdentities.get(member.identity.pubkey) ?? member.identity;
          return {
            pubkey: identity.pubkey,
            name: identity.name,
            ...(identity.handle ? { handle: identity.handle } : {}),
            ...(identity.avatar ? { avatar: identity.avatar } : {}),
            ...(identity.face ? { face: identity.face } : {}),
          };
        }),
    [conversationIdentities, roomSurface?.members],
  );
  const personProfiles = useStable(rawPersonProfiles, (previous, next) =>
    previous.length === next.length &&
    previous.every((profile, index) => shallowEqualRecord(profile, next[index]!)),
  );
  const participantsHydrated = roomSurface !== null;
  const agentByPubkey = useMemo(
    () => new Map(availableAgents.map((agent) => [agent.pubkey, agent])),
    [availableAgents],
  );
  const personProfileByPubkey = useMemo(
    () => new Map(personProfiles.map((profile) => [profile.pubkey, profile])),
    [personProfiles],
  );
  const memberOptions = useMemo<RoomMemberOption[]>(() => {
    const options = new Map<string, RoomMemberOption>();
    // The viewer, always and first. `availablePeople` is a Workspace roster
    // read; until it lands (or if it comes back partial) the reader was absent
    // from their own Room's participant list, because a roster entry is what
    // the list is built from. A later real entry overwrites this one.
    if (userPubkey) {
      const selfProfile = personProfileByPubkey.get(userPubkey);
      options.set(userPubkey, {
        pubkey: userPubkey,
        // The viewer is named like every other speaker; brass on the name is
        // the one thing that marks them (DESIGN.md).
        name: selfProfile?.name ?? fallbackMemberName(userPubkey),
        handle: selfProfile?.handle ?? fallbackMemberHandle(userPubkey),
        kind: 'person',
      });
    }
    for (const person of availablePeople) {
      const fallbackName = fallbackMemberName(person.pubkey);
      const profile = personProfileByPubkey.get(person.pubkey);
      options.set(person.pubkey, {
        pubkey: person.pubkey,
        name: profile?.name ?? fallbackName,
        handle: person.identity.handle ?? profile?.handle ?? fallbackMemberHandle(person.pubkey),
        kind: 'person',
        ...(person.identity.face ? { face: person.identity.face } : {}),
      });
    }
    for (const agent of availableAgents) {
      const display = resolveAgentDisplayIdentity(agent.pubkey, agent);
      options.set(agent.pubkey, {
        pubkey: agent.pubkey,
        name: display.name,
        handle: display.handle,
        kind: 'agent',
        agent,
      });
    }
    // The snapshot membership selector is the Room roster authority. Workspace
    // People and Agent reads only enrich/classify those keys, and can be partial
    // or stale. Any member absent from both secondary reads remains visible as
    // a person-shaped identity instead of disappearing from the count.
    for (const member of selectedMembers) {
      if (options.has(member.pubkey)) continue;
      const fallbackName = fallbackMemberName(member.pubkey);
      const profile = personProfileByPubkey.get(member.pubkey);
      options.set(member.pubkey, {
        pubkey: member.pubkey,
        name: profile?.name ?? fallbackName,
        handle: member.identity?.handle ?? profile?.handle ?? fallbackMemberHandle(member.pubkey),
        kind: 'person',
      });
    }
    return [...options.values()].sort((a, b) => {
      if (a.pubkey === userPubkey) return -1;
      if (b.pubkey === userPubkey) return 1;
      return a.name.localeCompare(b.name);
    });
  }, [
    availableAgents,
    availablePeople,
    personProfileByPubkey,
    roomMembers,
    selectedMembers,
    userPubkey,
  ]);
  const roomParticipants = useMemo(
    () =>
      selectedMembers.map((member) => {
        const known = memberOptions.find((option) => option.pubkey === member.pubkey);
        if (known) return known;
        const name = member.identity?.displayName ?? member.identity?.handle;
        return {
          pubkey: member.pubkey,
          name: name ?? fallbackMemberName(member.pubkey),
          handle: member.identity?.handle ?? fallbackMemberHandle(member.pubkey),
          kind: member.kind === 'agent' ? 'agent' : 'person',
          ...(member.kind === 'agent' && agentByPubkey.get(member.pubkey)
            ? { agent: agentByPubkey.get(member.pubkey) }
            : {}),
        } satisfies RoomMemberOption;
      }),
    [agentByPubkey, memberOptions, selectedMembers, userPubkey],
  );
  // The picker's candidates are the WORKSPACE roster minus this Room's
  // members. The old picker filtered this Room's own member list, so its
  // "add" section was always empty and the only visible path led to the
  // pairing command (captain report C74). The transcript paints the shared
  // `/workspace/:id` entry, so Members, profile receipts and settings reach
  // every byline at once. It reads the roster on entry so every agent byline
  // can name its model, and again whenever the roster sheet or member picker
  // opens; the last roster stays visible until the fresh response lands.
  useEffect(() => {
    workspaceRosterScopeRef.current = null;
    setWorkspaceRoster(null);
    setWorkspaceRosterAddress(null);
    if (!activeCommunityId || !userPubkey) return;
    let cancelled = false;
    let stop: (() => void) | undefined;
    void (async () => {
      const address = surfaceAddress(await getEffectiveRelayUrl(), userPubkey, '/workspace/:id', {
        workspaceId: activeCommunityId,
      });
      if (cancelled) return;
      const paint = () => {
        if (!cancelled) setWorkspaceRoster(mobileSurfaceCache.peek(address, isWorkspaceView));
      };
      stop = mobileSurfaceCache.subscribe(address, paint);
      await mobileSurfaceCache.read(address, isWorkspaceView);
      paint();
      if (!cancelled) setWorkspaceRosterAddress(address);
    })().catch(() => undefined);
    return () => {
      cancelled = true;
      stop?.();
    };
  }, [activeCommunityId, userPubkey]);
  useEffect(() => {
    const rosterSurfaceVisible = participantPickerVisible || rosterVisible;
    if (!roomClient || !activeCommunityId || !workspaceRosterAddress) return;
    if (
      !shouldReadWorkspaceRoster({
        activeWorkspaceId: activeCommunityId,
        cachedWorkspaceId: workspaceRosterScopeRef.current,
        rosterSurfaceVisible,
      })
    )
      return;
    let cancelled = false;
    mobileSurfaceCache
      .fetch(workspaceRosterAddress, isWorkspaceView, () => roomClient.workspace(activeCommunityId))
      .then(() => {
        if (!cancelled) workspaceRosterScopeRef.current = activeCommunityId;
      })
      .catch((err) => {
        if (!cancelled && rosterSurfaceVisible)
          setMembershipError(`Could not read the Workspace roster: ${String(err)}`);
      });
    return () => {
      cancelled = true;
    };
  }, [activeCommunityId, participantPickerVisible, roomClient, rosterVisible, workspaceRosterAddress]);
  const participantPickerCandidates = useMemo<MemberPickerCandidate[] | null>(() => {
    if (!workspaceRoster) return null;
    return [...workspaceRoster.members, ...workspaceRoster.agents]
      .filter((member) => !roomMemberPubkeys.has(member.identity.pubkey))
      .map((member) => {
        const identity = member.identity;
        if (identity.kind === 'agent') {
          const display = resolveAgentDisplayIdentity(
            identity.pubkey,
            memberAgent(member, workspaceRoster.workspace.id),
          );
          return {
            pubkey: identity.pubkey,
            name: display.name,
            handle: display.handle,
            kind: 'agent' as const,
            ...(display.avatarUrl ? { avatarUrl: display.avatarUrl } : {}),
            ...(display.face ? { face: display.face } : {}),
          };
        }
        return {
          pubkey: identity.pubkey,
          name: identity.name,
          handle: identity.handle ?? fallbackMemberHandle(identity.pubkey),
          kind: 'person' as const,
          ...(identity.face ? { face: identity.face } : {}),
          ...(identity.avatar ? { avatarUrl: identity.avatar } : {}),
        };
      });
  }, [roomMemberPubkeys, workspaceRoster]);
  // Everyone of the listed kind in the Workspace besides the viewer, whether
  // or not they are already in this Room. An empty candidate list means two
  // different things — a Room that already holds them all, or a Workspace
  // with nobody else in it — and this count is what tells the sheet which
  // one to say (captain report C83).
  const participantPickerWorkspacePeers = useMemo(() => {
    if (!workspaceRoster) return 0;
    return [...workspaceRoster.members, ...workspaceRoster.agents].filter((member) => {
      if (member.identity.pubkey === userPubkey) return false;
      if (!participantPickerKind) return true;
      const kind = member.identity.kind === 'agent' ? 'agent' : 'person';
      return kind === participantPickerKind;
    }).length;
  }, [participantPickerKind, userPubkey, workspaceRoster]);
  // Agents carry their model and owner, people their Room role, for the
  // roster sheet and @-mention menu.
  /** Each agent's model as its Workspace profile holds it — the one source
   *  every agent byline reads, step rows and replies alike. */
  const agentProfileModelByPubkey = useStable(useMemo(
    () =>
      new Map(
        (workspaceRoster?.agents ?? []).flatMap((agent) =>
          agent.model ? [[agent.identity.pubkey, agent.model] as const] : [],
        ),
      ),
    [workspaceRoster],
  ), sameMessageRefMap);
  const describedRoomParticipants = useMemo(() => {
    const workspaceAgents = new Map(
      (workspaceRoster?.agents ?? []).map((agent) => [agent.identity.pubkey, agent]),
    );
    const roomRoles = new Map(roomMembers.map((member) => [member.pubkey, member]));
    return roomParticipants.map((participant) => {
      if (participant.kind !== 'agent') {
        const role = normalizedRoomRole(roomRoles.get(participant.pubkey));
        return role ? { ...participant, role } : participant;
      }
      const workspaceAgent = workspaceAgents.get(participant.pubkey);
      const ownerHandle = workspaceAgent?.owner?.handle;
      return {
        ...participant,
        ...(workspaceAgent?.model ? { model: workspaceAgent.model } : {}),
        ...(ownerHandle ? { ownerHandle } : {}),
      };
    });
  }, [roomMembers, roomParticipants, workspaceRoster]);
  const visibleRosterMembers = useMemo(
    () => orderRoomRoster(describedRoomParticipants),
    [describedRoomParticipants],
  );
  const roomParticipantTotal = roomParticipants.length;
  const roomAgents = useMemo(
    () => roomParticipants.filter((participant) => participant.kind === 'agent'),
    [roomParticipants],
  );
  // Room member handles: one backspace deletes a whole `@member` tag
  // (`buzz/composer-tags.ts`).
  const composerTagHandles = useMemo(
    () => roomComposerTagHandles(roomParticipants),
    [roomParticipants],
  );
  // kind:30078 is the sole delivery-availability truth. Transcript/activity
  // events can describe work, but they never mint or renew availability.
  const agentPresences = heartbeatPresences;
  const roomMemberByPubkey = useMemo(
    () =>
      new Map<string, (typeof roomMembers)[number]>(
        roomMembers.map((member) => [member.pubkey, member]),
      ),
    [roomMembers],
  );
  const mentionableAgents = useMemo(
    () =>
      activeMentionCandidates(
        roomParticipants
          .filter((participant) => participant.kind === 'agent')
          .map((participant) => ({
            pubkey: participant.pubkey,
            name: participant.name,
            handle: participant.handle,
          })),
        agentPresences,
        presenceNow,
      ),
    [roomParticipants, agentPresences, presenceNow],
  );
  const activeMention = useMemo(
    () =>
      inputSelection.start === inputSelection.end
        ? activeMentionAtCursor(inputText, inputSelection.start)
        : null,
    [inputSelection.end, inputSelection.start, inputText],
  );
  const mentionMenuKey = activeMention
    ? `${inputText}:${activeMention.start}:${activeMention.end}`
    : null;
  const mentionCandidateRoster = useMemo(
    () => [CHANNEL_MENTION_OPTION, ...describedRoomParticipants, SYSTEM_MENTION_OPTION],
    [describedRoomParticipants],
  );
  const mentionSuggestions = useMemo(
    () =>
      activeMention
        ? filterMentionCandidates(
            activeMentionCandidates(mentionCandidateRoster, agentPresences, presenceNow),
            activeMention.query,
          )
        : { matches: [], overflow: 0 },
    [activeMention, mentionCandidateRoster, agentPresences, presenceNow],
  );
  const mentionMenuVisible = Boolean(
    composerFocused &&
    mentionMenuKey &&
    mentionMenuKey !== dismissedMentionKey &&
    mentionSuggestions.matches.length > 0,
  );
  const activeChannel = useMemo(
    () =>
      inputSelection.start === inputSelection.end
        ? activeChannelAtCursor(inputText, inputSelection.start)
        : null,
    [inputSelection.end, inputSelection.start, inputText],
  );
  const channelMenuKey = activeChannel
    ? `#${inputText}:${activeChannel.start}:${activeChannel.end}`
    : null;
  // The current Room's open corners from its corner record, held once the
  // first `#` opens the menu; frames keep it current from then on.
  const channelCornerRoomId = isDirectMessage ? null : (parentChannelId ?? decodedId);
  const [channelCornersRoomId, setChannelCornersRoomId] = useState<string | null>(null);
  useEffect(() => {
    if (activeChannel && channelCornerRoomId && roomClient) setChannelCornersRoomId(channelCornerRoomId);
  }, [activeChannel, channelCornerRoomId, roomClient]);
  const channelCornerRecord = useRoomCorners(
    channelCornersRoomId === channelCornerRoomId ? (channelCornerRoomId ?? undefined) : undefined,
    roomClient,
  );
  const channelCorners = useMemo(() => {
    const view = channelCornerRecord.view;
    if (!view || !channelCornerRecord.record) return null;
    return {
      roomId: view.room.id,
      room: { name: view.room.name },
      corners: roomOpenCornerRows(channelCornerRecord.record).map((item) => ({
        id: item.corner.id,
        name: item.corner.name,
      })),
    };
  }, [channelCornerRecord.record, channelCornerRecord.view]);
  const channelSuggestions = useMemo(() => {
    if (!activeChannel) return { matches: [], overflow: 0 };
    const corners = channelCorners?.roomId === channelCornerRoomId ? channelCorners : null;
    return filterChannelSuggestions(
      channelSuggestionCandidates(
        workspaceChats
          .filter((item) => !item.directMessage)
          .map((item) => ({
            id: item.room.id,
            name: item.room.name,
            repositoryName: item.repositoryName,
          })),
        corners?.room ?? null,
        corners?.corners ?? [],
      ),
      activeChannel.query,
    );
  }, [activeChannel, channelCorners, channelCornerRoomId, workspaceChats]);
  const channelMenuVisible = Boolean(
    composerFocused &&
    channelMenuKey &&
    channelMenuKey !== dismissedMentionKey &&
    channelSuggestions.matches.length > 0,
  );
  const suggestionCount = mentionMenuVisible
    ? mentionSuggestions.matches.length
    : channelMenuVisible
      ? channelSuggestions.matches.length
      : 0;
  // The latest signed lifecycle receipt is server-indexed. Draft/thought
  // overlays carry content only and can neither start nor extend a turn.
  const agentTurnMarkers = useMemo(
    () => roomSurface?.latestAgentTurns ?? [],
    [roomSurface?.latestAgentTurns],
  );
  // Every agent answering right now, not just the first: two agents asked in
  // one message run two concurrent turns and each owns its own live lane.
  const rawActiveAgentTurns = useMemo(
    () =>
      agentTurnMarkers.filter((turn) =>
        isAgentTurnActive(
          turn,
          agentPresences[turn.agentPubkey],
          presenceNow,
          presenceReconnectGrace[turn.agentPubkey],
        ),
      ),
    [agentTurnMarkers, agentPresences, presenceNow, presenceReconnectGrace],
  );
  // A filter rebuilds its array on every presence tick even when it selected
  // the same receipts, and this feeds the transcript projection.
  const activeAgentTurns = useStable(rawActiveAgentTurns, sameElementRefs);
  // The composer's thinking line and its settled summary are ONE line, so they
  // read the first of them; the transcript and the gold ring take them all.
  const activeAgentTurn = activeAgentTurns[0];
  const messages = unprojectedMessages;
  const directMessageListItem = useMemo(
    () => workspaceChats.find((item) => item.room.id === decodedId && item.directMessage) ?? null,
    [decodedId, workspaceChats],
  );
  const memberManagement = roomMemberManagementState({
    isDirectMessage,
    participantsHydrated,
    rosterRequested: rosterVisible,
    pickerRequested: participantPickerVisible,
  });
  // An @system notification DM (release or Workspace lifecycle): the server
  // never lets anyone but @system post into it (viewer.permissions.send is
  // false there and only there for a direct message, since a DM can never be
  // archived).
  const isReadOnlyDirectMessage = isDirectMessage && roomSurface?.viewer.permissions.send === false;
  // Only a win can make the GitHub star card due (the server counts the
  // milestone): an agent reply carrying files, or the viewer's own 👍. The
  // card is asked for once per visit and again only after such a win.
  const starPromptKey = useMemo(() => {
    const messages = roomSurface?.messages ?? [];
    const artifacts = messages.filter(
      (message) =>
        message.author.kind === 'agent' &&
        message.presentation === 'message' &&
        (message.attachments?.length ?? 0) > 0,
    ).length;
    const thumbs = messages.filter((message) =>
      message.reactions?.some((reaction) => reaction.emoji === '👍' && reaction.reacted),
    ).length;
    return `${artifacts}:${thumbs}`;
  }, [roomSurface?.messages]);
  const starPrompt = useStarPrompt(starPromptKey, Boolean(roomSurface) && !isReadOnlyDirectMessage);
  useFocusEffect(useCallback(() => {
    const humanUi = roomSurface?.boundApp?.manifest.humanUi;
    if (!isFocused() || !isCorner || !humanUi) return;
    router.replace({
      pathname: '/beeline/corner-app/[slug]',
      params: { slug: roomSurface.boundApp!.manifest.slug, roomId: decodedId },
    } as Href);
  }, [decodedId, isCorner, isFocused, roomSurface?.boundApp]));
  const currentSlashQuery = useMemo(() => slashVerbQuery(inputText), [inputText]);
  // Mention-scoped palette: `@agent /query` addresses THAT agent's advertised
  // commands. Mutually exclusive with `currentSlashQuery` by shape — the plain
  // path requires the WHOLE composer to be one slash token.
  const mentionSlash = useMemo(() => agentMentionSlashQuery(inputText), [inputText]);
  const mentionSlashAgentPubkey = useMemo(() => {
    if (!mentionSlash) return null;
    return mentionedAgentPubkey(`@${mentionSlash.mention}`, mentionableAgents) ?? null;
  }, [mentionSlash, mentionableAgents]);
  const mentionAgentCommandScope = mentionSlashAgentPubkey
    ? `${decodedId}:${viewerPubkey}:${mentionSlashAgentPubkey}`
    : null;
  const mentionAgentCommands = useMemo(() => {
    if (!mentionSlash || !mentionAgentCommandScope) return [];
    const published = agentCommandsByScope[mentionAgentCommandScope];
    return availableAgentMentionCommands(
      published ?? [],
      mentionSlash.query,
      agentFastModeByScope[mentionAgentCommandScope],
      agentCanLoginByScope[mentionAgentCommandScope],
    );
  }, [agentCommandsByScope, agentFastModeByScope, agentCanLoginByScope, mentionAgentCommandScope, mentionSlash]);
  // True only once the read RESOLVED (absent or empty list): an in-flight or
  // failed read is unknown, never "does not advertise".
  const mentionAgentLacksCommands = Boolean(
    mentionSlash &&
    mentionSlashAgentPubkey &&
    mentionAgentCommandScope &&
    agentCommandsByScope[mentionAgentCommandScope] !== undefined &&
    (agentCommandsByScope[mentionAgentCommandScope]?.length ?? 0) === 0,
  );
  const cornerAppCommands = useMemo(() => {
    if (currentSlashQuery === null) return [];
    return availableCornerAppCommands(roomSurface?.cornerApps ?? [], currentSlashQuery);
  }, [currentSlashQuery, roomSurface?.cornerApps]);
  const pendingCornerRequest = useMemo(() => {
    for (let index = combinedMessages.length - 1; index >= 0; index -= 1) {
      const message = combinedMessages[index];
      if (
        message.writePermission?.status === 'pending' &&
        message.writePermission.repository &&
        message.writePermission.purpose !== 'squire-spending'
      ) {
        return message;
      }
    }
    return undefined;
  }, [combinedMessages]);
  const pendingTargetBranchProposal = useMemo(() => {
    for (let index = combinedMessages.length - 1; index >= 0; index -= 1) {
      const message = combinedMessages[index];
      if (
        message.targetBranchProposal &&
        roomRepository?.targetBranch !== message.targetBranchProposal.to
      ) {
        return message;
      }
    }
    return undefined;
  }, [combinedMessages, roomRepository?.targetBranch]);
  // Load the addressed agent's published command list on demand — the palette
  // combines this record with server-authorized Beeline actions. A
  // failed read stays unknown and never blocks typing.
  useEffect(() => {
    const pubkey = mentionSlashAgentPubkey;
    const scope = mentionAgentCommandScope;
    if (!pubkey || !scope || !roomClient || !activeCommunityId) return;
    if (agentCommandsByScope[scope] !== undefined && agentFastModeByScope[scope] !== undefined && agentCanLoginByScope[scope] !== undefined) {
      return;
    }
    let cancelled = false;
    roomClient
      .agent(activeCommunityId, pubkey)
      .then((detail) => {
        if (!cancelled) {
          setAgentCommandsByScope((current) => ({
            ...current,
            [scope]: detail.commands ?? [],
          }));
          setAgentCanLoginByScope((current) => ({ ...current, [scope]: detail.canLogin === true }));
          setAgentFastModeByScope((current) => ({
            ...current,
            [scope]: fastModeCommandState(detail, viewerPubkey),
          }));
        }
      })
      .catch(() => {
        // A transport failure is not evidence that no record exists. Keep the
        // scope unresolved so the palette never makes a false absence claim.
      });
    return () => {
      cancelled = true;
    };
  }, [
    activeCommunityId,
    agentCommandsByScope,
    agentFastModeByScope,
    agentCanLoginByScope,
    decodedId,
    mentionAgentCommandScope,
    mentionSlashAgentPubkey,
    roomClient,
    viewerPubkey,
  ]);
  // Re-read owner actions each time the palette opens so profile changes
  // cannot leave an earlier permission or toggle state on screen.
  useEffect(() => {
    if (mentionSlashAgentPubkey) return;
    setAgentFastModeByScope((current) => (Object.keys(current).length ? {} : current));
    setAgentCanLoginByScope((current) => (Object.keys(current).length ? {} : current));
  }, [mentionSlashAgentPubkey]);
  // `null` means "show a skeleton": the channel kind or its name is still
  // resolving and no honest word exists yet. A corner never renders the Room
  // label as a stand-in for its own slug.
  // The parent Room's STORED name, for a corner's `#<room>/<corner>` header.
  // Read from the same Room-list cache the reference resolver uses — never a
  // second index. `undefined` = not a corner; `null` = corner whose parent
  // name has not landed yet (the header degrades to `#<corner>`, it does not
  // block on another read).
  const parentRoomName = useMemo(() => {
    if (!parentChannelId) return undefined;
    const parent = roomSurface?.parent;
    return parent?.name?.trim() ? parent.name : null;
  }, [parentChannelId, roomSurface?.parent]);
  const headerTitle = channelHeaderTitle(
    resolvedChannelName,
    isCorner ? 'corner' : channelKind,
    decodedId,
    {
      directMessage: isDirectMessage,
      parentRoomName,
    },
  );
  // Room-lifecycle copy ("Delete <name>?"), rename drafts, and cache writes
  // use the STORED name — the `#` mark is display-only and must never leak
  // into a mutation path. The header renders through `headerTitle` instead.
  const roomName = headerTitle ?? ROOM_LABEL;
  const storedRoomName = resolvedChannelName?.trim() || ROOM_LABEL;
  // A DM's title is its peer's identity. Derived from cached state rather
  // than resolved inside the enter-room fetch chain, so it is right on the
  // first painted frame of a warm cache instead of several server reads later.
  // Deliberately not `directMessagePeer`, which throws when the viewer is not
  // a participant — a throw here would be a render-time crash, not a bad title.
  const dmPeerPubkey = userPubkey
    ? directMessage?.participants.find((pubkey) => pubkey !== userPubkey)
    : undefined;
  const dmPeerProfile = dmPeerPubkey ? personProfileByPubkey.get(dmPeerPubkey) : undefined;
  const dmPeerIdentity = dmPeerPubkey
    ? (roomSurface?.members.find((member) => member.identity.pubkey === dmPeerPubkey)?.identity ??
      directMessageListItem?.directMessage?.peer)
    : undefined;
  const dmPeerAgent = dmPeerPubkey ? agentByPubkey.get(dmPeerPubkey) : undefined;
  const dmPeerAgentDisplay =
    dmPeerPubkey && dmPeerAgent
      ? resolveAgentDisplayIdentity(dmPeerPubkey, dmPeerAgent)
      : undefined;
  const dmPeerPresence = directMessageHeaderPresence(
    directMessageListItem?.room.id === decodedId ? directMessageListItem : null,
    presenceNow,
  );
  const dmPeerWorkspaceAgent = dmPeerPubkey
    ? workspaceRoster?.agents.find((agent) => agent.identity.pubkey === dmPeerPubkey)
    : undefined;
  const dmHeaderPresence =
    dmPeerAgent || dmPeerWorkspaceAgent
      ? directMessageAgentHeaderMeta(
          {
            model: dmPeerWorkspaceAgent?.model,
            ownerHandle: dmPeerWorkspaceAgent?.owner?.handle,
          },
          dmPeerPresence,
        )
      : dmPeerPresence;
  const dmAnnouncementAuthor = dmPeerPubkey
    ? roomSurface?.messages.find((message) => message.author.pubkey === dmPeerPubkey)?.author
    : undefined;
  const displayRoomName = useMemo(() => {
    if (!dmPeerPubkey) return roomName;
    // One title rule with the Room list row: `@<handle>` from the peer.
    if (dmPeerAgentDisplay) return directMessageTitle(dmPeerIdentity ?? dmPeerAgentDisplay);
    return directMessageTitle(
      directMessageHeaderIdentity(
        dmPeerIdentity,
        dmPeerProfile,
        dmPeerPubkey,
        isReadOnlyDirectMessage,
        dmAnnouncementAuthor,
      ),
    );
  }, [
    dmAnnouncementAuthor,
    dmPeerAgentDisplay,
    dmPeerIdentity,
    dmPeerProfile,
    dmPeerPubkey,
    isReadOnlyDirectMessage,
    roomName,
  ]);
  // The header's own title still distinguishes "not resolved yet" (`null` —
  // render the skeleton) from a resolved name. A DM is resolved as soon as its
  // peer is known, which the cached roster usually already answers.
  const displayHeaderTitle = dmPeerPubkey ? displayRoomName : headerTitle;
  const headerTitleKind: ChannelHeaderKind = isCorner ? 'corner' : dmPeerPubkey ? 'dm' : 'room';
  const emptyLedgerVariant: EmptyLedgerVariant = isCorner
    ? 'corner'
    : isDirectMessage
      ? 'dm'
      : 'room';
  const focusComposer = useCallback(() => {
    scheduleAnimationFrame(() => composerRef.current?.focus());
  }, []);
  // The first Room teaches by doing: each starter fills the live composer
  // (tagging the Room's first agent when there is one) or opens the invite.
  const firstRoomAgent = useMemo(
    () =>
      roomSurface?.members.find(
        (member) => member.identity.kind === 'agent' && Boolean(member.identity.handle),
      )?.identity,
    [roomSurface?.members],
  );
  // The one way anything but typing puts words in the composer: a starter
  // Starter prompts go through here, and `planComposerFill`
  // owns what that does to a draft somebody already started.
  const fillComposer = useCallback(
    (text: string, options: { mention?: ComposerMention; focusOnRefusal?: boolean } = {}) => {
      const plan = planComposerFill({ draft: inputTextRef.current, text, ...options });
      if (plan.focus) scheduleAnimationFrame(() => composerRef.current?.focus());
      if (!plan.fill) return false;
      if (plan.fill.mention) {
        selectedAgentMentionsRef.current.set(plan.fill.mention.handle, plan.fill.mention.pubkey);
        selectedMentionsRef.current.set(plan.fill.mention.handle, plan.fill.mention.pubkey);
      }
      inputTextRef.current = plan.fill.text;
      setInputText(plan.fill.text);
      setInputSelection(plan.fill.selection);
      return true;
    },
    [],
  );
  const startCornerMessage = useCallback(() => {
    const handle = firstRoomAgent?.handle?.replace(/^@/, '');
    if (!handle || !firstRoomAgent) return focusComposer();
    fillComposer(`@${handle} `, {
      mention: { handle, pubkey: firstRoomAgent.pubkey },
      focusOnRefusal: true,
    });
  }, [fillComposer, firstRoomAgent, focusComposer]);
  // The same minted pairing command the Room deck and the create wizard show,
  // in the same sheet: a Room with no agent has nobody to ask yet.
  const connectAgent = useCallback(async () => {
    if (!activeCommunityId || agentPairBusy || viewerIsAgent) return;
    setAgentConnectVisible(true);
    setAgentPairCommand(null);
    setAgentPairError(null);
    setAgentPairBusy(true);
    try {
      let pairingTransport = transport;
      if (!pairingTransport) {
        const identity = await loadBuzzIdentity();
        if (!identity) throw new Error('Beeline identity is unavailable');
        pairingTransport = new BuzzRigTransport(identity);
        setSessionTransport(pairingTransport);
      }
      const pairing = await (
        await pairingTransport.ensureClient()
      ).createAgentPairingCode(activeCommunityId);
      setAgentPairCommand(agentPairingCommand(pairing.code));
    } catch (reason) {
      setAgentPairError(`Could not create agent invite: ${String(reason)}`);
    } finally {
      setAgentPairBusy(false);
    }
  }, [activeCommunityId, agentPairBusy, setSessionTransport, transport, viewerIsAgent]);
  const closeAgentConnect = useCallback(() => {
    setAgentConnectVisible(false);
    setAgentPairCommand(null);
    setAgentPairError(null);
  }, []);
  const copyPairCommand = useCallback(async (command: string) => {
    await Clipboard.setStringAsync(command);
  }, []);
  const starterPromptDefs = useMemo(() => {
    if (emptyLedgerVariant !== 'room' || viewerIsAgent || !roomSurface?.viewer.permissions.send)
      return undefined;
    return roomStarterPrompts({
      roomAgent: firstRoomAgent,
      workspaceAgentCount: workspaceRoster ? workspaceRoster.agents.length : null,
      canManageWorkspace,
      workspaceName: workspaceRoster?.workspace.name,
    });
  }, [
    canManageWorkspace,
    emptyLedgerVariant,
    firstRoomAgent,
    roomSurface?.viewer.permissions.send,
    viewerIsAgent,
    workspaceRoster,
  ]);
  const starterIntro = starterPromptDefs ? roomStarterIntro(starterPromptDefs) : undefined;
  const starterPrompts = useMemo(() => {
    if (!starterPromptDefs) return undefined;
    return starterPromptDefs.map((prompt) => ({
      lead: prompt.lead,
      detail: prompt.detail,
      testID: prompt.testID,
      onPress: () => {
        if (prompt.action.kind === 'fill')
          fillComposer(prompt.action.text, {
            mention: prompt.action.mention,
            focusOnRefusal: true,
          });
        else if (prompt.action.kind === 'add-room-agent') {
          setMembershipError(null);
          setParticipantPickerKind('agent');
          setParticipantPickerVisible(true);
        } else if (prompt.action.kind === 'connect-agent') void connectAgent();
        else
          router.push({
            pathname: '/beeline/members',
            params: {
              ...(activeCommunityId ? { communityId: activeCommunityId } : {}),
              action: 'invite',
            },
          } as never);
      },
    }));
  }, [activeCommunityId, connectAgent, fillComposer, starterPromptDefs]);
  // The transcript is the composer's "outside": a tap on it puts the keyboard
  // away, the same as a drag (keyboardDismissMode on the list below). Kept
  // dependency-free so it never re-creates renderItem — see the memo note on
  // renderMessage.
  const dismissComposerKeyboard = useCallback(() => {
    Keyboard.dismiss();
  }, []);
  // The header reads this corner's row from the parent Room's corner record,
  // the same row the Corners screen and Room list paint. Live turns pick the
  // name and ring below; they never pick the state.
  const cornerHeaderSource = useCornerHeaderItem(
    isCorner ? (parentChannelId ?? undefined) : undefined,
    decodedId,
    isArchived,
    roomClient,
  );
  const cornerHeaderDisplay = cornerHeaderSource ? cornerDisplayState(cornerHeaderSource) : undefined;
  const cornerAgentPubkey = useMemo(
    () =>
      resolveCornerViewAgentPubkey(
        messages,
        (pubkey) => agentByPubkey.has(pubkey),
        roomSurface?.cornerOpenerAgentId,
      ),
    [agentByPubkey, messages, roomSurface?.cornerOpenerAgentId],
  );
  const rawSpeakerWorking = useMemo(
    () =>
      selectWorkingAgents({
        activeTurnPubkeys: activeAgentTurns.map((turn) => turn.agentPubkey),
      }),
    [activeAgentTurns],
  );
  const speakerWorking = useStable(rawSpeakerWorking, shallowEqualRecord);
  // The corner header names the opener from `corner_facts.owner_agent_id`, never
  // whichever agent currently holds a live turn. While a reviewer works in
  // the corner the transcript attribution is the reviewer's and stays there;
  // the corner does not change hands. The transcript-derived identity fills
  // in only before the server projection has landed. The gold ring on a
  // byline still names the actual worker (C77).
  const cornerHeaderAgentView = cornerHeaderAgent({
    ownerPubkey: cornerAgentPubkey,
    ...(cornerHeaderDisplay ? { status: cornerHeaderDisplay.status } : {}),
    ...(cornerHeaderDisplay?.headerSuffix ? { headerSuffix: cornerHeaderDisplay.headerSuffix } : {}),
    activeTurnPubkeys: activeAgentTurns.map((turn) => turn.agentPubkey),
  });
  const cornerOwnerPubkey = cornerHeaderAgentView.pubkey;
  const cornerOwnerDisplay = cornerOwnerPubkey
    ? resolvePendingAgentDisplay(
        cornerOwnerPubkey,
        agentByPubkey.get(cornerOwnerPubkey),
        participantsHydrated,
      )
    : undefined;
  const cornerHeaderWord = cornerHeaderAgentView.stateWord;
  const cornerOwnerWorking = cornerHeaderAgentView.ownerWorking;
  const visibleMessages = useMemo(
    () => projectActiveTurnStream(messages, activeAgentTurns, isArchived).map((message) => {
      const id = message.relayId ?? message.id;
      if (optimisticDeletes[id])
        return { ...message, text: 'Deleting message…', deleted: true, isSystemNotice: true };
      const reactions = optimisticReactions[id];
      return reactions ? { ...message, reactions } : message;
    }),
    [activeAgentTurns, isArchived, messages, optimisticDeletes, optimisticReactions],
  );
  // Run boundaries still control compact continuation spacing and machine-row
  // folding. Ordinary prose always renders its own byline, even inside a run,
  // so every message remains independently attributable.
  const rawContinuedAttributionIds = useMemo(
    () =>
      new Set(
        continuedSpeakerIds(
          visibleMessages.map((message) => ({
            id: message.id,
            speaker: ledgerSpeakerKey(message, knownAgentPubkeysFor(agentByPubkey)),
            // A collapsed tool/thought run is mechanism, not prose: it may fold
            // into the voice above it, but the prose below it must re-announce
            // (its byline was never allowed to be spent on the tool block).
            isMachine: message.isAgentActivity,
            // A reply always re-announces its own speaker; see
            // `continuedSpeakerIds`'s `hasReplyReference` doc.
            hasReplyReference: Boolean(message.replyToId),
          })),
        ),
      ),
    [agentByPubkey, visibleMessages],
  );
  // renderItem consumes this set; preserve its identity across commits that
  // did not change any run boundary so rows are not rebuilt for nothing.
  const continuedAttributionIds = useStable(rawContinuedAttributionIds, sameStringSet);
  // Native keeps the established inverted list. React Native Web implements
  // `inverted` with scale transforms, which can leave variable-height rows at
  // stale coordinates after a send. Every desktop-platform transcript uses
  // ordinary chronological flow, including a packaged Windows window resized
  // below the persistent-sidebar breakpoint.
  const desktopTranscript = desktopExperience;
  const invertedMessages = useMemo(() => [...visibleMessages].reverse(), [visibleMessages]);
  const transcriptMessages = desktopTranscript ? visibleMessages : invertedMessages;
  const showEmptyLedger = isCorner
    ? !viewerIsAgent && cornerNeedsStarter(transcriptMessages)
    : transcriptMessages.length === 0;
  const emptyLedger = showEmptyLedger ? (
    <View style={styles.emptyState}>
      <EmptyLedgerState
        variant={emptyLedgerVariant}
        name={isDirectMessage ? displayRoomName : isCorner ? undefined : roomName}
        agentHandle={isCorner ? firstRoomAgent?.handle : undefined}
        onPress={isCorner ? startCornerMessage : focusComposer}
        starterPrompts={starterPrompts}
        starterIntro={starterIntro}
      />
    </View>
  ) : null;
  // Landing retries can outlive the render that scheduled them. Read the
  // current inverted order so arrivals during measurement cannot shift the
  // durable boundary away from the numeric index we retry.
  const transcriptMessagesRef = useRef(transcriptMessages);
  transcriptMessagesRef.current = transcriptMessages;
  // A detached window fills with newer rows only once a pending landing has
  // landed, so the rows it measured stay where they are. It fills one page
  // per content size the list reports: the window turns idle before the list
  // measures the page it added, and a check in between reads the old short
  // height and would walk the window to the tail.
  const detachedFillMeasuredRef = useRef(true);
  const fillShortTranscript = useCallback(() => {
    if (anchoredSegmentActive) {
      if (scrollController.isLanding() || !detachedFillMeasuredRef.current) return;
      detachedFillMeasuredRef.current = false;
    }
    fillTranscript(visibleTranscriptWindow(foldedMessages, Number.MAX_SAFE_INTEGER).length);
  }, [anchoredSegmentActive, fillTranscript, foldedMessages, scrollController]);
  // A held jump landing keeps its distance from the oldest end of the phone
  // content while newer rows grow it at the newest end (native offset 0).
  // Native lists keep a visible row in place, but not while the content is
  // shorter than the list; React Native Web never does.
  const phoneContentHeightRef = useRef(0);
  const phoneScrollOffsetRef = useRef(0);
  const heldLandingFromOldestRef = useRef(0);
  // Only a window shorter than the list grows by newer rows after its
  // landing (the short-list fill). A window that fills the list grows only
  // at its oldest end, as the list draws rows above the target, and the
  // native offset keeps the target in place by itself.
  const phoneListHeightRef = useRef(0);
  const heldLandingShortRef = useRef(false);
  const holdPhoneLanding = (height: number) => {
    phoneContentHeightRef.current = height;
    if (!scrollController.isHoldingLanding() || !heldLandingShortRef.current) return;
    const offset = Math.max(0, height - heldLandingFromOldestRef.current);
    if (Math.abs(offset - phoneScrollOffsetRef.current) > 1) scrollController.holdLanding(offset);
  };
  // The fill waits for the Room connection: the store drops a page request
  // made without one, and nothing else would re-check a short saved copy.
  const phoneUnderfill = usePhoneUnderfillHistory({
    enabled:
      !desktopTranscript &&
      transcriptMessages.length > 0 &&
      Boolean(roomClient) &&
      Boolean(cacheViewerPubkey),
    status: transcriptFillStatus,
    historyRevision: visibleMessageCount,
    threshold: TAIL_PIN_THRESHOLD,
    fill: fillShortTranscript,
  });
  // A page that folds into rows already shown changes no height, so no size
  // report reopens the detached fill. Two frames after the window's rows
  // change, the list has reported any new height; without one, the height it
  // holds is current, so the fill checks it again.
  const observeUnderfillContentHeight = phoneUnderfill.observeContentHeight;
  useEffect(() => {
    if (desktopTranscript || !anchoredSegmentActive || detachedFillMeasuredRef.current) return;
    let second: number | false = false;
    const first = scheduleAnimationFrame(() => {
      second = scheduleAnimationFrame(() => {
        if (detachedFillMeasuredRef.current || phoneContentHeightRef.current <= 0) return;
        detachedFillMeasuredRef.current = true;
        observeUnderfillContentHeight(phoneContentHeightRef.current);
      });
    });
    return () => {
      if (first !== false) cancelScheduledAnimationFrame(first);
      if (second !== false) cancelScheduledAnimationFrame(second);
    };
  }, [anchoredSegmentActive, desktopTranscript, observeUnderfillContentHeight, transcriptMessages]);
  // The read cursor ranks rows by index to decide which is newest, so it reads
  // the chronological order for the same reason the jump control does: on the
  // phone `transcriptMessages` IS the reversed list, and ranking that array
  // picks the oldest visible row and reads a scroll back up as progress.
  const chronologicalMessagesRef = useRef(visibleMessages);
  chronologicalMessagesRef.current = visibleMessages;
  // The composer offers an agent's handle as visible, deletable text: on a
  // quote-reply, and when the newest message is that agent's answer to the
  // viewer, or before a first message to a sole agent member. Each candidate
  // is offered once (`buzz/composer-prefill.ts`).
  const composerPrefillRef = useRef<ComposerPrefill | null>(null);
  const offeredPrefillsRef = useRef(new Set<string>());
  const answerPrefill = useMemo(
    () =>
      viewerIsAgent || anchoredSegmentActive
        ? undefined
        : answerPrefillCandidate(
            visibleMessages,
            userPubkey,
            (message) =>
              message.authorIdentity?.handle ??
              (message.pubkey ? agentByPubkey.get(message.pubkey)?.handle : undefined),
            isDirectMessage ? undefined : {
              roomId: decodedId,
              agents: roomSurface?.members
                .filter((member) => member.identity.kind === 'agent')
                .map((member) => member.identity) ?? [],
              viewerIsAgent,
              humanCount: roomSurface?.members.filter((member) => member.identity.kind === 'human').length ?? 0,
            },
          ),
    [agentByPubkey, anchoredSegmentActive, decodedId, isDirectMessage, roomSurface?.members, userPubkey, viewerIsAgent, visibleMessages],
  );
  const answerPrefillRef = useRef(answerPrefill);
  answerPrefillRef.current = answerPrefill;
  const applyComposerPrefill = useCallback(
    (plan: ComposerPrefillPlan, agent?: { handle: string; pubkey: string }) => {
      if (plan.kind === 'keep') return;
      const text = plan.kind === 'fill' ? plan.text : '';
      composerPrefillRef.current = plan.kind === 'fill' ? plan.prefill : null;
      if (plan.kind === 'fill' && agent) {
        const handle = agent.handle.replace(/^@/, '');
        selectedAgentMentionsRef.current.set(handle, agent.pubkey);
        selectedMentionsRef.current.set(handle, agent.pubkey);
      }
      inputTextRef.current = text;
      setInputText(text);
      setInputSelection({ start: text.length, end: text.length });
    },
    [setInputText],
  );
  useEffect(() => {
    const candidate = answerPrefillRef.current;
    const plan = planAnswerPrefill({
      draft: inputTextRef.current,
      prefill: composerPrefillRef.current,
      candidate,
      offered: offeredPrefillsRef.current,
    });
    if (plan.kind === 'fill' && candidate) offeredPrefillsRef.current.add(candidate.sourceMessageId);
    applyComposerPrefill(plan, candidate);
  }, [answerPrefill?.sourceMessageId, applyComposerPrefill]);
  // The row the jump control exists to reach. Read from the chronological
  // order so the inverted phone list and the desktop list name the same row.
  const newestTranscriptMessageId = newestTranscriptRowId(visibleMessages);
  const newestArrivalMessageId = anchoredSegmentActive
    ? newestTranscriptRowId(arrivalMessages)
    : newestTranscriptMessageId;
  // Rooms use the unread divider and queue; corners use only the viewport-
  // driven jump control (`buzz/use-new-message-control.ts`).
  // The divider answers one question: where the reader's unread run began when
  // they opened this Room. The server's cursor owns that line until the newest
  // row is visible; a message arriving while the reader is in history belongs
  // to the control, not to that line. Binding the divider to the live queue
  // instead dragged it off the unread run and pinned it to whichever row had
  // just landed, which is the divider readers watched appear at the newest
  // message out of nowhere.
  const {
    discVisible: newestJumpDiscShown,
    badgeCount: newMessageBadgeCount,
    hasObservedVisibility: newMessageHasObservedVisibility,
    observeVisibleMessages,
    observeTailPinned,
  } = useNewMessageControl({
    unreadLine,
    roomId: decodedId,
    queueableMessages: arrivalMessages,
    arrivingIds: transcriptArrivalObservation.arrivingIds,
    newestMessageId: newestArrivalMessageId,
    isPinnedToTail: () => !anchoredSegmentActive && scrollController.isPinnedToTail(),
    enabled: !isCorner,
  });
  const slashVerbs = useMemo(
    () =>
      availableSlashVerbs(
        {
          canBuild: Boolean(
            !isCorner && !isDirectMessage && !viewerIsAgent && roomSurface?.viewer.permissions.send,
          ),
          canCreatePoll: Boolean(
            !isCorner && !isDirectMessage && !viewerIsAgent && roomSurface?.viewer.permissions.send,
          ),
          canManageSchedules: Boolean(
            !isCorner &&
            !viewerIsAgent &&
            (isDirectMessage ? Boolean(roomSurface?.viewer.permissions.send) : canManageWorkspace),
          ),
          canRunWorkflows: Boolean(
            !isCorner &&
            !isDirectMessage &&
            !viewerIsAgent &&
            canManageWorkspace &&
            roomSurface?.repositoryResolution === 'repository',
          ),
          canOpenCorner: Boolean(!isCorner && !viewerIsAgent && pendingCornerRequest),
          canRename: Boolean(!isCorner && !isDirectMessage && !viewerIsAgent && canManageWorkspace),
          canCloseCorner: isCorner && !viewerIsAgent,
          canChangeTargetBranch: Boolean(
            !isCorner &&
            !viewerIsAgent &&
            canManageWorkspace &&
            pendingTargetBranchProposal &&
            !targetBranchActionId,
          ),
          canAddAgent: Boolean(!isCorner && !isDirectMessage && !viewerIsAgent),
          canInvitePerson: Boolean(
            !isCorner && !isDirectMessage && !viewerIsAgent && canManageWorkspace,
          ),
        },
        currentSlashQuery ?? mentionSlash?.query ?? '',
      ),
    [
      currentSlashQuery,
      mentionSlash?.query,
      canManageWorkspace,
      isCorner,
      isDirectMessage,
      pendingCornerRequest,
      pendingTargetBranchProposal,
      targetBranchActionId,
      viewerIsAgent,
      roomSurface?.repositoryResolution,
      roomSurface?.viewer.permissions.send,
    ],
  );
  const slashMenuVisible = Boolean(
    composerFocused &&
    (currentSlashQuery !== null || (mentionSlash !== null && mentionSlashAgentPubkey !== null)) &&
    dismissedSlashText !== inputText,
  );
  const paletteItemCount =
    mentionAgentCommands.length + cornerAppCommands.length + slashVerbs.length;
  useEffect(() => {
    setHighlightedSlashVerbIndex(0);
  }, [currentSlashQuery, mentionSlash?.query, paletteItemCount]);
  // The desktop transcript's real scroll container and content node — a
  // plain scrollable View over real DOM (`shouldFollowDesktopTail` in
  // `buzz/room-scroll-follow.ts`), not React Native Web's FlatList/
  // VirtualizedList, whose own provisional layout accounting is the root
  // cause proof/desktop-append-overlap/NOTES.md traces eight prior scroll-
  // timing patches back to.
  const desktopScrollNodeRef = useRef<HTMLElement | null>(null);
  const desktopContentNodeRef = useRef<HTMLElement | null>(null);
  const desktopContentObserverRef = useRef<ResizeObserver | null>(null);
  // Row DOM nodes by message id, for id-based jumps (notification anchor,
  // unread boundary, artifact origin) and viewability — no index math, no
  // scrollToIndex failure/retry.
  const desktopRowNodesRef = useRef<Map<string, HTMLElement>>(new Map());
  const desktopVisibilityObserverRef = useRef<IntersectionObserver | null>(null);
  const desktopIntersectingIdsRef = useRef<Set<string>>(new Set());
  const desktopReadingAnchorRef = useRef<{ id: string; offset: number } | null>(null);
  const captureDesktopReadingAnchor = useCallback(() => {
    const node = desktopScrollNodeRef.current;
    desktopReadingAnchorRef.current = null;
    if (!node || scrollController.isPinnedToTail() || scrollController.isLanding()) return;
    const viewport = node.getBoundingClientRect();
    let firstTop = Infinity;
    for (const [id, row] of desktopRowNodesRef.current) {
      const bounds = row.getBoundingClientRect();
      if (bounds.bottom > viewport.top && bounds.top < viewport.bottom && bounds.top < firstTop) {
        firstTop = bounds.top;
        desktopReadingAnchorRef.current = { id, offset: bounds.top - viewport.top };
      }
    }
  }, [scrollController]);
  const restoreDesktopReadingAnchor = useCallback(() => {
    const node = desktopScrollNodeRef.current;
    const anchor = desktopReadingAnchorRef.current;
    const row = anchor ? desktopRowNodesRef.current.get(anchor.id) : undefined;
    if (node && row && anchor) {
      scrollController.holdReadingPosition(
        row.getBoundingClientRect().top - node.getBoundingClientRect().top - anchor.offset,
      );
    }
    captureDesktopReadingAnchor();
  }, [captureDesktopReadingAnchor, scrollController]);
  // The row a completed notification landing is pointing at, for as long as
  // the pointer plays. Cleared on its own timer, so the next landing on the
  // same row is a fresh false→true edge and a re-render is not.
  const [arrivalFlashMessageId, setArrivalFlashMessageId] = useState<string | null>(null);
  const arrivalFlashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // The row a settled message-source jump (a quote reference, a forward
  // source, a notification target) just centered. Same one-cycle timing as
  // the arrival pointer above, but its own brass tint — this is a reader
  // reaching for a specific message, not the passive "you arrived here" mark.
  const [sourceLandingFlashMessageId, setSourceLandingFlashMessageId] = useState<string | null>(
    null,
  );
  const sourceLandingFlashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const messageAnchorIdRef = useRef(messageAnchorId);
  messageAnchorIdRef.current = messageAnchorId;
  const sourceJumpSequenceRef = useRef(0);
  const handleOpenMessageSource = useCallback((roomId: string, messageId: string) => {
    sourceJumpSequenceRef.current += 1;
    router.navigate(
      messageJumpHref(roomId, messageId, `message-source:${sourceJumpSequenceRef.current}`),
    );
  }, []);
  const raiseArrivalFlash = useCallback((messageId: string) => {
    if (arrivalFlashTimerRef.current !== null) clearTimeout(arrivalFlashTimerRef.current);
    setArrivalFlashMessageId(messageId);
    arrivalFlashTimerRef.current = setTimeout(() => {
      arrivalFlashTimerRef.current = null;
      setArrivalFlashMessageId(null);
      // The cell reads the system setting itself; this timer only has to
      // outlast the longer of the two shapes it can take.
    }, arrivalFlashTiming(false).totalMs);
  }, []);
  const raiseSourceLandingFlash = useCallback((messageId: string) => {
    if (sourceLandingFlashTimerRef.current !== null)
      clearTimeout(sourceLandingFlashTimerRef.current);
    setSourceLandingFlashMessageId(messageId);
    sourceLandingFlashTimerRef.current = setTimeout(() => {
      sourceLandingFlashTimerRef.current = null;
      setSourceLandingFlashMessageId(null);
    }, arrivalFlashTiming(false).totalMs);
  }, []);
  useEffect(
    () => () => {
      if (arrivalFlashTimerRef.current !== null) clearTimeout(arrivalFlashTimerRef.current);
      if (sourceLandingFlashTimerRef.current !== null)
        clearTimeout(sourceLandingFlashTimerRef.current);
    },
    [],
  );
  useEffect(() => {
    scrollController.reset();
    desktopRowNodesRef.current.clear();
    desktopRowRefCallbacksRef.current.clear();
    desktopIntersectingIdsRef.current.clear();
    desktopReadingAnchorRef.current = null;
  }, [decodedId, scrollController]);
  // A message jump reaches its row by one scroll once the row is near the
  // newest end of the phone list, which draws only its first rows at once. A
  // row further up lands through a store window that keeps it near that end.
  // A row that is already shown lands now, even while a read for it is still
  // out; the landing ends that read.
  const messageJumpCanScrollTo = (messageId: string, index: number) =>
    desktopTranscript ||
    index < PHONE_FIRST_RENDER_ROWS ||
    (transcriptJump?.messageId === messageId &&
      (transcriptJump.status === 'ready' || transcriptJump.status === 'loading'));
  const observeVisibleTranscriptMessages = useCallback(
    ({ viewableItems }: { viewableItems: ViewToken<ChatDisplayMessage>[] }) => {
      const visibleRows = viewableItems
        .filter((token) => token.isViewable)
        .map((token) => token.item);
      transcriptPositions.observeVisibleRows(visibleRows);
      // The list recomputes viewability on scroll AND on every committed
      // update, so an arrival that lands below the fold reports itself unseen
      // without the reader touching anything.
      observeVisibleMessages(visibleRows);
      // The same report is what moves the read mark. A row that never entered
      // the viewport is never read, however far below it the transcript runs.
      // Chronological order, never `transcriptMessagesRef` — that one is
      // reversed on the phone, and the cursor ranks by index.
      advanceReadCursor(chronologicalMessagesRef.current, visibleRows);
      // A landing is done when this report shows its row; until then each
      // report scrolls to it again.
      scrollController.observeVisibleRows(visibleRows);
    },
    [advanceReadCursor, observeVisibleMessages, scrollController, transcriptPositions],
  );
  // The viewport pass above owns the read boundary, but it does not run when
  // an arrival only changes which row is NEWEST while the list already rests
  // at the tail — the same stale report `useNewMessageControl` re-asks for.
  // Re-ask the read cursor there: a DM opened at, or held at, its tail must
  // move the server mark too, or the Room list's unread dot outlives the read.
  // `pinnedTailReadReport` refuses without the list's own evidence: a cold
  // open's pin starts true and a first-unread landing is still to come, so a
  // fetched tail must never be read over messages sitting below the fold. A
  // reader in history, a landing in progress, or a provisional draft/live lane
  // all write nothing.
  useFocusEffect(useCallback(() => {
    if (anchoredSegmentActive || !isFocused()) return;
    const chronological = chronologicalMessagesRef.current;
    const report = pinnedTailReadReport(chronological, {
      pinnedToTail: scrollController.isPinnedToTail(),
      landing: scrollController.isLanding(),
      hasObservedVisibility: newMessageHasObservedVisibility,
    });
    if (!report.length) return;
    advanceReadCursor(chronological, report);
  }, [
    advanceReadCursor,
    anchoredSegmentActive,
    isFocused,
    newMessageHasObservedVisibility,
    newestTranscriptMessageId,
    scrollController,
  ]));
  // Back from the code reader: center the row the reader opened it from.
  const scrollToArtifactOrigin = useCallback(
    (index: number) => {
      const messageId = transcriptMessagesRef.current[index]?.id;
      if (!messageId) return;
      scrollController.request({ kind: 'message', messageId, align: 'center', jump: false });
    },
    [scrollController],
  );
  const handleOpenCode = useArtifactReturn({
    transcriptMessages,
    residentMessages: combinedMessages,
    onReveal: revealTranscriptThrough,
    onScroll: scrollToArtifactOrigin,
  });
  // Re-land on every REAL layout change of the desktop content — an
  // appended row, streaming text growing the newest row, a late-loading
  // image — while the reader is already pinned to the tail. One measured
  // comparison, no retry budget: `scrollTop`/`scrollHeight` are native
  // browser state, so a reader who scrolled away is simply no longer
  // pinned; there is nothing left to disarm.
  //
  // Pin state itself is read from the scroll controller, not recomputed here:
  // a cold open has no scroll event yet (scrollTop is still 0 against the
  // full, taller-than-viewport content), so a fresh scrollTop/scrollHeight
  // read at that instant says "not pinned" and would never take the first
  // landing. The controller's pin starts true and is corrected only by a real
  // scroll, which is the same invariant the native list already relies on.
  const setDesktopContentNode = useCallback(
    (node: HTMLElement | null) => {
      desktopContentObserverRef.current?.disconnect();
      desktopContentObserverRef.current = null;
      desktopContentNodeRef.current = node;
      if (!node || typeof ResizeObserver === 'undefined') return;
      const observer = new ResizeObserver(() => {
        if (!desktopScrollNodeRef.current) return;
        if (
          shouldFollowDesktopTail({
            isPinnedToTail: scrollController.isPinnedToTail(),
            isUserDragging: scrollController.isUserDragging(),
            hasLandingAnchor: scrollController.isLanding(),
          })
        ) {
          scrollController.followNow();
        } else {
          restoreDesktopReadingAnchor();
        }
      });
      observer.observe(node);
      desktopContentObserverRef.current = observer;
    },
    [restoreDesktopReadingAnchor, scrollController],
  );
  const setDesktopScrollNode = useCallback(
    (node: HTMLElement | null) => {
      desktopScrollNodeRef.current = node;
      desktopVisibilityObserverRef.current?.disconnect();
      desktopVisibilityObserverRef.current = null;
      if (!node || typeof IntersectionObserver === 'undefined') return;
      const observer = new IntersectionObserver(
        (entries) => {
          for (const entry of entries) {
            const id = (entry.target as HTMLElement).dataset?.rowId;
            if (!id) continue;
            if (entry.isIntersecting) desktopIntersectingIdsRef.current.add(id);
            else desktopIntersectingIdsRef.current.delete(id);
          }
          observeVisibleTranscriptMessages({
            viewableItems: transcriptMessagesRef.current
              .filter((item) => desktopIntersectingIdsRef.current.has(item.id))
              .map((item) => ({ item, isViewable: true }) as ViewToken<ChatDisplayMessage>),
          });
        },
        { root: node, threshold: 0 },
      );
      desktopVisibilityObserverRef.current = observer;
      for (const rowNode of desktopRowNodesRef.current.values()) observer.observe(rowNode);
    },
    [observeVisibleTranscriptMessages],
  );
  const registerDesktopRowNode = useCallback((id: string, node: HTMLElement | null) => {
    const previous = desktopRowNodesRef.current.get(id);
    if (previous && previous !== node) desktopVisibilityObserverRef.current?.unobserve(previous);
    if (node) {
      desktopRowNodesRef.current.set(id, node);
      desktopVisibilityObserverRef.current?.observe(node);
    } else {
      desktopRowNodesRef.current.delete(id);
      desktopIntersectingIdsRef.current.delete(id);
    }
  }, []);
  // A stable ref callback per row id, so a re-render that leaves a row's id
  // unchanged does not toggle its DOM node out of and back into the
  // observers above (a fresh inline `ref` closure does that on every commit).
  const desktopRowRefCallbacksRef = useRef<Map<string, (node: HTMLElement | null) => void>>(
    new Map(),
  );
  const getDesktopRowRefCallback = useCallback(
    (id: string) => {
      let callback = desktopRowRefCallbacksRef.current.get(id);
      if (!callback) {
        callback = (node) => registerDesktopRowNode(id, node);
        desktopRowRefCallbacksRef.current.set(id, callback);
      }
      return callback;
    },
    [registerDesktopRowNode],
  );
  useEffect(
    () => () => {
      desktopContentObserverRef.current?.disconnect();
      desktopVisibilityObserverRef.current?.disconnect();
    },
    [],
  );
  // Pinned? Real scrollHeight/scrollTop/clientHeight, not RN Web's
  // contentOffset/contentSize estimates — the same formula the follow above
  // reads off the live scroll node.
  const handleDesktopScroll = useCallback(
    (event: { currentTarget: HTMLElement }) => {
      const node = event.currentTarget;
      const pinned = node.scrollHeight - node.scrollTop - node.clientHeight <= TAIL_PIN_THRESHOLD;
      scrollController.observeTailPinned(pinned);
      observeTailPinned(pinned);
      captureDesktopReadingAnchor();
      if (anchoredSegmentActive && pinned && !scrollController.isLanding())
        loadNewerTranscriptMessages();
      if (
        (!pinned || node.scrollHeight <= node.clientHeight + TAIL_PIN_THRESHOLD) &&
        node.scrollTop <= TAIL_PIN_THRESHOLD
      ) {
        loadOlderTranscriptMessages();
      }
    },
    [
      anchoredSegmentActive,
      captureDesktopReadingAnchor,
      loadNewerTranscriptMessages,
      loadOlderTranscriptMessages,
      observeTailPinned,
      scrollController,
    ],
  );
  // Pinned? Native offset 0 is the visual bottom of the inverted list. iOS
  // drops `onScroll` ticks inside the throttle window and never sends the
  // resting offset as one; only momentum-end (or drag-end with no momentum)
  // carries it. With a 100 ms window, a scroll that settled on the newest row
  // left both this reading and the list's viewability report short of the
  // tail, so the jump chevron and its badge stayed up over the newest row.
  const observePhoneTailOffset = useCallback(
    (offsetY: number) => {
      const pinned = offsetY <= TAIL_PIN_THRESHOLD;
      scrollController.observeTailPinned(pinned);
      observeTailPinned(pinned);
    },
    [observeTailPinned, scrollController],
  );
  // Older history paging and rolling live windows can both change rows above
  // the reader. Restore a visible row's screen offset, with browser anchoring
  // disabled so this is the only correction. Tail and explicit landings retain
  // their own authority.
  useLayoutEffect(() => {
    if (!desktopTranscript) return;
    restoreDesktopReadingAnchor();
  }, [restoreDesktopReadingAnchor, desktopTranscript, transcriptMessages]);
  // Desktop rows are in the DOM once they commit, so each commit is a layout
  // pass for the active request: a landing scrolls again, and a send that
  // waits for its own row lands once that row exists, before paint. The phone
  // list reports its own passes (content size and viewability).
  useLayoutEffect(() => {
    if (!desktopTranscript) return;
    scrollController.observeLayout();
  }, [desktopTranscript, scrollController, transcriptJump, transcriptMessages]);
  // A Room opened with unread messages lands on the first of them.
  useEffect(() => {
    if (isCorner || !firstUnreadMessageId || messageAnchorId) return;
    scrollController.request({ kind: 'firstUnread', messageId: firstUnreadMessageId });
  }, [decodedId, firstUnreadMessageId, isCorner, messageAnchorId, scrollController]);
  // The disc's one job. It lands on the tail itself rather than on a queued
  // boundary row, so a reader who is merely re-reading history — no queue at
  // all — gets back to the live end in one tap, and a reader with unread mail
  // arrives where the next message will land. The request replaces any
  // landing in progress.
  const landAtNewestMessage = useCallback(() => {
    loadLatestTranscriptMessages();
    scrollController.request({ kind: 'newest' });
    // The badge is NOT cleared here. A press is not visibility: this scroll
    // can be clamped, interrupted by a drag, or land short while the extent
    // is still measuring, and clearing on the press alone would tell the
    // reader they had seen rows they never reached. The viewability pass
    // clears it when the newest row is actually on screen — the same rule
    // that clears it when they scroll there under their own finger.
  }, [loadLatestTranscriptMessages, scrollController]);
  // The viewer sending is the viewer saying they are speaking at the live end
  // of the log, so the transcript lands there and shows them their own
  // message. The request replaces any landing in progress and pins the tail,
  // which the arrival rule reads to decide whether the appended row follows.
  // On desktop the scroll can run before a burst's final row commits, so the
  // request waits for this exact row and lands once more when it exists.
  const landAtOwnSend = useCallback(
    (messageId: string) => {
      loadLatestTranscriptMessages();
      scrollController.request(
        desktopTranscript ? { kind: 'newest', untilRowId: messageId } : { kind: 'newest' },
      );
    },
    [desktopTranscript, loadLatestTranscriptMessages, scrollController],
  );
  useEffect(
    () =>
      liveDraftStore.subscribeCommit(() => {
        if (scrollController.isPinnedToTail()) scrollController.follow();
      }),
    [liveDraftStore, scrollController],
  );
  // A call starts at the live end, rather than retaining an automatic unread
  // landing. Deliberate history navigation keeps the existing arrival badge.
  const joinedCallId = voice.call?.id ?? null;
  useEffect(() => {
    if (joinedCallId && scrollController.enterCall()) loadLatestTranscriptMessages();
  }, [joinedCallId, loadLatestTranscriptMessages, scrollController]);
  // Only a different tail row is an arrival. Lifecycle updates repaint the
  // existing row and must not pull a reader out of history.
  const newestMessageId = foldedMessages.at(-1)?.id ?? null;
  const arrivalFollow = useScrollFollowOnArrival({
    newestId: newestMessageId,
    isPinnedToTail: scrollController.isPinnedToTail(),
    isUserDragging: scrollController.isUserDragging(),
    openLandsOnTail: roomOpenLandsOnTail({ desktopTranscript, messageAnchorId }),
  });
  useLayoutEffect(() => {
    if (arrivalFollow === 'hold') return;
    // Desktop's own ResizeObserver (`setDesktopContentNode` above) already
    // re-lands on the real DOM as the appended row's layout commits; this
    // call is a harmless, idempotent second landing for the same content —
    // native has no such observer and depends on it entirely. A landing in
    // progress keeps the list; `follow` yields to it.
    scrollController.follow();
  }, [newestMessageId, scrollController]);
  // Land on the exact fact that caused the alert, at the top of the screen.
  // A host row near the newest end lands at once. Otherwise the store opens
  // a window that keeps the target near its newest end: from resident rows at
  // once, or from a read around the id. The room stays usable throughout, and
  // the target is highlighted when its row is drawn.
  useEffect(() => {
    if (!notificationResponseId) return;
    const anchorKey = `${notificationResponseId}:${notificationMessageId ?? notificationTarget ?? ''}`;
    if (handledNotificationAnchorRef.current === anchorKey) return;

    const messageId = notificationMessageId?.trim();
    if (!messageId) return;
    const hostIndex = hostRowIndex(transcriptMessages, transcriptHostIdsRef.current, messageId);
    const needsRead =
      transcriptJump?.messageId !== messageId &&
      !(hostIndex >= 0 && messageJumpCanScrollTo(messageId, hostIndex));
    // The store finds a target in the Room's rows without a read, and joins a
    // read's page to them. A read answered before the Room's first rows opens
    // a window that cannot join them, and the target settles mid-screen.
    if (needsRead && (!roomClient || !cacheViewerPubkey || roomSurface?.room.id !== decodedId))
      return;
    handledNotificationAnchorRef.current = anchorKey;
    requestMessageJump(scrollController, messageId, needsRead ? jumpToTranscriptMessage : null);
  }, [
    cacheViewerPubkey,
    decodedId,
    jumpToTranscriptMessage,
    notificationMessageId,
    notificationResponseId,
    notificationTarget,
    roomClient,
    roomSurface,
    scrollController,
    transcriptJump,
    transcriptMessages,
  ]);
  useEffect(() => {
    if (
      !desktopTranscript ||
      !anchoredSegmentActive ||
      scrollController.isLanding() ||
      transcriptNewerStatus !== 'idle'
    )
      return;
    const node = desktopScrollNodeRef.current;
    if (node && node.scrollHeight <= node.clientHeight + TAIL_PIN_THRESHOLD) {
      loadNewerTranscriptMessages();
    }
  }, [
    desktopTranscript,
    anchoredSegmentActive,
    transcriptNewerStatus,
    transcriptMessages,
    loadNewerTranscriptMessages,
  ]);
  // A reconciled draft/final bubble keeps a stable display `id` across the
  // turn, so it also needs to resolve by its real relay event id — the id
  // any NIP-10 reply on another client actually references.
  const rawVisibleMessageById = useMemo(() => {
    const map = new Map<string, ChatDisplayMessage>();
    for (const message of visibleMessages) {
      map.set(message.id, message);
      if (message.relayId) map.set(message.relayId, message);
    }
    return map;
  }, [visibleMessages]);
  const visibleMessageById = useStable(rawVisibleMessageById, sameMessageRefMap);
  // The first human reply to a message answers it; a corner proposal card shows
  // which choice that reply made and who made it.
  const rawAnswerByMessageId = useMemo(() => {
    const answers = new Map<string, { decision: 'open' | 'cancel' | null; handle: string }>();
    for (const message of visibleMessages) {
      const identity = message.authorIdentity;
      if (identity?.kind !== 'human' || !message.replyToId) continue;
      if (answers.has(message.replyToId)) continue;
      answers.set(message.replyToId, {
        decision: cornerProposalDecision(message.text),
        handle: (identity.handle || identity.name).replace(/^@/, ''),
      });
    }
    return answers;
  }, [visibleMessages]);
  const answerByMessageId = useStable(rawAnswerByMessageId, sameRecordValueMap);
  const bylineOpeners = useStable(
    useMemo(() => transcriptBylineOpeners(visibleMessages), [visibleMessages]),
    sameStringSet,
  );
  const rawImmediatelyPrecedingVisibleMessageById = useMemo(() => {
    const map = new Map<string, ChatDisplayMessage>();
    for (let index = 1; index < visibleMessages.length; index += 1) {
      map.set(visibleMessages[index].id, visibleMessages[index - 1]);
    }
    return map;
  }, [visibleMessages]);
  const immediatelyPrecedingVisibleMessageById = useStable(
    rawImmediatelyPrecedingVisibleMessageById,
    sameMessageRefMap,
  );
  // Once the matching server-indexed receipt lands there is nothing left for
  // the local ack to guess at. A terminal receipt is still confirmation: the
  // old active-only check missed the case where WORKING had already become
  // COMPLETE before this screen observed it.
  useEffect(() => {
    if (pendingAck && hasComposerAckReceipt(pendingAck.requestId, agentTurnMarkers)) {
      setPendingAck(null);
    }
  }, [agentTurnMarkers, pendingAck]);

  // A single deadline-scheduled timer (never a ticking interval — see the
  // presence clock above) clears the purely local acknowledgement. If no
  // receipt arrives, silence is not evidence that an agent is waiting; a
  // later server-indexed WORKING receipt can independently light `thinking`.
  useEffect(() => {
    if (!pendingAck) return;
    const deadline = pendingAck.sentAt + COMPOSER_ACK_BOUND_MS;
    const delay = Math.max(1, deadline - Date.now() + 1);
    const timer = setTimeout(() => setPendingAck(null), delay);
    return () => clearTimeout(timer);
  }, [pendingAck]);

  // A committed steer is a brief confirmation, not a new lifecycle. It stays
  // on the exact running turn the server accepted it into and then clears.
  useEffect(() => {
    if (!receivedSteer) return;
    if (
      !activeAgentTurn ||
      activeAgentTurn.agentPubkey !== receivedSteer.agentPubkey ||
      activeAgentTurn.requestId !== receivedSteer.turnRequestId
    ) {
      setReceivedSteer(null);
      return;
    }
    const delay = Math.max(
      1,
      receivedSteer.receivedAt + STEER_RECEIVED_VISIBLE_MS - Date.now() + 1,
    );
    const timer = setTimeout(() => setReceivedSteer(null), delay);
    return () => clearTimeout(timer);
  }, [activeAgentTurn, receivedSteer]);

  /**
   * The ordinary turn indicator, and the only thing a plain question in a Room
   * ever lights: "beebee thinking…" while the reply is being composed, gone
   * when it lands. Its input is the Room's own `#t=agent-turn` lifecycle and
   * nothing else — no corner reaches it, exactly as no turn reaches the corner
   * line above.
   *
   * A Corner uses the same signed turn proof as a Room. Its separate
   * canonical Corner lease still owns the pinned Corner bar, but cannot hide a
   * channel-local reply that is visibly streaming now.
   *
   * `pendingAck` bridges only the send round trip. After acceptance, the
   * unclaimed commands stay silent until the helper claims them.
   * Only a genuine server-indexed WORKING receipt says the agent is thinking.
   */
  const composerAck = useMemo((): ComposerAckPresentation | null => {
    return selectComposerAckPresentation({
      isCorner,
      viewerCanSend: roomSurface?.viewer.permissions.send,
      ...(activeAgentTurn?.agentPubkey ? { activeTurnPubkey: activeAgentTurn.agentPubkey } : {}),
      ...(activeAgentTurn
        ? {
            activeTurnStartedAt: activeAgentTurn.startedAt ?? activeAgentTurn.createdAt,
            activeTurnRequestId: activeAgentTurn.requestId,
            activeTurnAgentPubkey: activeAgentTurn.agentPubkey,
            ...(activeAgentTurn.requestedBy
              ? { activeTurnRequestedBy: activeAgentTurn.requestedBy }
              : {}),
          }
        : {}),
      ...(viewerPubkey ? { viewerPubkey } : {}),
      ...(pendingAck ? { pendingAckSentAt: pendingAck.sentAt } : {}),
      ...(receivedSteer ? { receivedSteer } : {}),
      now: pendingAck?.sentAt ?? Date.now(),
      conversationIdentities,
      agentsByPubkey: agentByPubkey,
    });
  }, [
    activeAgentTurn,
    roomSurface?.viewer.permissions.send,
    agentByPubkey,
    conversationIdentities,
    isCorner,
    pendingAck,
    receivedSteer,
    viewerPubkey,
  ]);

  // C97: the fixed chrome below the inverted list changes independently of
  // transcript rows. A send resets the composer's height while retaining the
  // keyboard; native layout can update the pinned ref before an effect runs,
  // preserving the old offset as an empty gap. Capture the verdict in render.
  //
  // The phone turn line is NOT part of that chrome any more. It is absolute,
  // anchored to the composer's top edge (`room-bottom-chrome`), so it takes
  // no height out of the list whether or not an agent is working and the
  // newest row never moves when it comes or goes.
  // `bottomChromeLayoutKey` still carries turn/no-turn, but that is now a
  // no-op re-pin.
  const keyboardHeight = useKeyboardState((state) => state.height);
  const { progress: keyboardProgress } = useReanimatedKeyboardAnimation();
  const composerBottomInsetStyle = useAnimatedStyle(
    () => ({
      paddingBottom: composerBottomPadding(Platform.OS, insets.bottom, keyboardProgress.value),
    }),
    [insets.bottom],
  );
  const composerFootprint = composerHeight + keyboardHeight;
  const bottomChromeLayoutKey = composerAck ? 'turn' : 'no-turn';
  const composerLayoutFollow = useScrollFollowOnLayoutChange({
    footprint: composerFootprint,
    layoutKey: bottomChromeLayoutKey,
    isPinnedToTail: scrollController.isPinnedToTail(),
    isUserDragging: scrollController.isUserDragging(),
  });
  useLayoutEffect(() => {
    if (composerLayoutFollow === 'hold') return;
    scrollController.follow();
  }, [bottomChromeLayoutKey, composerFootprint, composerLayoutFollow, scrollController]);

  /**
   * Withdraw the question this turn is answering.
   *
   * The control is offered to anyone who may act in the Room (`viewerMayStopTurn`), and the
   * server refuses anyone else, so the two agree on one rule rather than the
   * phone guessing at it. The press is acknowledged on this line immediately
   * (`stoppingTurn`); the cancelled receipt is still what settles the durable
   * "stopped" line and retires the control.
   */
  const [stoppingTurn, setStoppingTurn] = useState<{
    agentPubkey: string;
    requestId: string;
  } | null>(null);
  const handleStopTurn = useCallback(
    async (stop: { agentPubkey: string; requestId: string }) => {
      setStoppingTurn(stop);
      try {
        await monolithPhoneOperation('cancelAgentTurn', {
          roomId: decodedId,
          requestId: stop.requestId,
          agentId: stop.agentPubkey,
        });
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        return true;
      } catch (err) {
        setStoppingTurn((current) =>
          current?.requestId === stop.requestId && current.agentPubkey === stop.agentPubkey
            ? null
            : current,
        );
        // A turn that settled while the press was in the air is the ordinary
        // race, not a failure worth a dialog: the line is already gone.
        if (err instanceof MonolithRequestTimeoutError) {
          refreshSignal.force();
          Modal.alert('Stop result unknown', phoneOperationFailureReason(err));
        }
        console.warn('Stopping the turn failed:', err);
        return false;
      }
    },
    [decodedId],
  );
  useEffect(() => {
    if (!stoppingTurn) return;
    if (
      !activeAgentTurn ||
      activeAgentTurn.requestId !== stoppingTurn.requestId ||
      activeAgentTurn.agentPubkey !== stoppingTurn.agentPubkey
    ) {
      setStoppingTurn(null);
    }
  }, [activeAgentTurn, stoppingTurn]);
  const stoppingThisTurn = Boolean(
    stoppingTurn &&
    composerAck?.stop &&
    stoppingTurn.requestId === composerAck.stop.requestId &&
    stoppingTurn.agentPubkey === composerAck.stop.agentPubkey,
  );

  /** The settled "<Past> for Ns · done h:MM" line a finished turn leaves briefly. */
  const [settledTurn, setSettledTurn] = useState<{
    line: string;
  } | null>(null);
  const lastActiveTurnRef = useRef<{
    requestId: string;
    agentPubkey: string;
    startedAt: number;
    verb: TurnVerb;
  } | null>(null);
  useEffect(() => {
    if (activeAgentTurn) {
      const verb = composerAck?.verb;
      if (verb) {
        lastActiveTurnRef.current = {
          requestId: activeAgentTurn.requestId,
          agentPubkey: activeAgentTurn.agentPubkey,
          startedAt: (activeAgentTurn.startedAt ?? activeAgentTurn.createdAt) * 1_000,
          verb,
        };
      }
      setSettledTurn(null);
      return;
    }
    const last = lastActiveTurnRef.current;
    if (!last) return;
    const terminal = agentTurnMarkers.find(
      (turn) =>
        turn.requestId === last.requestId &&
        turn.agentPubkey === last.agentPubkey &&
        turn.status !== 'working',
    );
    if (!terminal) return;
    const status = terminal.status;
    if (status === 'working') return;
    lastActiveTurnRef.current = null;
    const line = formatTerminalTurnOverlay(
      status,
      last.verb,
      last.startedAt,
      terminal.createdAt * 1_000,
    );
    if (!line) return;
    setSettledTurn({ line });
  }, [activeAgentTurn, agentTurnMarkers, composerAck]);
  useEffect(() => {
    if (!settledTurn) return;
    const timer = setTimeout(() => setSettledTurn(null), 6_000);
    return () => clearTimeout(timer);
  }, [settledTurn]);
  useEffect(() => {
    if (!desktopExperience || (!composerAck && !settledTurn)) return;
    setDesktopDeliveryState((state) => (state === 'delivered' ? null : state));
  }, [composerAck, desktopExperience, settledTurn]);

  useEffect(() => {
    // Only an explicit offline fact can age into dormancy. A five-second clock
    // here recreated FlatList's renderItem (and every visible message) while
    // someone was typing, which made the foreground intermittently unresponsive.
    const now = Date.now();
    const presenceDeadline = nextAgentPresenceTransitionAt(agentPresences, now);
    const turnDeadline = nextAgentTurnExpiryAt(agentTurnMarkers, now);
    const deadline =
      presenceDeadline === undefined
        ? turnDeadline
        : turnDeadline === undefined
          ? presenceDeadline
          : Math.min(presenceDeadline, turnDeadline);
    if (deadline === undefined) return;
    const delay = Math.max(1, deadline - now + 1);
    const timer = setTimeout(() => setPresenceNow(Date.now()), delay);
    return () => clearTimeout(timer);
  }, [agentPresences, agentTurnMarkers, presenceNow]);

  const replyTargetForMessage = useCallback(
    (message: ChatDisplayMessage): MessageReplyDisplayTarget => {
      const knownAgent = message.pubkey ? agentByPubkey.get(message.pubkey) : undefined;
      const isAgent = Boolean(
        message.pubkey && (message.isAgentAuthor || message.isAgentActivity || knownAgent),
      );
      const agentDisplay = isAgent
        ? resolveAgentDisplayIdentity(message.pubkey ?? 'unknown-agent', knownAgent)
        : undefined;
      const personProfile = message.pubkey ? personProfileByPubkey.get(message.pubkey) : undefined;
      const canonicalAuthorHandle =
        message.authorIdentity?.handle ??
        (isAgent
          ? knownAgent?.handle
          : (personProfile?.handle ??
            (message.pubkey ? fallbackMemberHandle(message.pubkey) : undefined)));
      const personName = personProfile?.name;
      const attachmentPreview = message.attachments?.[0]?.name;
      return {
        // A reconciled draft/final bubble's display `id` is a synthetic
        // per-turn key. The composer separately obtains the opaque threading
        // proof from the snapshot using this real message id.
        messageId: message.relayId ?? message.id,
        authorName:
          message.authorIdentity?.name ??
          agentDisplay?.name ??
          personName ??
          fallbackMemberName(message.pubkey ?? ''),
        ...(canonicalAuthorHandle ? { authorHandle: canonicalAuthorHandle } : {}),
        ...(message.pubkey ? { authorPubkey: message.pubkey } : {}),
        isAgent,
        preview: message.text.trim() || attachmentPreview || 'Attachment',
      };
    },
    [agentByPubkey, personProfileByPubkey],
  );

  const beginReply = useCallback(
    (message: ChatDisplayMessage) => {
      const target = beginReplyTarget(
        message,
        chronologicalMessagesRef.current,
        replyTargetForMessage(message),
        decodedId,
      );
      if (!target) return;
      const install = () => {
        setReplyTarget(target);
        if (target.isAgent && target.authorHandle && target.authorPubkey) {
          applyComposerPrefill(
            planReplyPrefill({
              draft: inputTextRef.current,
              prefill: composerPrefillRef.current,
              handle: target.authorHandle,
              pubkey: target.authorPubkey,
              sourceMessageId: target.messageId,
            }),
            { handle: target.authorHandle, pubkey: target.authorPubkey },
          );
        }
        setDismissedMentionKey(null);
        void Haptics.selectionAsync();
        // A reply started from a message the reader scrolled up to read keeps
        // that same scroll offset by default while the keyboard/reply banner
        // shrink the viewport, which reads as the transcript jumping to
        // center the replied-to message. The reply reference in the composer
        // is enough context, so land back on the end of the log instead.
        scrollController.request({ kind: 'newest' });
        scheduleAnimationFrame(() => composerRef.current?.focus());
      };
      install();
    },
    // Read through the ref: a transcript dependency here would hand every
    // row a new renderer on each live message.
    [applyComposerPrefill, decodedId, replyTargetForMessage, scrollController],
  );

  const handleReactToMessage = useCallback(
    async (message: ChatDisplayMessage, emoji: MessageReactionEmoji) => {
      if (message.isAgentDraft) return;
      const messageId = message.relayId ?? message.id;
      if (reactingRef.current.has(messageId)) return;
      reactingRef.current.add(messageId);
      const previous = optimisticReactionsRef.current[messageId] ?? message.reactions ?? [];
      const existing = previous.find((reaction) => reaction.emoji === emoji);
      const next = existing
        ? previous.map((reaction) => reaction.emoji === emoji ? {
            ...reaction,
            count: Math.max(0, reaction.count + (reaction.reacted ? -1 : 1)),
            reacted: !reaction.reacted,
          } : reaction).filter((reaction) => reaction.count > 0)
        : [...previous, { emoji, count: 1, reacted: true }];
      setOptimisticReactions((current) => ({ ...current, [messageId]: next }));
      try {
        const canonical = await monolithPhoneOperation('reactToMessage', {
          roomId: decodedId,
          messageId,
          emoji,
        });
        if (canonical) applyRoomMessageResult(canonical);
        setOptimisticReactions((current) => {
          const updated = { ...current };
          delete updated[messageId];
          return updated;
        });
      } catch (error) {
        setOptimisticReactions((current) => {
          const updated = { ...current };
          delete updated[messageId];
          return updated;
        });
        Modal.alert('Could not react', error instanceof Error ? error.message : String(error));
      } finally {
        reactingRef.current.delete(messageId);
      }
    },
    [applyRoomMessageResult, decodedId],
  );

  const messageIsBookmarked = useCallback(
    (message: ChatDisplayMessage) => Boolean(
      roomMessageRecord(messageRecordScope, decodedId, message.relayId ?? message.id)?.bookmarked ?? message.bookmarked,
    ),
    [decodedId, messageRecordScope],
  );

  const handleBookmarkMessage = useCallback(
    async (message: ChatDisplayMessage) => {
      if (message.isAgentActivity || message.isAgentDraft) return;
      const messageId = message.relayId ?? message.id;
      const previous = messageIsBookmarked(message);
      const bookmarked = !previous;
      writeRoomBookmark(messageRecordScope, decodedId, messageId, bookmarked);
      AccessibilityInfo.announceForAccessibility(
        bookmarked ? 'Message bookmarked' : 'Bookmark removed',
      );
      try {
        const result = await monolithPhoneOperation('setMessageBookmark', {
          roomId: decodedId,
          messageId,
          bookmarked,
        });
        writeRoomBookmark(messageRecordScope, decodedId, messageId, result.bookmarked);
        const row = roomMessageRecord(messageRecordScope, decodedId, messageId);
        if (row) applyRoomMessageResult({ ...row, bookmarked: result.bookmarked });
      } catch (error) {
        writeRoomBookmark(messageRecordScope, decodedId, messageId, previous);
        AccessibilityInfo.announceForAccessibility('Bookmark change failed');
        Modal.alert(
          bookmarked ? 'Could not bookmark message' : 'Could not remove bookmark',
          error instanceof Error ? error.message : String(error),
        );
      }
    },
    [applyRoomMessageResult, decodedId, messageIsBookmarked, messageRecordScope],
  );

  const handleReportMessage = useCallback(
    async (message: ChatDisplayMessage) => {
      if (message.isAgentActivity || message.isAgentDraft) return;
      const messageId = message.relayId ?? message.id;
      const outcome = await promptAndReportMessageIssue(
        { roomId: decodedId, messageId },
        {
          prompt: (title, body, options) => Modal.prompt(title, body, options),
          report: (input) => monolithPhoneOperation('reportMessageIssue', input),
        },
      );
      if (outcome.status === 'cancelled') return;
      if (outcome.status === 'failed') {
        Modal.alert('Could not report message', phoneOperationFailureReason(outcome.error));
        return;
      }
      const row = roomMessageRecord(messageRecordScope, decodedId, messageId);
      if (row) applyRoomMessageResult({ ...row, feedbackReported: true });
      const copy = reportIssueToastCopy(outcome.duplicate);
      showReportToast(copy);
      AccessibilityInfo.announceForAccessibility(copy);
    },
    [applyRoomMessageResult, decodedId, messageRecordScope, showReportToast],
  );

  const canDeleteMessage = useCallback(
    (message: ChatDisplayMessage) =>
      !message.deleted &&
      !message.isAgentActivity &&
      !message.isAgentDraft &&
      (message.isUser || canManageWorkspace),
    [canManageWorkspace],
  );
  const handleDeleteMessage = useCallback(
    async (message: ChatDisplayMessage) => {
      if (!canDeleteMessage(message)) return;
      const confirmed = await Modal.confirm(
        'Delete message?',
        'The message text and attachments will be removed. A deleted-message record will remain in this Room.',
        { cancelText: 'Cancel', confirmText: 'Delete', destructive: true },
      );
      if (!confirmed) return;
      const messageId = message.relayId ?? message.id;
      setOptimisticDeletes((current) => ({ ...current, [messageId]: true }));
      try {
        const canonical = await monolithPhoneOperation('deleteRoomMessage', {
          roomId: decodedId,
          messageId,
        });
        if (canonical) applyRoomMessageResult(canonical);
        setOptimisticDeletes((current) => {
          const updated = { ...current };
          delete updated[messageId];
          return updated;
        });
        AccessibilityInfo.announceForAccessibility('Message deleted');
      } catch (error) {
        setOptimisticDeletes((current) => {
          const updated = { ...current };
          delete updated[messageId];
          return updated;
        });
        Modal.alert(
          'Could not delete message',
          error instanceof Error ? error.message : String(error),
        );
      }
    },
    [applyRoomMessageResult, canDeleteMessage, decodedId],
  );
  const openMessageActions = useCallback((message: ChatDisplayMessage) => {
    // A live draft is the turn still writing — it settles into the reply the
    // actions would target, so it offers none.
    if (message.isAgentDraft || message.deleted) return;
    void Haptics.selectionAsync();
    setMessageActionsTarget(message);
  }, []);

  const workspaceChatListRef = useRef(workspaceChatList);
  workspaceChatListRef.current = workspaceChatList;
  const beginForward = useCallback(
    async (message: ChatDisplayMessage) => {
      // Forward works wherever a transcript renders — the picker sheet and
      // the send operation are not desktop-bound; the guard is only the
      // message itself and the Room client.
      if (message.isAgentDraft || !roomClient || !activeCommunityId) return;
      setForwardTarget(message);
      setForwardRooms(null);
      setForwardError(null);
      try {
        // The live Room list is current; only a list not yet loaded reads one.
        const held = workspaceChatListRef.current;
        const [chats, workspace] = await Promise.all([
          held ? held.chats : roomClient.chats(activeCommunityId).then((list) => list.chats),
          roomClient.workspace(activeCommunityId),
        ]);
        setForwardRooms(forwardTargets(chats, workspace, decodedId));
      } catch (error) {
        setForwardError(error instanceof Error ? error.message : String(error));
        setForwardRooms([]);
      }
    },
    [activeCommunityId, decodedId, roomClient],
  );

  const forwardToRoom = useCallback(
    async (target: ForwardTarget) => {
      if (!forwardTarget || forwardBusyRoomId) return;
      setForwardBusyRoomId(target.id);
      setForwardError(null);
      try {
        if (!transport || !activeCommunityId) throw new Error('Beeline is still connecting.');
        const roomId = await resolveForwardTargetRoom(
          target,
          activeCommunityId,
          (workspaceId, memberId) => transport.resolveDirectMessage(workspaceId, memberId),
        );
        await forwardMessageToRoom(
          (input) => monolithPhoneOperation('sendRoomMessage', input),
          roomId,
          {
            text: forwardTarget.text,
            author: forwardTarget.authorIdentity ?? {
              name: forwardTarget.pubkey ? fallbackMemberName(forwardTarget.pubkey) : 'SOMEONE',
              ...(forwardTarget.pubkey
                ? { handle: fallbackMemberHandle(forwardTarget.pubkey) }
                : {}),
            },
            attachments: forwardTarget.attachments,
            source: {
              roomId: decodedId,
              messageId: forwardTarget.relayId ?? forwardTarget.id,
            },
          },
          displayRoomName,
        );
        setForwardTarget(null);
        setForwardRooms(null);
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (error) {
        setForwardError(error instanceof Error ? error.message : String(error));
      } finally {
        setForwardBusyRoomId(null);
      }
    },
    [activeCommunityId, decodedId, displayRoomName, forwardBusyRoomId, forwardTarget, transport],
  );

  const markOutboxFailed = outbox.markFailed;
  const retryOutboxMessage = outbox.retry;
  const dismissOutboxMessage = outbox.dismiss;
  const handleSend = useCallback(
    async (shortcut?: MessageShortcut, dictated?: DictatedSend) => {
      // A leaked responder event must never read as a shortcut (#1340's
      // `onPress={onSend}` handed the PressEvent straight in; `!shortcut` then
      // skipped the composer-clear block and the field kept its text after
      // every send). Only a real shortcut — it always carries text — qualifies.
      const sendShortcut = shortcut && typeof shortcut.text === 'string' ? shortcut : undefined;
      const clearSubmittedDraft = composerDraft.captureMessage();
      const viewer = sendShortcut?.viewer;
      const spoken = (sendShortcut?.text ?? inputTextRef.current).trim();
      const addressed = viewer?.agentHandle && !spoken.includes(`@${viewer.agentHandle}`)
        ? `@${viewer.agentHandle} ${spoken}` : spoken;
      const rawText = viewer ? `${addressed}\n\n[${viewer.context}]` : addressed;
      const activeReplyTarget = sendShortcut ? sendShortcut.replyTarget : replyTarget;
      const activePendingAttachments = viewer?.pickedAttachments ?? (sendShortcut ? [] : pendingAttachmentsRef.current);
      // State updates are committed asynchronously. A ref closes the short
      // double-tap window before `sending` can disable the native control.
      if (
        sendInFlightRef.current ||
        (!spoken && activePendingAttachments.length === 0) ||
        isArchived
      )
        return;
      // Repository guidance is optional; the agent must still receive the request.
      if (
        !isDirectMessage &&
        !isCorner &&
        ((!roomRepository && roomRepositoryResolved) || roomRepoAccessIssue) &&
        looksLikeCornerOpenIntent(rawText)
      ) {
        setCornerOpenRepoPrompt(true);
        if (activeCommunityId && roomRepoCandidates.length === 0 && transport) {
          if (githubScope) void readGitHubAccess(transport, githubScope, true)
            .catch(() => undefined);
        }
      }
      const preparedReply = activeReplyTarget
        ? prepareMessageReply(rawText, activeReplyTarget)
        : undefined;
      const text = preparedReply?.text ?? rawText;
      const mentionedPubkeys = resolveComposerMentions(
        text,
        roomParticipants,
        sendShortcut ? NO_SELECTED_MENTIONS : selectedMentionsRef.current,
      ).pubkeys;
      const recordUntaggedSend = captureUntaggedSend(mentionedPubkeys.length > 0);
      const selectedMentionedAgent = sendShortcut
        ? undefined
        : selectedMentionAgentPubkey(text, selectedAgentMentionsRef.current);
      const mentionedAgent =
        selectedMentionedAgent ??
        preparedReply?.agentPubkey ??
        mentionedPubkeys.find((pubkey) => roomAgents.some((agent) => agent.pubkey === pubkey)) ??
        mentionedAgentPubkey(text, roomAgents);
      // Resolve before attachment upload or cold transport creation so the ack
      // cannot wait on either. A corner (one agent, always addressed) or a
      // two-party Room (the sole other participant may speak naturally, per the
      // addressing rule) counts too.
      const addressesAgent =
        isCorner ||
        Boolean(mentionedAgent) ||
        (roomAgents.length === 1 && roomParticipants.length <= 2);
      setReceivedSteer(null);
      setPendingAck(addressesAgent ? { sentAt: Date.now() } : null);

      sendInFlightRef.current = true;
      setSending(true);
      if (desktopExperience) setDesktopDeliveryState('sending');
      // Text feedback lands in the local overlay in this same turn. Signing,
      // transport startup and outbox persistence can all take longer than a
      // frame on a cold Android device.
      const provisionalId = activePendingAttachments.length === 0
        ? `pending:${Date.now()}:${Math.random()}`
        : null;
      if (provisionalId) {
        addMessages([{
          id: provisionalId,
          text,
          isUser: true,
          timestamp: Math.floor(Date.now() / 1_000),
          authorIdentity: roomSurface?.viewer.identity ?? {
            pubkey: userPubkey,
            kind: 'human',
            name: fallbackMemberName(userPubkey),
          },
          pubkey: userPubkey,
          ...(mentionedPubkeys.length ? { mentionPubkeys: mentionedPubkeys } : {}),
          ...(preparedReply?.reference ? { replyToId: preparedReply.reference.eventId } : {}),
        }]);
        landAtOwnSend(provisionalId);
      }
      let preparedEvent: Awaited<ReturnType<BuzzRigTransport['composeMessage']>> | undefined;
      let preparedTransport: BuzzRigTransport | undefined;
      try {
        // A warm/partial snapshot can paint before the hydration effect has
        // published its transport state. Sending is still a valid operation:
        // construct the monolith transport on demand rather than
        // leaving the enabled send control as a silent no-op.
        let sendTransport = transport;
        if (!sendTransport) {
          const identity = await loadBuzzIdentity();
          if (!identity) throw new Error('Beeline identity is unavailable');
          sendTransport = new BuzzRigTransport(identity);
        }
        if (!transport) setSessionTransport(sendTransport);
        preparedTransport = sendTransport;
        // ■ on a dictated message drops it at any step before it enters the Room.
        const dictationCancelled = () => {
          if (!dictated?.cancelled) return false;
          setPendingAck(null);
          if (provisionalId) removeOptimistic(preparedEvent?.id ?? provisionalId);
          if (desktopExperience) setDesktopDeliveryState(null);
          return true;
        };
        if (dictationCancelled()) return;
        const uploadedSnapshot = viewer?.screenshotBase64
          ? await (async () => {
              const bytes = Uint8Array.from(Buffer.from(viewer.screenshotBase64!, 'base64'));
              const uploaded = await sendTransport.uploadMedia(bytes, 'image/jpeg');
              return {
                url: uploaded.url,
                name: 'browser-screen.jpg',
                mimeType: 'image/jpeg',
                size: uploaded.size,
                sha256: uploaded.sha256,
                ...(uploaded.thumb ? { thumbnailUrl: uploaded.thumb } : {}),
              };
            })()
          : undefined;
        const selectedAttachments = activePendingAttachments.length
            ? await attachmentUploader.uploadAll(await sendTransport.ensureClient(), activePendingAttachments)
            : [];
        const attachments = [
          ...(viewer?.artifact ? [viewer.artifact] : []),
          ...(uploadedSnapshot ? [uploadedSnapshot] : []),
          ...selectedAttachments,
        ];
        if (dictationCancelled()) return;
        // Sign before append. The authoritative event id is the optimistic row
        // identity and the durable outbox key from its first frame onward.
        preparedEvent = preparedReply?.reference
          ? await sendTransport.composeReplyMessage(
              text,
              preparedReply.reference,
              mentionedAgent,
              attachments,
              mentionedPubkeys,
            )
          : await sendTransport.composeMessage(
              { sessionId: decodedId, text, attachments },
              mentionedAgent || mentionedPubkeys.length
                ? {
                    ...(mentionedAgent ? { mentionAgent: mentionedAgent } : {}),
                    ...(mentionedPubkeys.length ? { mentionPubkeys: mentionedPubkeys } : {}),
                  }
                : undefined,
            );
        if (addressesAgent) {
          setPendingAck((current) =>
            current ? { ...current, requestId: preparedEvent!.id } : current,
          );
        }
        if (provisionalId) reconcileOptimistic(provisionalId, preparedEvent.id);
        const optimistic = {
          id: preparedEvent.id,
          text,
          isUser: true,
          timestamp: preparedEvent.created_at,
          authorIdentity: roomSurface?.viewer.identity ?? {
            pubkey: userPubkey,
            kind: 'human',
            name: fallbackMemberName(userPubkey),
          },
          pubkey: userPubkey,
          reference: undefined,
          ...(mentionedPubkeys.length ? { mentionPubkeys: mentionedPubkeys } : {}),
          ...(preparedReply?.reference ? { replyToId: preparedReply.reference.eventId } : {}),
          ...(attachments.length ? { attachments } : {}),
        } satisfies ChatDisplayMessage;
        const activeOutbox = outbox.current();
        if (!activeOutbox) throw new Error('Message outbox is unavailable');
        if (dictationCancelled()) return;
        if (dictated) dictated.committed = true;
        await activeOutbox.enqueue(preparedEvent, {
          id: preparedEvent.id,
          text,
          createdAt: preparedEvent.created_at,
          author: roomSurface?.viewer.identity ?? {
            pubkey: userPubkey,
            kind: 'human',
            name: fallbackMemberName(userPubkey),
          },
          presentation: 'message',
          ...(mentionedPubkeys.length ? { mentionPubkeys: mentionedPubkeys } : {}),
          ...(attachments.length ? { attachments } : {}),
        });
        landAtOwnSend(optimistic.id);
        if (!provisionalId) addMessages([optimistic]);
        if (!sendShortcut) {
          const draftCleared = clearSubmittedDraft();
          if (activeComposerDraftRef.current === composerDraft) {
            if (draftCleared) {
              const nextInputRevision = composerInputRevisionRef.current + 1;
              composerInputRevisionRef.current = nextInputRevision;
              // Reconcile only the remaining draft, including typing appended during send.
              if (!composerDraft.value) composerRef.current?.clear();
              inputTextRef.current = composerDraft.value;
              setComposerInputRevision(nextInputRevision);
              if (!composerDraft.value) setComposerHeight(COMPOSER_MIN_HEIGHT);
              const end = composerDraft.value.length;
              setInputSelection({ start: end, end });
            }
            replacePendingAttachments((current) =>
              current.filter((attachment) => !activePendingAttachments.includes(attachment)),
            );
            setReplyTarget((current) => (current === activeReplyTarget ? null : current));
          }
        }
        await activeOutbox.attempted(preparedEvent.id);
        const writeResult = await sendTransport.publishPreparedMessage(preparedEvent);
        recordUntaggedSend(preparedEvent.id);
        if (writeResult.message) applyRoomMessageResult(writeResult.message);
        if (writeResult.pendingAgentCommands) applyPendingAgentCommands(writeResult.pendingAgentCommands);
        if (
          isCorner &&
          activeAgentTurn &&
          writeResult.activeSteerAgentIds?.includes(activeAgentTurn.agentPubkey)
        ) {
          setReceivedSteer({
            agentPubkey: activeAgentTurn.agentPubkey,
            turnRequestId: activeAgentTurn.requestId,
            receivedAt: Date.now(),
          });
        }
        if (desktopExperience) setDesktopDeliveryState('delivered');
        // The write ack retires the local bridge: the server has STORED the
        // message, so "sending…" has nothing left to bridge. It used to outlive
        // the write by up to the whole first-token wait (tens of seconds) or
        // its own 15s bound, whichever was longer. The claimed turn's WORKING
        // receipt lights `thinking` on its own, and this ack must not sit
        // between them.
        const ackedRequestId = preparedEvent.id;
        setPendingAck((current) =>
          current && (current.requestId === undefined || current.requestId === ackedRequestId)
            ? null
            : current,
        );
        // The server moved our read mark with the send itself, so a message we
        // wrote never golds the Room list (room-list-row.ts) and the viewport
        // has no mark left to write for it. The write receipt or live delta
        // paints the canonical message without a confirmation GET.
        acknowledgeReadMark(preparedEvent.id);
        return true;
      } catch (err) {
        console.warn('Send failed:', err);
        if (provisionalId && !preparedEvent) removeOptimistic(provisionalId);
        if (desktopExperience) setDesktopDeliveryState('failed');
        // A publish failure already gets its own explicit modal below; the
        // local ack has nothing left to guess at and must not keep buzzing.
        setPendingAck(null);
        if (preparedEvent) await markOutboxFailed(preparedEvent.id);
        const failure = publishFailurePresentation(err);
        Modal.alert(
          'Message not sent',
          failure.message,
          failure.retryable
            ? [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'Retry',
                  onPress: () => {
                    if (!preparedEvent || !preparedTransport) return;
                    retryOutboxMessage(preparedEvent.id, preparedTransport);
                  },
                },
              ]
            : [{ text: 'OK' }],
        );
        return false;
      } finally {
        sendInFlightRef.current = false;
        setSending(false);
      }
    },
    [
      captureUntaggedSend,
      isDirectMessage,
      activeCommunityId,
      attachmentUploader,
      replacePendingAttachments,
      transport,
      decodedId,
      addMessages,
      reconcileOptimistic,
      removeOptimistic,
      isArchived,
      isCorner,
      activeAgentTurn,
      userPubkey,
      parentChannelId,
      roomParticipants,
      roomAgents,
      cacheViewerPubkey,
      replyTarget,
      roomRepoCandidates.length,
      roomRepository,
      cornerAgentPubkey,
      agentPresences,
      presenceNow,
      presenceReconnectGrace,
      agentByPubkey,
      applyPendingAgentCommands,
      roomRepositoryResolved,
      roomRepoAccessIssue,
      roomSurface,
      desktopExperience,
      composerDraft,
      landAtOwnSend,
    ],
  );

  // Fill modals render outside the Room tree. Give the viewer the Room's live
  // messages and its signed/outbox-backed send path without a second socket.
  useFocusEffect(useCallback(() => {
    if (!roomSurface || !isFocused()) return;
    publishViewerConversation({
      roomId: decodedId,
      messages: roomSurface.messages,
      send: (message, dictated) => handleSend({ text: message.text, viewer: message }, dictated).then(Boolean),
    });
    return () => removeViewerConversation(decodedId);
  }, [decodedId, handleSend, isFocused, roomSurface]));

  // A row action needs the latest send state when tapped, without subscribing
  // every transcript cell to the send handler's draft and Room dependencies.
  const handleSendRef = useRef(handleSend);
  handleSendRef.current = handleSend;
  const handleCornerProposalDecision = useCallback(
    (message: ChatDisplayMessage, decision: 'open' | 'cancel') => {
      if (sendInFlightRef.current) return;
      const proposalReplyTarget = {
        ...replyTargetForMessage(message),
        ...(message.reference ? { reference: message.reference } : {}),
      };
      setCornerProposalAction({ messageId: message.id, decision });
      void handleSendRef.current({
        text: decision === 'open' ? 'go' : 'cancel',
        replyTarget: proposalReplyTarget,
      }).finally(() =>
        setCornerProposalAction((current) =>
          current?.messageId === message.id && current.decision === decision ? null : current,
        ),
      );
    },
    [replyTargetForMessage],
  );

  const pickPhoto = useCallback(async () => {
    const remaining = MAX_MESSAGE_ATTACHMENTS - pendingAttachments.length;
    if (remaining <= 0) {
      Modal.alert(
        'Attachment limit reached',
        `A message can include up to ${MAX_MESSAGE_ATTACHMENTS} attachments.`,
      );
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      selectionLimit: remaining,
      quality: 1,
      exif: false,
    });
    if (result.canceled || result.assets.length === 0) return;
    replacePendingAttachments((current) => [
      ...current,
      ...pickedPhotoAttachments(result.assets).slice(0, MAX_MESSAGE_ATTACHMENTS - current.length),
    ]);
  }, [pendingAttachments.length, replacePendingAttachments]);

  const pickDocument = useCallback(async () => {
    if (pendingAttachments.length >= MAX_MESSAGE_ATTACHMENTS) {
      Modal.alert(
        'Attachment limit reached',
        `A message can include up to ${MAX_MESSAGE_ATTACHMENTS} attachments.`,
      );
      return;
    }
    const result = await DocumentPicker.getDocumentAsync({
      copyToCacheDirectory: true,
      multiple: false,
      type: '*/*',
    });
    const asset = result.canceled ? undefined : result.assets[0];
    if (!asset) return;
    replacePendingAttachments((current) => [
      ...current,
      {
        uri: asset.uri,
        name: asset.name?.trim() || `file-${Date.now()}`,
        mimeType: asset.mimeType ?? 'application/octet-stream',
        size: asset.size ?? 0,
        source: 'file',
      },
    ]);
  }, [pendingAttachments.length, replacePendingAttachments]);

  const pasteImage = useCallback(async () => {
    if (pendingAttachments.length >= MAX_MESSAGE_ATTACHMENTS) {
      Modal.alert(
        'Attachment limit reached',
        `A message can include up to ${MAX_MESSAGE_ATTACHMENTS} attachments.`,
      );
      return;
    }
    if (!(await Clipboard.hasImageAsync())) {
      Modal.alert('Nothing to paste', 'Copy an image first, then try again.');
      return;
    }
    const image = await Clipboard.getImageAsync({ format: 'png' });
    if (!image) return;
    const attachment = await pastedImageAttachment(image);
    replacePendingAttachments((current) => [...current, attachment]);
  }, [pendingAttachments.length, replacePendingAttachments]);

  const chooseAttachment = useCallback(() => {
    setAttachmentPickerVisible(true);
  }, []);

  const selectMention = useCallback(
    (participant: RoomMemberOption) => {
      if (!activeMention) return;
      const inserted = replaceActiveMention(
        inputTextRef.current,
        activeMention,
        participant.handle,
      );
      if (participant.kind === 'agent') {
        selectedAgentMentionsRef.current.set(participant.handle, participant.pubkey);
      }
      // `@channel` (a broadcast) and `@system` (a report) are tokens, never
      // resolvable identities — neither may earn a picker→pubkey binding.
      recordMentionPick(selectedMentionsRef.current, participant);
      const nextSelection = { start: inserted.cursor, end: inserted.cursor };
      const completedMention = activeMentionAtCursor(inserted.text, inserted.cursor);
      inputTextRef.current = inserted.text;
      setInputText(inserted.text);
      setInputSelection((current) =>
        current.start === nextSelection.start && current.end === nextSelection.end
          ? current
          : nextSelection,
      );
      setDismissedMentionKey(
        completedMention
          ? `${inserted.text}:${completedMention.start}:${completedMention.end}`
          : null,
      );
      setHighlightedMentionIndex(0);
      scheduleAnimationFrame(() => {
        focusComposerSelection(
          composerRef.current,
          nextSelection,
          Platform.OS,
        );
      });
      void Haptics.selectionAsync();
    },
    [activeMention],
  );

  const selectChannel = useCallback(
    (suggestion: ChannelSuggestion) => {
      if (!activeChannel) return;
      const inserted = replaceActiveChannel(inputTextRef.current, activeChannel, suggestion.token);
      const nextSelection = { start: inserted.cursor, end: inserted.cursor };
      inputTextRef.current = inserted.text;
      setInputText(inserted.text);
      setInputSelection(nextSelection);
      setHighlightedMentionIndex(0);
      scheduleAnimationFrame(() => {
        focusComposerSelection(
          composerRef.current,
          nextSelection,
          Platform.OS,
        );
      });
      void Haptics.selectionAsync();
    },
    [activeChannel],
  );

  const handleWritePermission = useCallback(
    async (message: ChatDisplayMessage, decision: 'allow' | 'deny') => {
      const permission = message.writePermission;
      if (
        !transport ||
        !permission ||
        !permission.repository ||
        permission.status !== 'pending' ||
        viewerIsAgent ||
        (permission.purpose === 'squire-spending' && permission.ownerPubkey !== cacheViewerPubkey)
      )
        return;
      setPermissionActionId(permission.permissionId);
      try {
        await transport.respondToWritePermission(
          decodedId,
          permission.permissionId,
          permission.requestId,
          permission.agentPubkey,
          decision,
          permission.repository,
        );
        void Haptics.notificationAsync(
          decision === 'allow'
            ? Haptics.NotificationFeedbackType.Success
            : Haptics.NotificationFeedbackType.Warning,
        );
      } catch (err) {
        console.warn('Write permission response failed:', err);
      } finally {
        setPermissionActionId(null);
      }
    },
    [cacheViewerPubkey, decodedId, transport, viewerIsAgent],
  );

  /**
   * Answer a grant card. The server holds the authority (agent owner or a
   * Workspace manager, and the owner alone for a host MCP route) and refuses
   * anyone else; the card re-reads from the indexed Room, so nothing is
   * decided on the phone. A refusal leaves the card pending, so its reason is
   * shown: a visible control must act or explain itself.
   */
  const handleGrantDecision = useCallback(
    async (grantId: string, decision: 'always' | 'once' | 'deny') => {
      if (viewerIsAgent || grantActionId) return;
      setGrantActionId(grantId);
      try {
        await monolithPhoneOperation('decideAgentGrant', { grantId, decision });
        void Haptics.notificationAsync(
          decision === 'deny'
            ? Haptics.NotificationFeedbackType.Warning
            : Haptics.NotificationFeedbackType.Success,
        );
      } catch (err) {
        Modal.alert('Could not answer', phoneOperationFailureReason(err));
      } finally {
        setGrantActionId(null);
      }
    },
    [grantActionId, viewerIsAgent],
  );

  const handleChoiceAnswer = useCallback(
    async (choiceId: string, optionId: string, note?: string) => {
      if (viewerIsAgent || choiceActionId) return;
      setChoiceActionId(choiceId);
      try {
        await monolithPhoneOperation('answerChoice', {
          choiceId,
          optionId,
          ...(note ? { note } : {}),
        });
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (err) {
        refreshSignal.force();
        console.warn('Choice answer failed:', err);
        Modal.alert('Could not answer', phoneOperationFailureReason(err));
      } finally {
        setChoiceActionId(null);
      }
    },
    [choiceActionId, viewerIsAgent],
  );

  const handleChoiceSkip = useCallback(
    async (choiceId: string) => {
      if (viewerIsAgent || choiceActionId) return;
      setChoiceActionId(choiceId);
      try {
        await monolithPhoneOperation('skipChoice', { choiceId });
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      } catch (err) {
        console.warn('Choice skip failed:', err);
        Modal.alert('Could not skip', phoneOperationFailureReason(err));
      } finally {
        setChoiceActionId(null);
      }
    },
    [choiceActionId, viewerIsAgent],
  );

  const handleCreatePoll = useCallback(
    async (draft: PollDraft) => {
      if (createPollBusy) return false;
      setCreatePollBusy(true);
      try {
        await monolithPhoneOperation('createRoomPoll', { roomId: decodedId, ...draft });
        setCreatePollVisible(false);
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        return true;
      } catch (err) {
        Modal.alert('Could not create poll', phoneOperationFailureReason(err));
        return false;
      } finally {
        setCreatePollBusy(false);
      }
    },
    [createPollBusy, decodedId],
  );

  const openConnectorOfferCeremony = useCallback(
    (offerId: string, connectorType: string, pairedConnectorId: string, roomId = decodedId, directSignIn = false) => {
      router.push(
        connectorOfferCeremonyRoute({
          workspaceId: activeCommunityId ?? '',
          viewerId: cacheViewerPubkey,
          roomId,
          offerId,
          connectorType,
          pairedConnectorId,
          directSignIn,
        }) as Href,
      );
    },
    [activeCommunityId, cacheViewerPubkey, decodedId],
  );

  const continueConnectorOffer = useCallback(
    async (offerId: string, connectorType: string, pairedConnectorId: string, reconnect: boolean) => {
      try {
        if (reconnect) await monolithPhoneOperation('acceptConnectorOffer', { offerId });
        openConnectorOfferCeremony(offerId, connectorType, pairedConnectorId, decodedId, reconnect);
      } catch (err) {
        Modal.alert('Could not open sign-in', phoneOperationFailureReason(err));
      }
    },
    [openConnectorOfferCeremony, decodedId],
  );

  /**
   * Start a connector-offer ceremony. The server holds the authority, pairs
   * the offering helper, and returns its row; the phone immediately routes
   * that row through the existing Workbench install + sign-in screens. The
   * card and paused agent settle only when the helper reports connected.
   */
  const handleAcceptConnectorOffer = useCallback(
    async (offerId: string, connectorType: string) => {
      if (viewerIsAgent || connectorOfferActionId) return;
      setConnectorOfferActionId(offerId);
      try {
        const accepted = await monolithPhoneOperation('acceptConnectorOffer', { offerId });
        // A wallet offer settles in the acceptance itself: there is no
        // install or sign-in ceremony to open.
        if (accepted.status !== 'accepted') {
          openConnectorOfferCeremony(offerId, connectorType, accepted.connectorId, accepted.roomId);
        }
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (err) {
        console.warn('Connector offer acceptance failed:', err);
      } finally {
        setConnectorOfferActionId(null);
      }
    },
    [connectorOfferActionId, openConnectorOfferCeremony, viewerIsAgent],
  );

  /** The settled offer card's door to the Workbench page (Q3: one of its three remaining paths). */
  const openWorkbench = useCallback(() => {
    router.push({
      pathname: '/beeline/settings/workbench',
      params: {
        ...(activeCommunityId ? { workspaceId: activeCommunityId } : {}),
        ...(cacheViewerPubkey ? { viewerId: cacheViewerPubkey } : {}),
      },
    } as Href);
  }, [activeCommunityId, cacheViewerPubkey]);

  /**
   * Confirm a proposed target-branch change.
   *
   * The republished Room→repository event is signed by THIS viewer, so a
   * non-admin is refused here with a plain sentence rather than being allowed
   * to publish an event every reader would silently ignore. The SDK
   * (`setRoomTargetBranch`) and every reader re-check the role independently —
   * this guard is the clear answer, not the boundary.
   */
  const handleConfirmTargetBranch = useCallback(
    async (message: ChatDisplayMessage) => {
      const proposal = message.targetBranchProposal;
      if (!transport || !proposal || targetBranchActionId) return;
      if (viewerIsAgent || !canManageWorkspace) {
        setTargetBranchNotice({
          proposalId: proposal.proposalId,
          text: 'Only a workspace manager can change the target branch.',
        });
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        return;
      }
      setTargetBranchActionId(proposal.proposalId);
      setTargetBranchNotice(null);
      try {
        const result = await transport.roomTargetBranchSet(decodedId, proposal.to);
        applyRoomRepositoryResult(result);
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (err) {
        setTargetBranchNotice({
          proposalId: proposal.proposalId,
          text: err instanceof Error ? err.message : String(err),
        });
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      } finally {
        setTargetBranchActionId(null);
      }
    },
    [applyRoomRepositoryResult, canManageWorkspace, decodedId, targetBranchActionId, transport, viewerIsAgent],
  );

  const handleAddRoomMembers = useCallback(
    async (pubkeys: string[]) => {
      if (!transport || !activeCommunityId || !canManageWorkspace || addingMembers) return;
      const chosen = (participantPickerCandidates ?? []).filter(
        (candidate) =>
          pubkeys.includes(candidate.pubkey) && !roomMemberPubkeys.has(candidate.pubkey),
      );
      if (chosen.length === 0) return;
      setAddingMembers(true);
      setMembershipError(null);
      try {
        await transport.inviteRoomMembers(decodedId, chosen.map((candidate) => candidate.pubkey));
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setParticipantPickerVisible(false);
      } catch (err) {
        setMembershipError(`Could not add Room members: ${String(err)}`);
      } finally {
        setAddingMembers(false);
      }
    },
    [
      activeCommunityId,
      addingMembers,
      canManageWorkspace,
      decodedId,
      participantPickerCandidates,
      roomMemberPubkeys,
      transport,
    ],
  );

  const handleRemoveRoomMember = useCallback(
    async (participant: RoomMemberOption) => {
      if (!transport || !canManageWorkspace || participant.pubkey === userPubkey) return;
      const confirmed = await Modal.confirm(
        `Remove ${participant.name}?`,
        `Their membership will be removed and this ${ROOM_LABEL} will disappear from their workspace list.`,
        { cancelText: 'Cancel', confirmText: 'Remove', destructive: true },
      );
      if (!confirmed) return;
      setMembershipActionPubkey(participant.pubkey);
      setMembershipError(null);
      void transport
        .removeRoomMember(decodedId, participant.pubkey)
        .then(() => {
          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        })
        .catch((err) => {
          setMembershipError(`Could not remove ${participant.name}: ${String(err)}`);
        })
        .finally(() => setMembershipActionPubkey(null));
    },
    [canManageWorkspace, decodedId, transport, userPubkey],
  );

  // The picker's workspace-level rows. A one-person workspace has nobody to
  // add from the roster, so the same invite flows the Room-list "+" menu
  // reaches through the members screen live here too.
  const handleInvitePerson = useCallback(async () => {
    if (!activeCommunityId || !canManageWorkspace || memberInviteBusy) return;
    setMemberInviteBusy(true);
    setMembershipError(null);
    try {
      let inviteTransport = transport;
      if (!inviteTransport) {
        const identity = await loadBuzzIdentity();
        if (!identity) throw new Error('Beeline identity is unavailable');
        inviteTransport = new BuzzRigTransport(identity);
        setSessionTransport(inviteTransport);
      }
      const url = await createCommunityInviteUrl(
        await inviteTransport.ensureClient(),
        activeCommunityId,
        resolveCommunityInvitePublicOrigin(getBuzzRuntimeConfig()),
      );
      await Share.share({ message: url });
    } catch (reason) {
      setMembershipError(`Could not create person invite: ${String(reason)}`);
    } finally {
      setMemberInviteBusy(false);
    }
  }, [activeCommunityId, canManageWorkspace, memberInviteBusy, setSessionTransport, transport]);

  // A NEW agent: the pairing command lives on the Members page. An agent
  // already in the Workspace is a checkbox row in the picker itself.
  const handleConnectAgent = useCallback(() => {
    setParticipantPickerVisible(false);
    router.push({
      pathname: '/beeline/members',
      params: {
        ...(activeCommunityId ? { communityId: activeCommunityId } : {}),
        action: 'add-agent',
      },
    } as Href);
  }, [activeCommunityId]);

  const returnToRoomList = useCallback(() => {
    setRosterVisible(false);
    setRoomActionsVisible(false);
    router.replace({
      pathname: '/beeline/channels',
      ...(activeCommunityId ? { params: { communityId: activeCommunityId } } : {}),
    });
  }, [activeCommunityId]);

  const handleRoomLifecycle = useCallback(
    async (action: 'delete' | 'leave') => {
      if (!transport || (action === 'delete' && !canManageWorkspace) || roomLifecycleBusy) return;
      const deleting = action === 'delete';
      setRoomLifecycleBusy(true);
      setMembershipError(null);
      try {
        if (deleting) {
          const confirmed = await Modal.confirm(
            `Delete ${displayRoomName}?`,
            `This ${ROOM_LABEL} and its workspace data will be permanently deleted.`,
            {
              cancelText: 'Cancel',
              confirmText: `Delete ${ROOM_LABEL}`,
              destructive: true,
            },
          );
          if (!confirmed) return;
          await transport.deleteRoom(decodedId);
        } else {
          const title = roomTitle(displayRoomName) ?? displayRoomName;
          const left = await leaveRoomWithConfirmation(
            title,
            roomSurface?.leaveDeletesRoom === true,
            (confirmDelete) => transport.leaveRoom(decodedId, confirmDelete),
          );
          if (!left) return;
        }
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        returnToRoomList();
      } catch (err) {
        refreshSignal.force();
        setMembershipError(
          `Could not ${deleting ? 'delete' : 'leave'} ${ROOM_LABEL}: ${String(err)}`,
        );
      } finally {
        setRoomLifecycleBusy(false);
      }
    },
    [
      decodedId,
      displayRoomName,
      canManageWorkspace,
      roomSurface?.leaveDeletesRoom,
      returnToRoomList,
      roomLifecycleBusy,
      transport,
      userPubkey,
    ],
  );

  /** One dismissal for the Room actions sheet: the scrim, the Cancel row and
   *  the hardware back all land here, and a rename in flight holds it open. */
  const closeRoomActions = useCallback(() => {
    if (renameBusy) return;
    setRenameEditing(false);
    setRenameError(null);
    setRoomActionsVisible(false);
  }, [renameBusy]);

  const handleRenameRoom = useCallback(async () => {
    const name = renameDraft.trim();
    const kindLabel = isCorner ? CORNER_LABEL : ROOM_LABEL;
    if (!name) {
      setRenameError(`${kindLabel} name cannot be empty.`);
      return;
    }
    if (!isCorner && !validRoomSlug(name)) {
      setRenameError(ROOM_SLUG_HINT);
      return;
    }
    if (!transport || !canRenameTitle || renameBusy) return;

    setRenameBusy(true);
    setRenameError(null);
    const clearSubmitted = renameTextDraft.capture(false);
    const previousName = roomSurface?.room.name;
    applyRoomName(name);
    try {
      const client = await transport.ensureClient();
      await client.renameChannel(decodedId, name);
      clearSubmitted();
      setRenameEditing(false);
      setRoomActionsVisible(false);
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      if (previousName) applyRoomName(previousName, name);
      setRenameError(`Could not rename ${kindLabel}: ${String(err)}`);
    } finally {
      setRenameBusy(false);
    }
  }, [applyRoomName, canRenameTitle, decodedId, isCorner, renameBusy, renameDraft, renameTextDraft, roomSurface?.room.name, transport]);

  const startRenameFromTitle = useCallback(() => {
    if (!canRenameTitle) return;
    renameTextDraft.initialize(storedRoomName);
    setRenameError(null);
    setRenameEditing(true);
    if (!isCorner) setRoomActionsVisible(true);
  }, [canRenameTitle, isCorner, storedRoomName, renameTextDraft]);

  const handleOpenRandomCorner = useCallback(async (attempt?: CornerOpenAttempt) => {
    if (openingRandomCorner) return cornerOpenTappedAgain();
    if (isArchived || viewerIsAgent) return;
    if (!transport) {
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Modal.alert(
        'Not connected yet',
        `A new ${CORNER_LABEL} could not be opened because the app is still connecting to the server. Try again in a moment.`,
      );
      return;
    }
    setOpeningRandomCorner(true);
    const current = attempt ?? newCornerOpenAttempt();
    try {
      await openRandomNamedCorner({
        attempt: current,
        createCorner: (roomId, title, cornerId) =>
          transport.createHumanCorner(roomId, title, undefined, undefined, true, cornerId),
        // Inside a corner the new corner is a sibling under the parent Room.
        roomId: parentChannelId ?? decodedId,
        openCorner: (cornerId, title) => {
          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          if (desktopExperience) openDesktopCorner(parentChannelId ?? decodedId, cornerId);
          else router.push(cornerHref(cornerId, parentChannelId ?? decodedId, title));
        },
      });
    } catch (err) {
      alertCornerOpenFailure(err, parentChannelId ?? decodedId, () => void handleOpenRandomCorner(current));
    } finally {
      setOpeningRandomCorner(false);
    }
  }, [
    decodedId,
    desktopExperience,
    isArchived,
    openDesktopCorner,
    openingRandomCorner,
    parentChannelId,
    transport,
    viewerIsAgent,
  ]);

  /**
   * Mobile swipe-right asks first, through the shared bottom sheet — the same
   * presentation Room creation uses. The sheet holds the message while it is
   * open; declining creates nothing.
   */
  const handleForwardToNewCorner = useCallback(
    (message: ChatDisplayMessage) => {
      if (openingRandomCorner || isArchived || viewerIsAgent || desktopExperience) return;
      if (!transport) {
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        Modal.alert(
          'Not connected yet',
          `A new ${CORNER_LABEL} could not be opened because the app is still connecting to the server. Try again in a moment.`,
        );
        return;
      }
      void Haptics.selectionAsync();
      setForwardCornerPrompt(message);
    },
    [desktopExperience, isArchived, openingRandomCorner, transport, viewerIsAgent],
  );

  const confirmForwardToNewCorner = useCallback(async (
    retry?: { target: ChatDisplayMessage; attempt: CornerOpenAttempt },
  ) => {
    const target = retry?.target ?? forwardCornerPrompt;
    if (!target) return;
    if (openingRandomCorner || isArchived || viewerIsAgent || desktopExperience) return;
    if (!transport) return;
    setForwardCornerPrompt(null);
    setOpeningRandomCorner(true);
    const attempt = retry?.attempt ?? newCornerOpenAttempt();
    try {
      await forwardMessageToNewCorner({
        attempt,
        confirm: async () => true,
        forwardText: formatForwardedMessage(
          target.text,
          displayRoomName,
          target.authorIdentity ?? {
            name: target.pubkey ? fallbackMemberName(target.pubkey) : 'SOMEONE',
            ...(target.pubkey ? { handle: fallbackMemberHandle(target.pubkey) } : {}),
          },
          { roomId: decodedId, messageId: target.relayId ?? target.id },
        ),
        sourceMessageId: target.relayId ?? target.id,
        createCorner: (roomId, title, sourceMessageId, cornerId) =>
          transport.createHumanCorner(roomId, title, undefined, sourceMessageId, true, cornerId),
        // Inside a corner the new corner is a sibling under the parent Room.
        roomId: parentChannelId ?? decodedId,
        openCorner: (cornerId, title) => {
          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          if (desktopExperience) openDesktopCorner(parentChannelId ?? decodedId, cornerId);
          else router.push(cornerHref(cornerId, parentChannelId ?? decodedId, title));
        },
      });
    } catch (err) {
      alertCornerOpenFailure(
        err,
        parentChannelId ?? decodedId,
        () => void confirmForwardToNewCorner({ target, attempt }),
      );
    } finally {
      setOpeningRandomCorner(false);
    }
  }, [
    decodedId,
    desktopExperience,
    displayRoomName,
    forwardCornerPrompt,
    isArchived,
    openDesktopCorner,
    openingRandomCorner,
    parentChannelId,
    transport,
    viewerIsAgent,
  ]);

  const loadRoomRepoPicker = useCallback(
    async (refresh = false) => {
      if (!transport || !activeCommunityId || !githubScope) return;
      setRoomRepoListLoading(true);
      try {
        const access = await readGitHubAccess(transport, githubScope, refresh);
        setRoomRepoError(
          access.githubReconnectNeeded
            ? 'GitHub sign-in expired — reconnect GitHub in Settings to see new repositories.'
            : null,
        );
      } catch (error) {
        if (refresh) throw error;
        const candidates = await transport.workspaceRoomRepositoryCandidates();
        await writeGitHubAccess(githubScope, { installed: false, candidates,
          installations: [], githubReconnectNeeded: false });
      } finally {
        setRoomRepoListLoading(false);
      }
    },
    [activeCommunityId, transport, chatListRelayUrl, userPubkey],
  );

  const loadRoomRepoChoice = useCallback(async () => {
    if (!transport || !activeCommunityId) return;
    setRoomRepoError(null);
    try {
      await loadRoomRepoPicker(true);
    } catch (err) {
      setRoomRepoError('Could not load repos. Check your connection and try again.');
    }
  }, [activeCommunityId, loadRoomRepoPicker, transport]);

  const startGitHubInstallation = useCallback(
    async (installationId?: number) => {
      if (!transport) throw new Error('GitHub transport is unavailable');
      return transport.githubInstallationStart(githubInstallationRedirectUri(), installationId);
    },
    [transport],
  );
  const refreshGitHubRepositories = useCallback(
    () => loadRoomRepoPicker(true),
    [loadRoomRepoPicker],
  );
  const resumeRoomRepoPicker = useCallback(() => {
    setShowRoomRepoPicker(true);
  }, []);
  const { handleAddGitHubAccount, handleManageGitHubInstallation } = useGitHubInstallationSession({
    ready: Boolean(transport && activeCommunityId),
    returnPath: `/beeline/chat/${encodeURIComponent(decodedId)}`,
    startInstallation: startGitHubInstallation,
    refreshRepositories: refreshGitHubRepositories,
    onError: setRoomRepoError,
    onNotice: setRoomRepoNotice,
    onColdResume: resumeRoomRepoPicker,
  });

  const applyRoomRepository = useCallback(
    async (input: RepoCandidate) => {
      if (!transport || !input.remote || roomRepoBusy) return;
      setRoomRepoBusy(true);
      setRoomRepoError(null);
      try {
        // A candidate without a connected installation may be a repository the
        // App never covered (an admin binding a repo whose OWNER has not
        // granted access). Probe the typed coverage state first: binding now
        // would only dead-end the daemon's token path later.
        if (!input.githubInstallationId) {
          const access = await transport.githubRepositoryAccess(input.name).catch(() => undefined);
          if (access && access.accessible === false && access.reason !== 'revoked') {
            uncoveredOwnersRef.current.add(input.name.split('/')[0]?.toLowerCase() ?? '');
            if (access.installUrl) {
              setOwnerGrant({ repository: input.name, installUrl: access.installUrl });
              return;
            }
          }
        }
        const published = await transport.roomRepositorySet(decodedId, {
          key: input.key,
          name: input.name,
          remote: input.remote,
          ...(input.githubInstallationId
            ? { githubInstallationId: input.githubInstallationId }
            : {}),
          ...(input.defaultBranch ? { targetBranch: input.defaultBranch } : {}),
          ...(activeCommunityId ? { communityId: activeCommunityId } : {}),
        });
        applyRoomRepositoryResult(published);
        setShowRoomRepoPicker(false);
        setCornerOpenRepoPrompt(false);
        setOwnerGrant(null);
      } catch (err) {
        setRoomRepoError(`Could not link repo: ${String(err)}`);
      } finally {
        setRoomRepoBusy(false);
      }
    },
    [activeCommunityId, applyRoomRepositoryResult, decodedId, roomRepoBusy, transport],
  );

  // The pasted repository's owner is not among this viewer's installations:
  // resolve the typed coverage state and share the owner's install link
  // instead of opening a connect flow that can never grant a foreign repo.
  const handleAskOwnerGrant = useCallback(
    async (fullName: string) => {
      if (!transport) return;
      setOwnerGrant(null);
      const access = await transport.githubRepositoryAccess(fullName).catch(() => undefined);
      uncoveredOwnersRef.current.add(fullName.split('/')[0]?.toLowerCase() ?? '');
      if (access?.installUrl) {
        setOwnerGrant({ repository: fullName, installUrl: access.installUrl });
        void Share.share({
          message: ownerGrantShareMessage({ repository: fullName, installUrl: access.installUrl }),
        });
        return;
      }
      setRoomRepoNotice(
        access?.accessible
          ? `${fullName} is already available below.`
          : `Could not confirm GitHub coverage for ${fullName}. Try again once the owner has installed the app.`,
      );
    },
    [transport],
  );

  const handleCreateGitHubRepository = useCallback(
    async (installationId: number, name: string) => {
      if (!transport) return;
      setRoomRepoError(null);
      try {
        const candidate = await transport.githubRepositoryCreate({
          installationId,
          name,
          private: true,
        });
        if (githubScope) await updateGitHubAccess(githubScope,
          (current) => ({ ...current, candidates: [...current.candidates, candidate] }));
        await applyRoomRepository(candidate);
      } catch (err) {
        setRoomRepoError(`Could not create repo: ${String(err)}`);
        throw err;
      }
    },
    [applyRoomRepository, transport],
  );

  const {
    openCornerCount,
    selectCandidate: handleSelectRoomRepoCandidate,
    createRepository: handleCreateRoomRepository,
  } = useRoomRepoReplacementGuard(parentChannelId ?? decodedId, roomRepository, {
    link: applyRoomRepository,
    create: handleCreateGitHubRepository,
  });

  // Unassigning the repo is the inverse of linking it: the Room becomes
  // chat-only. It is confirmed like the other destructive Room actions, and
  // the confirm text carries the one room-side consequence that matters —
  // open corners keep their own repo copies, nothing else moves.
  const handleUnlinkRoomRepository = useCallback(async () => {
    if (!transport || !roomRepository || roomRepoBusy) return;
    const hasOpenCorners = openCornerCount > 0;
    const confirmed = await Modal.confirm(
      `Unlink ${roomRepository.binding.name}?`,
      hasOpenCorners
        ? `This ${ROOM_LABEL} becomes chat-only. Open ${CORNER_LABEL}s keep their copies of the repo; messages and history are untouched.`
        : `This ${ROOM_LABEL} becomes chat-only. Messages and history are untouched.`,
      { cancelText: 'Cancel', confirmText: 'Unlink repo', destructive: true },
    );
    if (!confirmed) return;
    setRoomRepoBusy(true);
    setRoomRepoError(null);
    try {
      await transport.roomRepositoryRemove(decodedId);
      clearRoomRepository();
      setShowRoomRepoPicker(false);
    } catch {
      setRoomRepoError('Could not unlink the repository.');
    } finally {
      setRoomRepoBusy(false);
    }
  }, [clearRoomRepository, decodedId, openCornerCount, roomRepoBusy, roomRepository, transport]);

  const roomRepoChoice = useRoomRepositoryChoice({
    visible: roomActionsVisible,
    canManage: canManageWorkspace,
    roomName: roomSurface?.room.name ?? '',
    current: roomRepository?.binding ?? null,
    candidates: roomRepoCandidates,
    installations: githubInstallations,
    loading: roomRepoListLoading,
    busy: roomRepoBusy,
    error: roomRepoError,
    notice: roomRepoNotice,
    listOpen: showRoomRepoPicker,
    setListOpen: setShowRoomRepoPicker,
    onLoad: () => void loadRoomRepoChoice(),
    onConnect: () => void handleAddGitHubAccount(),
    onLink: handleSelectRoomRepoCandidate,
    onCreate: handleCreateRoomRepository,
    onUnlink: () => void handleUnlinkRoomRepository(),
    onCancel: closeRoomActions,
    draftContext: decodedId,
  });

  const handleReconnectRoomRepository = useCallback(async () => {
    if (!roomRepoAccessIssue || !transport) return;
    setRoomRepoError(null);
    setRoomRepoNotice('Refreshing repositories…');
    let candidates: RepoCandidate[];
    let installations: GitHubInstallationAccess[];
    try {
      if (!githubScope) return;
      const access = await readGitHubAccess(transport, githubScope, true);
      candidates = access.candidates;
      installations = access.installations;
      setRoomRepoNotice(null);
    } catch {
      setRoomRepoNotice(null);
      setRoomRepoError('Could not refresh repositories. Return to Beeline and try again.');
      return;
    }
    const plan = githubRepositoryLinkagePlan(
      roomRepoAccessIssue.fullName,
      candidates,
      installations,
    );
    if (plan.kind === 'available') {
      setRoomRepoAccessIssue(null);
      setCornerOpenRepoPrompt(false);
      return;
    }
    const confirmed = await Modal.confirm(
      'Choose repositories on GitHub',
      GITHUB_REPOSITORY_SELECTION_INSTRUCTION,
      { cancelText: 'Cancel', confirmText: 'Continue to GitHub' },
    );
    if (!confirmed) return;
    if (plan.kind === 'manage') void handleManageGitHubInstallation(plan.installation);
    else void handleAddGitHubAccount();
  }, [handleAddGitHubAccount, handleManageGitHubInstallation, roomRepoAccessIssue, transport]);

  /**
   * Leave this transcript. A screen opened from a notification or a list
   * returns to that list; otherwise it pops to the screen it was opened from.
   * See `corner-navigation.ts`. A lone transcript replaces itself instead of
   * calling a `router.back()` that silently does nothing.
   */
  const handleBack = useCallback(() => {
    // Stop the live-draft drain before the stack moves. The scheduler otherwise
    // keeps ticking on a still-mounted Room (native-stack does not unmount on
    // blur) and a back press waits until the turn's text is ready to paint.
    liveDraftStore.setActive(false);
    const routes = (navigation.getState()?.routes ?? []) as ChatStackRoute[];
    const action = chatBackAction(routes, parentChannelId, cornerReturnTarget);
    if (action.type === 'pop') router.dismiss(action.count);
    // A lone corner (for example, an older link without an origin hint) has
    // nothing to pop to, so open its parent Room.
    else if (action.type === 'open-room') router.replace(roomHref(action.channelId));
    // A corner opened from a Room's corners screen lands back on that screen
    // even when the list is not on the stack — never the parent Room.
    else if (action.type === 'open-corners') router.replace(roomCornersHref(action.roomId));
    else if (action.type === 'back') router.back();
    else router.replace('/beeline/channels');
  }, [cornerReturnTarget, liveDraftStore, navigation, parentChannelId]);

  const closeCornerPending = useRef(false);
  const handleCloseCorner = useCallback(async () => {
    if (closeCornerPending.current) return;
    closeCornerPending.current = true;
    try {
      if (!transport) throw new Error('Still connecting. Try again in a moment.');
      await transport.closeCorner(decodedId);
      handleBack();
    } catch (error) {
      refreshSignal.force();
      Modal.alert('Could not close corner', error instanceof Error ? error.message : String(error));
    } finally {
      closeCornerPending.current = false;
    }
  }, [decodedId, handleBack, transport, refreshSignal]);

  const handleCommunitySelect = useCallback((communityId: string | null) => {
    if (!communityId) return;
    router.replace({
      pathname: '/beeline/channels',
      params: { communityId },
    });
  }, []);

  const openCorner = useCallback(
    (subchannelId: string | undefined) => {
      const action = cornerOpenAction(subchannelId, decodedId);
      if (action.type === 'explain') {
        Modal.alert('Corner unavailable', action.message);
        return;
      }
      if (desktopExperience) openDesktopCorner(decodedId, action.cornerId);
      else router.push(cornerHref(action.cornerId, decodedId));
    },
    [decodedId, desktopExperience, openDesktopCorner],
  );

  const closeDesktopWorkPane = useCallback(() => {
    commitDesktopWorkPane({ type: 'close' });
  }, [commitDesktopWorkPane]);

  // Expand moves the corner into the primary view and closes the pane.
  const expandDesktopCorner = useCallback(
    (cornerId: string) => {
      commitDesktopWorkPane({ type: 'expand' });
      router.push(cornerHref(cornerId, desktopWorkRoomId));
    },
    [commitDesktopWorkPane, desktopWorkRoomId],
  );

  useEffect(() => {
    if (!desktopExperience || Platform.OS !== 'web' || typeof window === 'undefined') return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (
        (event.metaKey || event.ctrlKey) &&
        event.shiftKey &&
        event.key.toLowerCase() === 'm'
      ) {
        event.preventDefault();
        focusComposer();
      } else if (event.key === 'Escape' && profileAgentId) {
        event.preventDefault();
        setProfileAgentId(null);
      } else if (event.key === 'Escape' && desktopWorkPaneMounted) {
        event.preventDefault();
        closeDesktopWorkPane();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    closeDesktopWorkPane,
    desktopExperience,
    desktopWorkPaneMounted,
    focusComposer,
    profileAgentId,
  ]);

  const handleDesktopDrop = useCallback(
    (event: React.DragEvent<HTMLElement>) => {
      if (!desktopExperience || sending) return;
      event.preventDefault();
      const files = Array.from(event.dataTransfer.files).slice(
        0,
        MAX_MESSAGE_ATTACHMENTS - pendingAttachments.length,
      );
      if (!files.length) return;
      replacePendingAttachments((current) => [
        ...current,
        ...files.map((file) => ({
          uri: URL.createObjectURL(file),
          name: file.name || `file-${Date.now()}`,
          mimeType: file.type || 'application/octet-stream',
          size: file.size,
          source: 'file' as const,
        })),
      ]);
    },
    [desktopExperience, pendingAttachments.length, replacePendingAttachments, sending],
  );

  const handleDesktopPaste = useCallback(
    (event: ClipboardEvent) => {
      if (!desktopExperience || sending) return;
      const files = Array.from(event.clipboardData?.files ?? []).slice(
        0,
        MAX_MESSAGE_ATTACHMENTS - pendingAttachments.length,
      );
      if (!files.length) return;
      event.preventDefault();
      replacePendingAttachments((current) => [
        ...current,
        ...files.map((file) => ({
          uri: URL.createObjectURL(file),
          name: file.name || `clipboard-${Date.now()}`,
          mimeType: file.type || 'application/octet-stream',
          size: file.size,
          source: 'file' as const,
        })),
      ]);
    },
    [desktopExperience, pendingAttachments.length, replacePendingAttachments, sending],
  );

  const clearSlashComposer = useCallback(() => {
    inputTextRef.current = '';
    setInputText('');
    setInputSelection({ start: 0, end: 0 });
    setComposerHeight(COMPOSER_MIN_HEIGHT);
    setDismissedSlashText(null);
    setHighlightedSlashVerbIndex(0);
    scheduleAnimationFrame(() => composerRef.current?.focus());
  }, []);

  const dismissSlashMenu = useCallback(() => {
    clearSlashComposer();
    void Haptics.selectionAsync();
  }, [clearSlashComposer]);

  /**
   * Insert a selected agent command in place of the typed `/query` token,
   * KEEPING the @mention that scoped the palette. The trailing space closes
   * the palette and leaves the composer ready for the command's arguments.
   */
  const insertAgentCommand = useCallback(
    (name: string) => {
      const next = insertAgentSlashCommand(inputText, name);
      inputTextRef.current = next;
      setInputText(next);
      setInputSelection({ start: next.length, end: next.length });
      setComposerHeight(COMPOSER_MIN_HEIGHT);
      void Haptics.selectionAsync();
    },
    [inputText],
  );

  /**
   * Fast mode is the owner's toggle, not text: it writes through the same
   * `updateAgentModelSelection` operation as the profile switch and leaves
   * the palette open on the new state.
   */
  const toggleAgentFastMode = useCallback(async () => {
    const pubkey = mentionSlashAgentPubkey;
    const scope = mentionAgentCommandScope;
    const current = scope ? agentFastModeByScope[scope] : null;
    if (!pubkey || !scope || !current || current.status === 'saving' || !activeCommunityId) {
      return;
    }
    const enabled = !current.enabled;
    setAgentFastModeByScope((state) => ({
      ...state,
      [scope]: { enabled: current.enabled, status: 'saving' },
    }));
    void Haptics.selectionAsync();
    try {
      let writeTransport = transport;
      if (!writeTransport) {
        const identity = await loadBuzzIdentity();
        if (!identity) throw new Error('Beeline identity is unavailable');
        writeTransport = new BuzzRigTransport(identity);
        setSessionTransport(writeTransport);
      }
      const client = await writeTransport.ensureClient();
      await client.setAgentModelConfig(activeCommunityId, pubkey, { fastMode: enabled });
      setAgentFastModeByScope((state) => ({ ...state, [scope]: { enabled } }));
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {
      setAgentFastModeByScope((state) => ({
        ...state,
        [scope]: { enabled: current.enabled, status: 'failed' },
      }));
    }
  }, [
    activeCommunityId,
    agentFastModeByScope,
    mentionAgentCommandScope,
    mentionSlashAgentPubkey,
    setSessionTransport,
    transport,
  ]);

  const selectAgentCommand = useCallback(
    (name: string) => {
      if (name === FAST_MODE_COMMAND) {
        void toggleAgentFastMode();
        return;
      }
      insertAgentCommand(name);
    },
    [insertAgentCommand, toggleAgentFastMode],
  );

  const runSlashVerb = useCallback(
    (verb: BuiltInSlashVerbId) => {
      clearSlashComposer();
      void Haptics.selectionAsync();
      switch (verb) {
        case 'build':
          router.push(roomCornersHref(decodedId));
          return;
        case 'poll':
          setCreatePollVisible(true);
          return;
        case 'schedule':
          if (!canManageWorkspace || !activeCommunityId) return;
          router.push({
            pathname: '/beeline/settings/schedules',
            params: { roomId: decodedId, workspaceId: activeCommunityId },
          } as unknown as Href);
          return;
        case 'workflow':
          if (!canManageWorkspace) return;
          router.push({
            pathname: '/beeline/settings/workflows',
            params: { roomId: decodedId },
          } as unknown as Href);
          return;
        case 'open-corner':
          if (pendingCornerRequest) void handleWritePermission(pendingCornerRequest, 'allow');
          return;
        case 'rename':
          startRenameFromTitle();
          return;
        case 'close-corner':
          void handleCloseCorner();
          return;
        case 'change-target-branch':
          if (pendingTargetBranchProposal) {
            void handleConfirmTargetBranch(pendingTargetBranchProposal);
          }
          return;
        case 'add-agent':
          if (!canManageWorkspace) {
            handleConnectAgent();
            return;
          }
          setMembershipError(null);
          setParticipantPickerKind('agent');
          setParticipantPickerVisible(true);
          return;
        case 'invite':
          if (!canManageWorkspace) return;
          setMembershipError(null);
          setParticipantPickerKind('person');
          setParticipantPickerVisible(true);
      }
    },
    [
      clearSlashComposer,
      activeCommunityId,
      canManageWorkspace,
      decodedId,
      handleCloseCorner,
      handleConnectAgent,
      handleConfirmTargetBranch,
      handleWritePermission,
      pendingCornerRequest,
      pendingTargetBranchProposal,
      startRenameFromTitle,
    ],
  );

  const openCornerApp = useCallback(
    (slug: string) => {
      clearSlashComposer();
      void Haptics.selectionAsync();
      router.push({
        pathname: '/beeline/corner-app/[slug]',
        params: { slug, roomId: decodedId },
      } as Href);
    },
    [clearSlashComposer, decodedId],
  );

  /** Select whatever the highlight points at across commands-then-verbs. */
  const selectHighlightedPaletteItem = useCallback(() => {
    const commandIndex = highlightedSlashVerbIndex - mentionAgentCommands.length;
    if (commandIndex < 0) {
      const command = mentionAgentCommands[highlightedSlashVerbIndex];
      if (command) {
        selectAgentCommand(command.name);
        return;
      }
    } else if (commandIndex < cornerAppCommands.length) {
      const app = cornerAppCommands[commandIndex];
      if (app) {
        openCornerApp(app.slug);
        return;
      }
    } else {
      const verb = slashVerbs[commandIndex - cornerAppCommands.length];
      if (verb) {
        runSlashVerb(verb.id);
        return;
      }
    }
    // No match at all: Enter/the send button passes the text through as an
    // ordinary message instead of dying as a dead end. The daemon visibly
    // marks such text on the other side.
    handleSend();
  }, [
    handleSend,
    highlightedSlashVerbIndex,
    selectAgentCommand,
    inputText,
    cornerAppCommands,
    mentionAgentCommands,
    openCornerApp,
    runSlashVerb,
    slashVerbs,
  ]);

  const handleOpenGitHubEvent = useCallback((url: string) => {
    void openExternalUrl(url).catch(() => undefined);
  }, []);
  // A name in a system line opens the roster, where that identity lives.
  const handleOpenSystemIdentity = useCallback(() => {
    router.push({
      pathname: '/beeline/members',
      params: activeCommunityId ? { communityId: activeCommunityId } : {},
    } as Href);
  }, [activeCommunityId]);
  const handleCopyLedgerMessage = useCallback((text: string) => {
    void copyEntireTurn(text, Clipboard.setStringAsync);
  }, []);
  const handleSelectLedgerMessage = useCallback((text: string) => {
    const textId = storeTempText(text);
    router.push({ pathname: '/text-selection', params: { textId } } as Href);
  }, []);
  const rowActions = useScopedCallbacks({
    handleWritePermission,
    beginForward,
    handleForwardToNewCorner,
    handleConfirmTargetBranch,
    retryOutboxMessage,
    handleOpenChannelReference,
    handleOpenMention
  }, `${decodedId}\0${cacheViewerPubkey}`);
  const renderMessage = useCallback(
    (
      item: ChatDisplayMessage,
      {
        continued: attributionContinued,
        immediatelyPrecedingMessage,
        referencedMessage,
        firstBylineOfDay,
        untaggedHint,
        deliveryFailed = false,
        speakerWorking: rowSpeakerWorking = false,
        cornerProposalAnswer,
        cornerProposalAction: rowCornerProposalAction,
      }: RoomMessageRenderContext,
    ) => {
      // An agent's order or report is ordinary transcript: the recipient leads
      // the text as an @mention and the row keeps its own author's byline.
      item = agentCommandTranscriptMessage(item, roomParticipants);
      if (item.roomUpdate) {
        return (
          <LedgerRoomUpdate
            id={item.id}
            line={item.text}
            stamp={ledgerStamp(item.timestamp)}
            digest={item.roomUpdate.digest}
          />
        );
      }

      if (item.writePermission) {
        return (
          <WritePermissionCard
            message={item}
            roomName={roomName}
            agent={agentByPubkey.get(item.writePermission.agentPubkey)}
            viewerIsAgent={viewerIsAgent}
            viewerPubkey={cacheViewerPubkey}
            viewerCanManage={canManageWorkspace}
            actionId={permissionActionId}
            targetBranch={roomRepository?.targetBranch}
            onDecision={rowActions.handleWritePermission}
            onOpenCorner={openCorner}
          />
        );
      }

      if (item.grantRequest) {
        return (
          <GrantRequestCard
            message={item}
            agent={agentByPubkey.get(item.grantRequest.agent.pubkey)}
            viewerIsAgent={viewerIsAgent}
            viewerPubkey={cacheViewerPubkey}
            viewerCanManageWorkspace={canManageWorkspace}
            actionId={grantActionId}
            onDecision={handleGrantDecision}
            onOpenSource={(roomId, messageId) =>
              router.navigate(messageJumpHref(roomId, messageId, `squire-grant:${item.id}`))
            }
          />
        );
      }
      if (item.squireApproval) {
        return (
          <SquireApprovalCard
            message={item}
            agent={agentByPubkey.get(item.squireApproval.agent.pubkey)}
            viewerPubkey={cacheViewerPubkey}
            onOpenSource={(roomId, messageId) =>
              router.navigate(messageJumpHref(roomId, messageId, `squire-approval:${item.id}`))
            }
          />
        );
      }
      if (item.computerSession) {
        return (
          <ComputerSessionCard session={item.computerSession} isDesktop={desktopExperience}
          agentHandle={item.authorIdentity?.kind === 'agent' ? item.authorIdentity.handle : undefined} />
        );
      }
      // The active call lives below the Room header; ended calls use LedgerSystemLine.
      if (item.voiceCall && !item.voiceCall.endedAt) return null;
      if (item.onboarding) return <RepositoryOnboardingCard card={item.onboarding} viewerId={cacheViewerPubkey} author={item.authorIdentity} />;
      if (item.choice) {
        return (
          <ChoiceCard
            message={item}
            agent={agentByPubkey.get(item.choice.agent.pubkey)}
            viewerIsAgent={viewerIsAgent}
            viewerPubkey={cacheViewerPubkey}
            actionId={choiceActionId}
            onAnswer={handleChoiceAnswer}
            onSkip={handleChoiceSkip}
          />
        );
      }

      if (item.appSignIn) {
        const card = item.appSignIn;
        const agentName = resolveAgentDisplayIdentity(
          card.agentId,
          agentByPubkey.get(card.agentId),
        ).name;
        return (
          <AppSignInCard
            message={item}
            agentName={agentName}
            canConnect={!viewerIsAgent && cacheViewerPubkey === card.ownerId}
            busy={appSignInActionId === card.appId}
            onConnect={() => {
              if (appSignInActionId || viewerIsAgent || cacheViewerPubkey !== card.ownerId) return;
              setAppSignInActionId(card.appId);
              void monolithPhoneOperation('beginAppSignIn', { appId: card.appId })
                .then((result) =>
                  openAppSignIn(result.authorizationUrl, {
                    workspaceId: activeCommunityId ?? '',
                    viewerId: cacheViewerPubkey,
                    roomId: decodedId,
                    appId: card.appId,
                  }),
                )
                .catch((error) =>
                  Modal.alert('Could not connect app', phoneOperationFailureReason(error)),
                )
                .finally(() => setAppSignInActionId(null));
            }}
          />
        );
      }
      if (item.agentSignIn) {
        const card = item.agentSignIn;
        const agentName = resolveAgentDisplayIdentity(
          card.agentId,
          agentByPubkey.get(card.agentId),
        ).name;
        return (
          <AgentSignInCard
            card={card}
            agentName={agentName}
            isOwner={!viewerIsAgent && cacheViewerPubkey === card.ownerId}
            onSubmit={async (code) => {
              try {
                await monolithPhoneOperation('completeAgentSignIn', {
                  roomId: decodedId,
                  messageId: item.id,
                  code,
                });
              } catch (error) {
                throw new Error(phoneOperationFailureReason(error));
              }
            }}
            testID={`agent-sign-in-${item.id}`}
          />
        );
      }
      if (item.connectorOffer) {
        return (
          <ConnectorOfferCard
            message={item}
            agent={agentByPubkey.get(item.connectorOffer.agent.pubkey)}
            viewerIsAgent={viewerIsAgent}
            viewerPubkey={cacheViewerPubkey}
            viewerCanManage={canManageWorkspace}
            actionId={connectorOfferActionId}
            onAccept={handleAcceptConnectorOffer}
            onDecline={async offerId => {
              if (connectorOfferActionId) return;
              setConnectorOfferActionId(offerId);
              try { await monolithPhoneOperation('decideApprovalCard', { roomId: decodedId, messageId: item.id, decision: 'deny' }); }
              catch (error) { Modal.alert('Could not decline', phoneOperationFailureReason(error)); }
              finally { setConnectorOfferActionId(null); }
            }}
            onContinue={(offerId, connectorType, pairedConnectorId) =>
              void continueConnectorOffer(offerId, connectorType, pairedConnectorId, item.connectorOffer!.intent === 'reconnect')
            }
            onOpenWorkbench={openWorkbench}
          />
        );
      }

      if (item.notificationLifecycleRun) {
        return (
          <NotificationLifecycleCard
            message={item}
            cornerId={isCorner ? decodedId : undefined}
            onOpenCorner={openCorner}
            onOpenUrl={handleOpenGitHubEvent}
          />
        );
      }


      if (item.walletTx || item.walletInsufficient || item.walletDelegation) {
        return <WalletCards message={item} stamp={ledgerStamp(item.timestamp)} />;
      }

      if (item.targetBranchProposal) {
        const notice =
          targetBranchNotice?.proposalId === item.targetBranchProposal.proposalId
            ? targetBranchNotice.text
            : null;
        return (
          <TargetBranchProposalCard
            message={item}
            roomName={roomName}
            agent={
              item.targetBranchProposal.agentPubkey
                ? agentByPubkey.get(item.targetBranchProposal.agentPubkey)
                : undefined
            }
            currentTargetBranch={roomRepository?.targetBranch}
            canManageWorkspace={canManageWorkspace}
            viewerIsAgent={viewerIsAgent}
            actionId={targetBranchActionId}
            notice={notice}
            onConfirm={rowActions.handleConfirmTargetBranch}
            viewerPubkey={cacheViewerPubkey}
            onDeny={async () => {
              if (targetBranchActionId) return;
              setTargetBranchActionId(item.targetBranchProposal!.proposalId);
              try { await monolithPhoneOperation('decideApprovalCard', { roomId: decodedId, messageId: item.id, decision: 'deny' }); }
              catch (error) { Modal.alert('Could not decline', phoneOperationFailureReason(error)); }
              finally { setTargetBranchActionId(null); }
            }}
          />
        );
      }
      if (item.cornerApp) {
        return (
          <CornerAppRow
            title={item.cornerApp.title}
            onOpen={() => openCornerApp(item.cornerApp!.slug)}
          />
        );
      }
      if (item.corner) {
        return null;
      }


      if (item.githubEvent) {
        return <GitHubEventCard message={item} onOpenCorner={openCorner} onOpenUrl={handleOpenGitHubEvent} />;
      }

      if (item.daemonFact) {
        return (
          <View>
            <DaemonFactCard
              message={item}
              onOpenCorner={openCorner}
              onOpenUrl={handleOpenGitHubEvent}
            />
          </View>
        );
      }

      // ── Archived notice ──────────────────────────────────────────
      if (item.isArchivedNotice) {
        return (
          <View style={styles.archivedBubble}>
            <Text style={styles.archivedText}>□ CORNER ARCHIVED · READ-ONLY</Text>
          </View>
        );
      }

      // ── System line: one renderer for every server-phrased notification ──
      if (item.isSystemNotice) {
        return (
          <LedgerSystemLine
            id={item.id}
            text={item.text}
            {...(item.systemEvent ? { event: item.systemEvent } : {})}
            stamp={ledgerStamp(item.timestamp)}
            onOpenIdentity={handleOpenSystemIdentity}
            onOpenUrl={handleOpenGitHubEvent}
            onOpenBrief={openCurrentBrief}
          />
        );
      }

      if (item.durableFact) {
        return (
          <LedgerRoomUpdate
            id={item.id}
            line={durableFactLine(item)}
            stamp={ledgerStamp(item.timestamp)}
            tone={item.durableFact.kind === 'failure' ? 'brass' : 'quiet'}
          />
        );
      }

      const knownAgent = item.pubkey ? agentByPubkey.get(item.pubkey) : undefined;
      const personName = item.pubkey ? personProfileByPubkey.get(item.pubkey)?.name : undefined;
      const referencedTarget = referencedMessage
        ? replyTargetForMessage(referencedMessage)
        : undefined;
      const ledgerMessage = (
        <OrdinaryLedgerMessage
          message={item}
          firstBylineOfDay={firstBylineOfDay}
          // The byline shows the agent's model from its profile; an agent
          // with no profile model keeps the plain `AGENT` word.
          agentModel={item.pubkey ? agentProfileModelByPubkey.get(item.pubkey) : undefined}
          desktopLayout={isDesktop}
          announcementFeed={isReadOnlyDirectMessage}
          {...(knownAgent ? { agent: knownAgent } : {})}
          participantsHydrated={participantsHydrated}
          {...(personName ? { personName } : {})}
          viewerPubkey={cacheViewerPubkey}
          speakerWorking={rowSpeakerWorking}
          continued={attributionContinued}
          {...(immediatelyPrecedingMessage ? { immediatelyPrecedingMessage } : {})}
          {...(referencedTarget ? { referencedTarget } : {})}
          participantHandles={roomParticipants}
          channelIndex={channelReferenceIndex}
          untaggedHint={untaggedHint}
          deliveryFailed={deliveryFailed}
          onChannelReference={rowActions.handleOpenChannelReference}
          codeRoomId={decodedId}
          onOpenCode={handleOpenCode}
          onOpenSource={handleOpenMessageSource}
          onMention={rowActions.handleOpenMention}
          onOpenProfile={handleOpenProfile}
          onTapOutsideComposer={dismissComposerKeyboard}
          onReply={beginReply}
          onCopy={handleCopyLedgerMessage}
          onMessageActions={openMessageActions}
          onReact={handleReactToMessage}
          onForward={rowActions.beginForward}
          onBookmark={handleBookmarkMessage}
          onReportIssue={handleReportMessage}
          {...(!isDirectMessage && !isArchived && !viewerIsAgent && !desktopExperience
            ? { onForwardToNewCorner: rowActions.handleForwardToNewCorner }
            : {})}
          {...(!isCorner &&
          !isArchived &&
          !viewerIsAgent &&
          !isReadOnlyDirectMessage &&
          !cornerProposalAnswer
            ? { onCornerProposalDecision: handleCornerProposalDecision }
            : {})}
          cornerProposalAnswer={cornerProposalAnswer}
          cornerProposalAction={rowCornerProposalAction}
          onRetry={rowActions.retryOutboxMessage}
          onDismiss={dismissOutboxMessage}
        />
      );
      return item.cornerMarkers?.length ? (
        <View>
          {ledgerMessage}
          <CornerOpenedMarkers message={item} onOpenCorner={openCorner} onOpenUrl={handleOpenGitHubEvent} />
        </View>
      ) : (
        ledgerMessage
      );
    },
    [
      rowActions,
      openCorner,
      isDirectMessage,
      agentByPubkey,
      agentProfileModelByPubkey,
      isDesktop,
      handleGrantDecision,
      handleChoiceAnswer,
      handleChoiceSkip,
      handleOpenSystemIdentity,
      openCurrentBrief,
      handleOpenCode,
      handleOpenMessageSource,
      handleReactToMessage,
      handleBookmarkMessage,
      handleReportMessage,
      handleCornerProposalDecision,
      grantActionId,
      connectorOfferActionId,
      appSignInActionId,
      activeCommunityId,
      cacheViewerPubkey,
      decodedId,
      handleAcceptConnectorOffer,
      continueConnectorOffer,
      openCornerApp,
      openWorkbench,
      choiceActionId,
      openCorner,
      participantsHydrated,
      permissionActionId,
      personProfileByPubkey,
      cacheViewerPubkey,
      roomRepository?.targetBranch,
      roomName,
      roomParticipants,
      targetBranchActionId,
      targetBranchNotice,
      canManageWorkspace,
      viewerIsAgent,
      beginReply,
      dismissOutboxMessage,
      replyTargetForMessage,
      channelReferenceIndex,
      dismissComposerKeyboard,
      handleOpenProfile,
      handleOpenGitHubEvent,
      handleCopyLedgerMessage,
      openMessageActions,
      isReadOnlyDirectMessage,
      isDirectMessage,
      desktopExperience,
      isArchived,
      isCorner,
      decodedId,
    ],
  );
  // Resolve changing transcript-wide indexes before the memo boundary. A new
  // hint, byline opener or working speaker changes only that row's props.
  const presentationForMessage = useCallback((item: ChatDisplayMessage): RoomMessagePresentation => ({
    firstBylineOfDay: bylineOpeners.has(item.id),
    untaggedHint: hintMessageIds.has(item.id),
    deliveryFailed: failedOutboxIds.has(item.id),
    speakerWorking: Boolean(item.pubkey && speakerWorking[item.pubkey]),
    cornerProposalAnswer: answerByMessageId.get(item.relayId ?? item.id) ?? null,
    cornerProposalAction: cornerProposalAction?.messageId === item.id ? cornerProposalAction.decision : null,
  }), [bylineOpeners, hintMessageIds, failedOutboxIds, speakerWorking, answerByMessageId, cornerProposalAction]);
  const renderItem = useRoomMessageRenderItem({
    render: renderMessage,
    presentationForMessage,
    continuedIds: continuedAttributionIds,
    precedingMessageById: immediatelyPrecedingVisibleMessageById,
    messageById: visibleMessageById,
    arrivingCardIds,
    cardMotionStore: transcriptCardMotionStore,
    firstNewMessageId,
    arrivalFlashMessageId,
    sourceLandingFlashMessageId,
  });

  if (!roomSurface) {
    if (transcriptHydrationFailed) {
      return (
        <View style={[styles.container, { paddingTop: insets.top }]} testID="room-hydration-error">
          <View style={styles.hydrationErrorHeader}>
            {(!isDesktop || isCorner) && (
              <TouchableOpacity
                accessibilityLabel="Back to Rooms"
                onPress={handleBack}
                style={styles.backButton}
                testID="chat-back"
              >
                <ChevronGlyph
                  color={styles.backText.color}
                  direction="left"
                  size={CHEVRON_BACK_SIZE}
                  testID="chat-back-glyph"
                />
              </TouchableOpacity>
            )}
            <View style={styles.headerCenter}>
              <ChannelHeaderTitle
                kind={headerTitleKind}
                title={displayHeaderTitle ?? routeChannelTitle ?? ROOM_LABEL}
              />
              <HeaderMetaCaps>HISTORY UNAVAILABLE</HeaderMetaCaps>
            </View>
          </View>
          <ErrorBanner title="! ERROR" description={transcriptHydrationError ?? 'Could not load this conversation.'}
            retryLabel="Retry" onRetry={retryHydration} />
        </View>
      );
    }
    return (
      <View style={[styles.container, styles.center, { paddingTop: insets.top }]}>
        <SurfaceGlyphLoader testID="room-surface-loader" />
        <Text style={styles.loadingText}>
          LOADING {(isCorner ? CORNER_LABEL : ROOM_LABEL).toUpperCase()}
        </Text>
      </View>
    );
  }

  return (
    <BuzzCommunityShell
      communities={communities}
      activeCommunityId={activeCommunityId}
      onSelect={handleCommunitySelect}
      onAdd={() => router.push('/beeline/community' as Href)}
      onSettings={() => router.push('/beeline/settings' as Href)}
      viewerPubkey={userPubkey || undefined}
      viewerAvatarUrl={personProfileByPubkey.get(userPubkey)?.avatar}
    >
      <View style={styles.desktopConversationFrame}>
        <View style={styles.container}>
          {/* Header. No surface of its own — the chrome sits on the same
            obsidian as the transcript, parted only by a hairline. */}
          <View
            style={[styles.header, { minHeight: insets.top + 60, paddingTop: insets.top + 8 }]}
            testID={isCorner ? 'corner-session-header' : undefined}
          >
            {desktopExperience && <DesktopRoomListToggle />}
            {(!isDesktop || isCorner) && (
              <TouchableOpacity
                accessibilityLabel={
                  isCorner && cornerReturnTarget === 'corners'
                    ? `Back to this ${ROOM_LABEL}’s ${CHANGES_LABEL}`
                    : isCorner && cornerReturnTarget !== 'room-list'
                      ? 'Back'
                      : 'Back to Rooms'
                }
                accessibilityRole="button"
                hitSlop={HEADER_EDGE_HIT_SLOP}
                onPress={handleBack}
                style={styles.backButton}
                testID="chat-back"
              >
                <ChevronGlyph
                  color={isCorner ? styles.cornerBackText.color : styles.backText.color}
                  direction="left"
                  size={CHEVRON_BACK_SIZE}
                  testID="chat-back-glyph"
                />
              </TouchableOpacity>
            )}
            {/*
            The corner's opener, stated here once and never repeated on a
            message. A reviewer or helper holding a live turn in the corner
            never swaps this mark or the name under it: their work is
            attributed in the transcript, and the state word reads
            `reviewing` while it runs.
          */}
            {isCorner && cornerOwnerPubkey && (
              <HeaderIdentitySlot testID="corner-header-agent">
                <IdentityMark
                  kind="agent"
                  seed={cornerOwnerDisplay?.avatarSeed ?? cornerOwnerPubkey}
                  avatarUrl={cornerOwnerDisplay?.avatarUrl}
                  face={cornerOwnerDisplay?.face}
                  name={cornerOwnerDisplay?.name ?? 'Agent'}
                  size={26}
                  alive={cornerOwnerWorking}
                />
              </HeaderIdentitySlot>
            )}
            <DirectMessageHeaderIdentity
              isDirectMessage={isDirectMessage}
              readOnly={isReadOnlyDirectMessage}
              peerPubkey={dmPeerPubkey}
              connectorAvatarUrl={
                dmPeerIdentity?.avatar ?? directMessageListItem?.directMessage?.peer.avatar
              }
              kind={dmPeerAgentDisplay || dmPeerIdentity?.kind === 'agent' ? 'agent' : 'human'}
              seed={dmPeerAgentDisplay?.avatarSeed}
              avatarUrl={
                dmPeerAgentDisplay?.avatarUrl ??
                dmPeerIdentity?.avatar ??
                directMessageListItem?.directMessage?.peer.avatar ??
                dmPeerProfile?.avatar
              }
              face={dmPeerAgentDisplay?.face ?? dmPeerIdentity?.face ?? dmPeerProfile?.face}
              name={displayRoomName}
            />
            <View style={styles.headerCenter}>
              {displayHeaderTitle === null ? (
                // The channel's own name has not landed yet. Neither "Room" nor
                // a corner slug would be true, so show neither.
                <View
                  accessibilityLabel="Loading name"
                  style={[styles.channelNameSkeleton, isCorner && styles.cornerChannelNameSkeleton]}
                  testID="chat-title-skeleton"
                />
              ) : (
                <ChannelHeaderTitle
                  kind={headerTitleKind}
                  numberOfLines={1}
                  onLongPress={canRenameTitle ? startRenameFromTitle : undefined}
                  onPress={
                    !isCorner && !isDirectMessage ? () => setRoomActionsVisible(true) : undefined
                  }
                  title={displayHeaderTitle}
                />
              )}
              {!isCorner && (
                <RoomRepositorySubtitle
                  onOpenUrl={handleOpenGitHubEvent}
                  repositoryName={roomRepoChipLabel(roomRepository)}
                />
              )}
              {isCorner ? (
                <HeaderMetaRow>
                  <CornerHeaderAgentText
                    name={cornerOwnerDisplay?.name ?? 'Agent'}
                    stateWord={cornerHeaderWord}
                    state={cornerHeaderDisplay?.status}
                    headerSuffix={cornerHeaderDisplay?.headerSuffix}
                    waitingReason={cornerHeaderSource?.reason}
                    blocker={cornerHeaderSource?.blocker}
                    viewerId={viewerPubkey}
                    onReasonPress={cornerHeaderSource?.blocker?.url ? () => {
                      void openExternalUrl(cornerHeaderSource.blocker!.url!);
                    } : cornerHeaderSource?.itemId ? () => {
                      requestMessageJump(scrollController, cornerHeaderSource.itemId!, jumpToTranscriptMessage);
                    } : undefined}
                    style={[
                      styles.cornerHeaderAgent,
                      cornerHeaderDisplay?.status === 'working'
                        ? styles.cornerHeaderWorking
                        : cornerHeaderDisplay?.status === 'review'
                          ? styles.cornerHeaderReview
                          : cornerHeaderDisplay?.status === 'archived'
                            ? styles.cornerHeaderArchived
                            : styles.cornerHeaderWaiting,
                    ]}
                  />
                </HeaderMetaRow>
              ) : isDirectMessage ? (
                <HeaderMetaCaps testID="room-header-meta">{dmHeaderPresence}</HeaderMetaCaps>
              ) : null}
            </View>
            {/* Membership still consumes no header width: the Members row lives
              in the Room and corner overflow sheets. The desktop work pane
              does not carry it. The trailing slot is the Room's corners door —
              now the ONE active-corner affordance, since the pinned line above
              the composer is gone. A lone brass `◇` a few pixels from the
              overflow dots read as decoration on the menu rather than as a
              destination of its own, so the door is NAMED, the way every rail
              command is: the mark states the kind, the word states where it
              goes, and the pair's boxes touch like the Room-list chrome. */}
            {/* Desktop corners carry the parent Room's door too, so its long
              press opens a sibling corner as it does in the Room. */}
            {(!parentChannelId || desktopExperience) && !isDirectMessage && (
              <TouchableOpacity
                accessibilityHint="Long press to open a new corner"
                accessibilityLabel={`${ROOM_LABEL} ${CHANGES_LABEL}`}
                accessibilityRole="button"
                delayLongPress={450}
                hitSlop={HEADER_EDGE_HIT_SLOP}
                onLongPress={() => void handleOpenRandomCorner()}
                onPress={() => router.push(roomCornersHref(parentChannelId ?? decodedId))}
                style={styles.roomCornersButton}
                testID="room-corners-menu"
              >
                <CornerGlyph
                  color={styles.roomCornersGlyph.color}
                  size={HEADER_MARK_SIZE}
                  testID="room-corners-glyph"
                />
              </TouchableOpacity>
            )}
            {isCorner && !viewerIsAgent && !isArchived && (
              <TouchableOpacity
                accessibilityLabel={`${CORNER_LABEL} actions`}
                accessibilityRole="button"
                hitSlop={HEADER_EDGE_HIT_SLOP}
                onPress={() => setCornerActionsVisible(true)}
                style={styles.roomActionsButton}
                testID="corner-actions-menu"
              >
                <OverflowGlyph
                  color={styles.roomActionsGlyph.color}
                  size={HEADER_MARK_SIZE}
                  testID="corner-actions-glyph"
                />
              </TouchableOpacity>
            )}
            {isDirectMessage &&
              !viewerIsAgent &&
              !isArchived && (
                <TouchableOpacity
                  accessibilityLabel="Conversation actions"
                  accessibilityRole="button"
                  hitSlop={HEADER_EDGE_HIT_SLOP}
                  onPress={() => {
                    setMembershipError(null);
                    setDmActionsVisible(true);
                  }}
                  style={styles.roomActionsButton}
                  testID="dm-actions-menu"
                >
                  <OverflowGlyph
                    color={styles.roomActionsGlyph.color}
                    size={HEADER_MARK_SIZE}
                    testID="dm-actions-glyph"
                  />
                </TouchableOpacity>
              )}
            {!parentChannelId && !isDirectMessage && !viewerIsAgent && !isArchived && (
              <TouchableOpacity
                accessibilityLabel={`${ROOM_LABEL} actions`}
                accessibilityRole="button"
                hitSlop={HEADER_EDGE_HIT_SLOP}
                onPress={() => {
                  setMembershipError(null);
                  setRenameEditing(false);
                  setRenameError(null);
                  setRoomActionsVisible(true);
                }}
                style={styles.roomClusteredActionsButton}
                testID="room-actions-menu"
              >
                <OverflowGlyph
                  color={styles.roomActionsGlyph.color}
                  size={HEADER_MARK_SIZE}
                  testID="room-actions-glyph"
                />
              </TouchableOpacity>
            )}
            {isArchived && (
              <View style={styles.archivedBadge}>
                <Text style={styles.archivedBadgeText}>archived</Text>
              </View>
            )}
          </View>

          {!isCorner && !isDirectMessage && (() => {
            const call = workspaceChats.find(chat => chat.room.id === decodedId)?.voiceCall;
            return call && !call.endedAt ? <VoiceCallCard call={call} viewer={viewerPubkey}
              joined={voice.call?.id === call.id} connecting={voice.connecting} onJoin={() => void voice.join()} /> : null;
          })()}

          <RoomReviewerSurfaceNotice
            allowAutoMerge={roomRepository?.allowAutoMerge}
            canManage={canManageWorkspace}
            isCorner={isCorner}
            reviewerAgentId={roomSurface?.room.reviewerAgentId}
          />

          <KeyboardAvoidingView
            style={styles.keyboardBody}
            behavior={Platform.OS === 'ios' ? 'padding' : 'translate-with-padding'}
          >
            {/* What the corner is for, held under the header for its whole life:
            the human's own request, inscribed rather than framed. The header
            carries a short corner name, so without this the objective survives
            only until the first message lands. */}
            {isCorner && (
              <CornerObjectiveLine
                objective={cornerObjectiveText}
                onOpenBrief={openCurrentBrief}
                onOpenWorkflow={openRoomWorkflowRun}
                workflow={roomWorkflowRun}
                otherLiveRuns={roomOtherLiveRuns}
              />
            )}

            {/* The corner's PR state, inscribed above the transcript: one line
            that links to GitHub, where review and merge happen. */}
            {isCorner && (
              <View style={styles.cornerStatusInset}>
                <CornerStatusLine
                  lifecycle={roomSurface?.cornerLifecycle}
                  archived={isArchived}
                  onOpenPullRequest={(url) => {
                    void openExternalUrl(url).catch(() => {
                      Modal.alert('Could not open pull request', 'Open the PR from GitHub instead.');
                    });
                  }}
                />
              </View>
            )}

            <View style={styles.transcriptViewport}>
              {desktopTranscript ? (
                // A plain scrollable View over real DOM — no FlatList/
                // VirtualizedList. See `shouldFollowDesktopTail` in
                // `buzz/room-scroll-follow.ts` and proof/desktop-append-overlap/
                // NOTES.md for why RN Web's own list machinery raced the browser's
                // real layout on this surface.
                <View
                  testID="chat-messages"
                  ref={setDesktopScrollNode as unknown as React.Ref<View>}
                  {...{
                    onScroll: handleDesktopScroll,
                    // A wheel or touch scroll is the reader taking the list.
                    onWheel: scrollController.userScrolled,
                    onTouchMove: scrollController.userScrolled,
                  }}
                  style={[styles.messageList, styles.desktopScroll]}
                >
                  <View
                    ref={setDesktopContentNode as unknown as React.Ref<View>}
                    style={[
                      styles.messageListContent,
                      styles.messageListContentDesktop,
                      transcriptMessages.length === 0 && styles.messageListContentEmpty,
                    ]}
                  >
                    {emptyLedger}
                    {transcriptMessages.length > 0 && (
                      <>
                        {transcriptHistoryLine}
                        {transcriptMessages.map((item) => (
                          <View
                            key={item.id}
                            {...{ dataSet: { rowId: item.id } }}
                            ref={getDesktopRowRefCallback(item.id) as unknown as React.Ref<View>}
                          >
                            {renderItem({ item })}
                          </View>
                        ))}
                        {transcriptForwardLine}
                      </>
                    )}
                  </View>
                </View>
              ) : (
                <PhoneTranscriptList
                  testID="chat-messages"
                  ref={flatListRef}
                  inverted={transcriptMessages.length > 0}
                  data={transcriptMessages}
                  keyExtractor={(item: ChatDisplayMessage) => phoneRowKey(item.id)}
                  CellRendererComponent={PhoneTranscriptCell}
                  style={styles.messageList}
                  contentContainerStyle={[
                    styles.messageListContent,
                    transcriptMessages.length === 0 && styles.messageListContentEmpty,
                    // Inverted list: paddingTop is the visual tail. Always the
                    // ordinary speaker-change margin plus the fixed composer-top
                    // gap — the thinking line is absolute and paints over that
                    // invariant tail rather than changing it when mounted.
                    !isArchived && {
                      paddingTop: phoneTranscriptTailPadding({
                        turnChromeVisible: Boolean(composerAck || settledTurn),
                      }),
                    },
                  ]}
                  maintainVisibleContentPosition={{
                    // Native records the first eligible visible child's real
                    // frame and compensates by its measured movement. That
                    // preserves variable-height history without getItemLayout,
                    // eager rendering, or an estimated offset. Index 0 is
                    // excluded because optimistic settlement and streams can
                    // replace it in place.
                    minIndexForVisible: 1,
                    // Native offset 0 is the visual bottom. A detached window's
                    // newest row is not the live tail: newer rows load below a
                    // jump target there, and following them would carry the
                    // reader away from it.
                    ...(anchoredSegmentActive ? {} : { autoscrollToTopThreshold: 50 }),
                  }}
                  keyboardShouldPersistTaps="handled"
                  keyboardDismissMode={transcriptKeyboardDismissMode(Platform.OS)}
                  // The transcript scrubber below is this list's scroll bar.
                  showsVerticalScrollIndicator={false}
                  onScroll={(event) => {
                    phoneScrollOffsetRef.current = event.nativeEvent.contentOffset.y;
                    observePhoneTailOffset(event.nativeEvent.contentOffset.y);
                    transcriptPositions.observeScroll(event.nativeEvent);
                    if (
                      anchoredSegmentActive &&
                      event.nativeEvent.contentOffset.y <= TAIL_PIN_THRESHOLD &&
                      !scrollController.isLanding()
                    )
                      loadNewerTranscriptMessages();
                  }}
                  // One frame, the list's own default. A wider window leaves the
                  // viewability report (which settles the badge and the unread
                  // line) on an offset the list has already scrolled past.
                  scrollEventThrottle={16}
                  onViewableItemsChanged={observeVisibleTranscriptMessages}
                  // A drag is the reader taking the list: it cancels any
                  // landing or follow in progress. These fire only for a real
                  // gesture, never for a programmatic scroll.
                  onScrollBeginDrag={() => {
                    allowOlderHistoryRef.current = true;
                    scrollController.dragStarted();
                  }}
                  onScrollEndDrag={(event) => {
                    // Drag-end precedes momentum-begin. Missing optional velocity is
                    // not proof that the gesture stopped: the drag stays held for a
                    // frame, so momentum-begin can claim it.
                    const velocity = event.nativeEvent.velocity?.y;
                    const momentumMayFollow = velocity === undefined || Math.abs(velocity) > 0.01;
                    // No momentum follows, so this is where the list rests. With
                    // momentum it is an in-flight offset; momentum-end rests it.
                    if (!momentumMayFollow)
                      observePhoneTailOffset(event.nativeEvent.contentOffset.y);
                    scrollController.dragEnded(momentumMayFollow);
                  }}
                  onMomentumScrollBegin={() => {
                    allowOlderHistoryRef.current = true;
                    scrollController.momentumStarted();
                  }}
                  onMomentumScrollEnd={(event) => {
                    observePhoneTailOffset(event.nativeEvent.contentOffset.y);
                    scrollController.momentumEnded();
                  }}
                  // React Native Web has no drag events; a wheel or touch
                  // scroll is the same signal there.
                  {...(Platform.OS === 'web'
                    ? {
                        onTouchMove: scrollController.userScrolled,
                        onWheel: scrollController.userScrolled,
                      }
                    : {})}
                  onLayout={(event) => {
                    phoneListHeightRef.current = event.nativeEvent.layout.height;
                    phoneUnderfill.observeListHeight(event.nativeEvent.layout.height);
                  }}
                  onContentSizeChange={(_width, height) => {
                    transcriptPositions.observeContentSize(height);
                    detachedFillMeasuredRef.current = true;
                    phoneUnderfill.observeContentHeight(height);
                    holdPhoneLanding(height);
                    scrollController.observeLayout();
                  }}
                  renderItem={renderItem}
                  onScrollToIndexFailed={phoneScrollList.scrollToIndexFailed}
                  onEndReached={loadOlderTranscriptIfReaderAsked}
                  onEndReachedThreshold={0.5}
                  ListEmptyComponent={emptyLedger}
                  // Inverted native list: the header is the newest end of the transcript.
                  ListHeaderComponent={
                    starPrompt.prompt || transcriptForwardLine ? (
                      <View>
                        {transcriptForwardLine}
                        {starPrompt.prompt ? (
                          <View style={styles.starPrompt}>
                            <StarPromptCard
                              prompt={starPrompt.prompt}
                              busy={starPrompt.busy}
                              onAnswer={(action) => void starPrompt.answer(action)}
                            />
                          </View>
                        ) : null}
                      </View>
                    ) : null
                  }
                  // Inverted native list: the footer is the visual top.
                  ListFooterComponent={
                    <>
                      {transcriptHistoryLine}
                      {transcriptMessages.length > 0 && emptyLedger}
                    </>
                  }
                />
              )}
              {!desktopTranscript && (
                <TranscriptScrubber
                  positions={transcriptPositions}
                  loadOlder={loadOlderTranscriptMessages}
                  scrollController={scrollController}
                />
              )}
              <RoomUnreadControls
                bottomInset={!desktopExperience && !isArchived ? turnChromeTopInset : undefined}
                corner={isCorner}
                badgeCount={newMessageBadgeCount}
                discVisible={newestJumpDiscShown}
                onJumpToNewest={landAtNewestMessage}
              />
            </View>

            {/* P2: Archived channels are read-only */}
            {isArchived ? (
              <View style={[styles.archivedInputBar, readOnlyFooterInset]}>
                <Text
                  style={[styles.archivedInputText, isCorner && styles.cornerArchivedInputText]}
                >
                  {parentChannelId ? 'Corner' : ROOM_LABEL} archived (read-only)
                </Text>
              </View>
            ) : (
              <View style={[styles.bottomChromeStack, desktopExperience && styles.desktopReadingColumn]} testID="room-bottom-chrome">
                {/* Phone turn chrome paints over the transcript's own bottom
                margin: `TurnBandSlot` is absolute (`room-bottom-chrome`),
                anchored to this stack's top edge, so it takes no height from
                the list whether or not an agent is working and cannot cover
                the newest row — the line's box is exactly the speaker-change
                margin plus the fixed composer-top gap the transcript always
                leaves. The slot is mounted
                whether or not a line is showing; `pointerEvents="box-none"`
                lets the transcript keep every touch the line is not using.
                Desktop keeps the slot inside inputBar. */}
                {!desktopExperience && (
                  <TurnBandSlot testID="hanging-turn-chrome" onTopInset={setTurnChromeTopInset}>
                    {composerAck ? (
                      <TurnProgressLine
                        label={composerAck.label}
                        startedAt={composerAck.startedAt}
                        received={composerAck.received}
                        stopping={stoppingThisTurn}
                        onStop={
                          composerAck.stop
                            ? () => void handleStopTurn(composerAck.stop!)
                            : undefined
                        }
                        testID="turn-progress-line"
                      />
                    ) : settledTurn ? (
                      <TurnSettledLine line={settledTurn.line} testID="turn-settled-line" />
                    ) : null}
                  </TurnBandSlot>
                )}
                {/* No pinned corner line lives here. A Room holds many corners at
                once, so one line above the composer could only ever name one of
                them, and it sat between the reader and the field they were
                typing in. The Room's corners door in the header is the one way
                in; the corner's own state is read there, in the corners list,
                and on the Room-list row. */}
                {isReadOnlyDirectMessage ? (
                  <View style={[styles.archivedInputBar, readOnlyFooterInset]}>
                    <Text style={styles.archivedInputText}>
                      Announcements only · you can't reply here
                    </Text>
                  </View>
                ) : (
                  <Animated.View style={[styles.inputBar, composerBottomInsetStyle]}>
                    {slashMenuVisible &&
                      (() => {
                        const mentionAgent = mentionSlashAgentPubkey
                          ? agentByPubkey.get(mentionSlashAgentPubkey)
                          : undefined;
                        const mentionAgentName = mentionSlashAgentPubkey
                          ? resolveAgentDisplayIdentity(mentionSlashAgentPubkey, mentionAgent).name
                          : undefined;
                        return (
                          <SlashVerbPicker
                            verbs={slashVerbs}
                            query={currentSlashQuery ?? mentionSlash?.query ?? ''}
                            highlightedIndex={highlightedSlashVerbIndex}
                            onDismiss={dismissSlashMenu}
                            onSelect={runSlashVerb}
                            commands={mentionAgentCommands}
                            apps={cornerAppCommands}
                            agentName={mentionAgentName}
                            agentLacksCommands={mentionAgentLacksCommands}
                            onSelectCommand={selectAgentCommand}
                            onSelectApp={openCornerApp}
                          />
                        );
                      })()}
                    {mentionMenuVisible && (
                      <MentionSuggestionMenu
                        highlightedIndex={highlightedMentionIndex}
                        keyboardOpen={keyboardHeight > 0}
                        matches={mentionSuggestions.matches}
                        onSelect={selectMention}
                        overflow={mentionSuggestions.overflow}
                        personAvatar={(pubkey) => personProfileByPubkey.get(pubkey)?.avatar}
                      />
                    )}
                    {channelMenuVisible && (
                      <ChannelSuggestionMenu
                        highlightedIndex={Math.min(
                          highlightedMentionIndex,
                          channelSuggestions.matches.length - 1,
                        )}
                        keyboardOpen={keyboardHeight > 0}
                        matches={channelSuggestions.matches}
                        onSelect={selectChannel}
                        overflow={channelSuggestions.overflow}
                        query={activeChannel?.query ?? ''}
                      />
                    )}
                    {cornerOpenRepoPrompt && (roomRepoAccessIssue ? (
                      <ErrorBanner inline title={roomRepoAccessIssue.reason === 'revoked' ? 'ACCESS TO THIS REPO WAS REVOKED' : 'THIS REPO ISN’T IN THE BEELINE INSTALLATION'}
                        description={`${roomRepoAccessIssue.fullName} must be reconnected before a ${CORNER_LABEL} can open.`}
                        retryLabel={roomRepoAccessIssue.reason === 'not_granted' ? 'Add this repo to the Beeline installation →' : `Connect ${roomRepoAccessIssue.fullName.split('/')[0]} →`}
                        onRetry={() => void handleReconnectRoomRepository()} retryTestID="corner-open-repo-connect"
                        secondaryAction={{ label: 'DISMISS', onPress: () => setCornerOpenRepoPrompt(false), testID: 'corner-open-repo-prompt-dismiss' }} testID="corner-open-repo-prompt" />
                    ) : (
                      <View style={styles.repoPromptBanner} testID="corner-open-repo-prompt">
                        <Text style={styles.repoPromptTitle}>
                          {`THIS ${ROOM_LABEL.toUpperCase()} ISN’T LINKED TO A REPO`}
                        </Text>
                        <Text style={styles.repoPromptHint}>
                          {`Pick one to open a ${CORNER_LABEL}.`}
                        </Text>
                        {canManageWorkspace ? (
                          <RepoPicker
                            draftContext={decodedId}
                            busy={roomRepoBusy}
                            candidates={roomRepoCandidates}
                            installations={githubInstallations}
                            currentKey={null}
                            error={roomRepoError}
                            notice={roomRepoNotice}
                            ownerGrant={ownerGrant}
                            onAddAccount={() => void handleAddGitHubAccount()}
                            onAskOwnerGrant={(fullName) => void handleAskOwnerGrant(fullName)}
                            onCreateRepository={handleCreateGitHubRepository}
                            onManageInstallation={(installation) =>
                              void handleManageGitHubInstallation(installation)
                            }
                            onSelect={handleSelectRoomRepoCandidate}
                            testIDPrefix="corner-open-repo-picker"
                          />
                        ) : (
                          <Text style={styles.repoPromptHint}>
                            Ask a {ROOM_LABEL} admin to link one.
                          </Text>
                        )}
                        <Button
                          label="DISMISS"
                          variant="quiet"
                          accessibilityLabel="Dismiss"
                          onPress={() => setCornerOpenRepoPrompt(false)}
                          testID="corner-open-repo-prompt-dismiss"
                          appearance={{ control: styles.repoPromptDismiss, label: styles.repoPromptDismissText }}
                        />
                      </View>
                    ))}
                    {desktopExperience ? (
                      <View
                        style={styles.desktopStatusSlot}
                        accessibilityLiveRegion="polite"
                        testID="desktop-message-status"
                      >
                        {desktopDeliveryState === 'sending' ? (
                          <Text style={styles.desktopStatusText}>SENDING…</Text>
                        ) : null}
                        {composerAck ? (
                          <TurnProgressLine
                            inset={false}
                            label={composerAck.label}
                            startedAt={composerAck.startedAt}
                            received={composerAck.received}
                            stopping={stoppingThisTurn}
                            onStop={
                              composerAck.stop
                                ? () => void handleStopTurn(composerAck.stop!)
                                : undefined
                            }
                            testID="turn-progress-line"
                          />
                        ) : desktopDeliveryState && desktopDeliveryState !== 'sending' ? (
                          <Text
                            style={[
                              styles.desktopStatusText,
                              desktopDeliveryState === 'failed' && styles.desktopStatusFailed,
                            ]}
                          >
                            {desktopDeliveryState === 'delivered'
                              ? 'DELIVERED'
                              : 'MESSAGE FAILED · RETRY FROM THE MESSAGE'}
                          </Text>
                        ) : settledTurn ? (
                          <TurnSettledLine line={settledTurn.line} testID="turn-settled-line" />
                        ) : null}
                      </View>
                    ) : null}
                    <ConversationComposer
                      isDirectMessage={isDirectMessage}
                      hasAgentMembers={Boolean(roomSurface?.members.some(member => member.identity.kind === 'agent'))}
                      voice={!isCorner && roomSurface?.members.some(member => member.identity.kind === 'agent') ? voice : undefined}
                      onStop={
                        composerAck?.stop ? () => handleStopTurn(composerAck.stop!) : undefined
                      }
                      inputRef={composerRef}
                      reply={
                        replyTarget
                          ? {
                              handle: replyTarget.authorHandle ?? replyTarget.authorName,
                              preview: replyTarget.preview,
                            }
                          : undefined
                      }
                      onCancelReply={() => setReplyTarget(null)}
                      tagHandles={composerTagHandles}
                      attachments={pendingAttachments.map((attachment) => ({
                        uri: attachment.uri,
                        name: attachment.name,
                        mimeType: attachment.mimeType,
                        sizeLabel: formatAttachmentSize(attachment.size),
                        uploadState: attachmentUploader.state(attachment),
                      }))}
                      attachmentsUploading={sending}
                      onRemoveAttachment={(index) =>
                        replacePendingAttachments((current) =>
                          current.filter((_, attachmentIndex) => attachmentIndex !== index),
                        )
                      }
                      onRetryAttachment={(index) => {
                        const attachment = pendingAttachments[index];
                        if (!transport || !attachment) return;
                        void transport
                          .ensureClient()
                          .then((client) => attachmentUploader.start(client, [attachment]))
                          .catch(() => undefined);
                      }}
                      speechHints={speechHints}
                      value={inputText}
                      inputRevision={composerInputRevision}
                      isInputRevisionCurrent={(inputRevision) =>
                        inputRevision === composerInputRevisionRef.current
                      }
                      height={composerHeight}
                      maxHeight={COMPOSER_MAX_HEIGHT}
                      focused={composerFocused}
                      disabled={sending}
                      canSend={
                        slashMenuVisible
                          ? Boolean(inputText.trim())
                          : Boolean(
                              splitComposerTags(inputText, composerTagHandles).rest.trim() ||
                              pendingAttachments.length,
                            )
                      }
                      onAttach={chooseAttachment}
                      attachDisabled={sending}
                      containerProps={
                        desktopExperience
                          ? ({
                              onDragOver: (event: React.DragEvent<HTMLElement>) =>
                                event.preventDefault(),
                              onDrop: handleDesktopDrop,
                            } as any)
                          : undefined
                      }
                      onDesktopPaste={desktopExperience ? handleDesktopPaste : undefined}
                      onChangeText={(value) => {
                        inputTextRef.current = value;
                        setInputText(value);
                      }}
                      onContentSizeChange={(event) => {
                        const contentHeight = Math.ceil(event.nativeEvent.contentSize.height);
                        setComposerHeight(
                          Math.min(
                            COMPOSER_MAX_HEIGHT,
                            Math.max(COMPOSER_MIN_HEIGHT, contentHeight),
                          ),
                        );
                      }}
                      onFocus={() => setComposerFocused(true)}
                      onBlur={() => setComposerFocused(false)}
                      onKeyPress={(event) => {
                        const action = mentionKeyboardAction(event.nativeEvent.key);
                        // Printable keys must never be prevented by the mention
                        // picker. In particular, `>` is ordinary composer text.
                        if (slashMenuVisible) {
                          if (!action) return;
                          if (action === 'select') {
                            event.preventDefault();
                            selectHighlightedPaletteItem();
                          } else if (
                            (action === 'next' || action === 'previous') &&
                            paletteItemCount
                          ) {
                            event.preventDefault();
                            const direction = action === 'next' ? 1 : -1;
                            setHighlightedSlashVerbIndex(
                              (current) =>
                                (current + direction + paletteItemCount) % paletteItemCount,
                            );
                          } else {
                            event.preventDefault();
                            dismissSlashMenu();
                          }
                          return;
                        }
                        if (!suggestionCount) {
                          const desktopAction = desktopComposerKeyAction(
                            Platform.OS,
                            event.nativeEvent.key,
                            Boolean(
                              (event.nativeEvent as unknown as { shiftKey?: boolean }).shiftKey,
                            ),
                          );
                          if (desktopAction === 'send') {
                            event.preventDefault();
                            void handleSend();
                          }
                          return;
                        }
                        if (!action) return;
                        if (action === 'select') {
                          event.preventDefault();
                          const index = Math.min(highlightedMentionIndex, suggestionCount - 1);
                          if (mentionMenuVisible) {
                            const selected = mentionSuggestions.matches[index];
                            if (selected) selectMention(selected);
                          } else {
                            const selected = channelSuggestions.matches[index];
                            if (selected) selectChannel(selected);
                          }
                        } else if (action === 'next' || action === 'previous') {
                          event.preventDefault();
                          const direction = action === 'next' ? 1 : -1;
                          setHighlightedMentionIndex(
                            (current) =>
                              (Math.min(current, suggestionCount - 1) +
                                direction +
                                suggestionCount) %
                              suggestionCount,
                          );
                        } else {
                          event.preventDefault();
                          setDismissedMentionKey(
                            mentionMenuVisible ? mentionMenuKey : channelMenuKey,
                          );
                        }
                      }}
                      onSelectionChange={(event) => {
                        const nextSelection = event.nativeEvent.selection;
                        setInputSelection((current) =>
                          current.start === nextSelection.start && current.end === nextSelection.end
                            ? current
                            : nextSelection,
                        );
                      }}
                      onSend={
                        slashMenuVisible
                          ? () => {
                              selectHighlightedPaletteItem();
                            }
                          : (dictated?: DictatedSend) => handleSend(undefined, dictated)
                      }
                    />
                  </Animated.View>
                )}
              </View>
            )}
          </KeyboardAvoidingView>
          {reportToast}
        </View>
        {profileAgentId && desktopExperience && activeCommunityId && (
          <View style={styles.agentProfilePane} testID="desktop-agent-profile-pane">
            {profileKind === 'human' ? (
              <HumanProfile
                key={profileAgentId}
                memberId={profileAgentId}
                workspaceId={activeCommunityId}
                onClose={() => setProfileAgentId(null)}
              />
            ) : (
              <BuzzMembers
                key={profileAgentId}
                profileAgentId={profileAgentId}
                profileRoomId={decodedId}
                workspaceIdOverride={activeCommunityId}
                onClose={() => setProfileAgentId(null)}
              />
            )}
          </View>
        )}
        {!profileAgentId && desktopWorkPaneMounted && desktopWorkPaneContent && (
          <DesktopRoomInspector
            room={desktopWorkPaneMounted}
            client={roomClient}
            channelIndex={channelReferenceIndex}
            onChannelReference={handleOpenChannelReference}
            content={displayedDesktopWorkPaneContent!}
            onOpenCorner={(cornerId) => openDesktopCorner(desktopWorkRoomId, cornerId)}
            onOpenInMain={expandDesktopCorner}
            onClose={closeDesktopWorkPane}
          />
        )}
      </View>

      <AttachmentPickerSheet
        visible={attachmentPickerVisible}
        onClose={() => setAttachmentPickerVisible(false)}
        onPickDocument={() => void pickDocument()}
        onPickPhoto={() => void pickPhoto()}
        onPickPasted={desktopExperience ? undefined : () => void pasteImage()}
      />

      <HullActionSheetModal
        accessibilityLabel="Close message actions"
        onClose={() => setMessageActionsTarget(null)}
        testID="message-actions-sheet"
        title="Message"
        visible={Boolean(messageActionsTarget)}
      >
        {messageActionsTarget && !messageActionsTarget.isAgentActivity ? (
          // The reaction entry point is the emoji scroll itself — the sheet's
          // top cell, with no React row and nothing to expand above it.
          <MessageReactionStrip
            onReact={(emoji) => {
              const target = messageActionsTarget;
              setMessageActionsTarget(null);
              if (target) void handleReactToMessage(target, emoji);
            }}
          />
        ) : null}
        {messageActionsTarget && !messageActionsTarget.isAgentActivity ? (
          <HullActionSheetRow
            accessibilityLabel={
              messageIsBookmarked(messageActionsTarget) ? 'Remove bookmark' : 'Bookmark message'
            }
            label={messageIsBookmarked(messageActionsTarget) ? 'Remove bookmark' : 'Bookmark'}
            onPress={() => {
              const target = messageActionsTarget;
              setMessageActionsTarget(null);
              if (target) void handleBookmarkMessage(target);
            }}
            testID="message-bookmark-action"
          />
        ) : null}
        {messageActionsTarget && !messageActionsTarget.isAgentActivity ? (
          <HullActionSheetRow
            accessibilityLabel="Report an issue with this message"
            label="Report issue"
            onPress={() => {
              const target = messageActionsTarget;
              setMessageActionsTarget(null);
              if (target) void handleReportMessage(target);
            }}
            testID="message-report-action"
          />
        ) : null}
        {messageActionsTarget ? (
          <HullActionSheetRow
            accessibilityLabel="Copy message text"
            label="Copy"
            onPress={() => {
              handleCopyLedgerMessage(
                messageActionsTarget.isAgentActivity
                  ? agentActivityReplyExcerpt(messageActionsTarget)
                  : messageActionsTarget.text,
              );
              setMessageActionsTarget(null);
            }}
            testID="message-copy-action"
          />
        ) : null}
        {messageActionsTarget ? (
          <HullActionSheetRow
            accessibilityLabel="Select message text"
            label="Select"
            onPress={() => {
              const target = messageActionsTarget;
              setMessageActionsTarget(null);
              if (target) {
                handleSelectLedgerMessage(
                  target.isAgentActivity ? agentActivityReplyExcerpt(target) : target.text,
                );
              }
            }}
            testID="message-select-action"
          />
        ) : null}
        {messageActionsTarget && canBeginReply(messageActionsTarget, decodedId) ? (
          <HullActionSheetRow
            accessibilityLabel="Reply to message"
            label="Reply"
            onPress={() => {
              const target = messageActionsTarget;
              setMessageActionsTarget(null);
              if (target) beginReply(target);
            }}
            testID="message-reply-action"
          />
        ) : null}
        {messageActionsTarget && !messageActionsTarget.isAgentActivity ? (
          <HullActionSheetRow
            accessibilityLabel="Forward message"
            label="Forward"
            onPress={() => {
              const target = messageActionsTarget;
              setMessageActionsTarget(null);
              if (target) void beginForward(target);
            }}
            testID="message-forward-action"
          />
        ) : null}
        {messageActionsTarget && canDeleteMessage(messageActionsTarget) ? (
          <HullActionSheetRow
            accessibilityLabel="Delete message"
            destructive
            label="Delete"
            onPress={() => {
              const target = messageActionsTarget;
              setMessageActionsTarget(null);
              if (target) void handleDeleteMessage(target);
            }}
            testID="message-delete-action"
          />
        ) : null}
        <HullActionSheetCancel
          onPress={() => setMessageActionsTarget(null)}
          testID="message-actions-close"
        />
      </HullActionSheetModal>

      <ForwardCornerSheet
        onClose={() => setForwardCornerPrompt(null)}
        onOpen={() => void confirmForwardToNewCorner()}
        visible={Boolean(forwardCornerPrompt)}
      />

      <ForwardMessagePickerSheet
        draftContext={decodedId}
        busyRoomId={forwardBusyRoomId}
        error={forwardError}
        onClose={() => {
          if (forwardBusyRoomId) return;
          setForwardTarget(null);
          setForwardRooms(null);
          setForwardError(null);
        }}
        onForward={(target) => void forwardToRoom(target)}
        targets={forwardRooms}
        visible={Boolean(forwardTarget)}
      />

      <RoomRosterSheet
        bottomInset={insets.bottom}
        canManage={roomSurface?.viewer.permissions.manage ?? false}
        isDirectMessage={isDirectMessage}
        memberByPubkey={roomMemberByPubkey}
        membershipActionPubkey={membershipActionPubkey}
        membershipError={membershipError}
        members={visibleRosterMembers}
        onAddMembers={() => {
          setMembershipError(null);
          // One counted Members section owns one add control, so the picker it
          // opens lists both kinds and carries its own invite-a-person and
          // connect-an-agent rows.
          setParticipantPickerKind(null);
          setParticipantPickerVisible(true);
        }}
        onClose={closeRoster}
        onRemove={handleRemoveRoomMember}
        onOpenProfile={(participant) =>
          handleOpenProfile(participant.pubkey, participant.kind === 'agent' ? 'agent' : 'human')
        }
        workingByPubkey={speakerWorking}
        parentChannelId={parentChannelId ?? null}
        personProfileByPubkey={personProfileByPubkey}
        userPubkey={userPubkey}
        visible={memberManagement.rosterVisible}
      />

      <HullActionSheetModal
        accessibilityLabel={`Close ${ROOM_LABEL} actions`}
        dismissOnBackdrop={!renameBusy}
        footer={roomRepoChoice.footer}
        onClose={() =>
          roomRepoChoice.listOpen ? setShowRoomRepoPicker(false) : closeRoomActions()
        }
        sticky={roomRepoChoice.listOpen ? undefined : roomRepoChoice.control}
        onTitlePress={canRenameTitle && !roomRepoChoice.listOpen ? startRenameFromTitle : undefined}
        testID="room-actions-sheet"
        title={roomRepoChoice.listOpen ? 'Choose a repo' : displayRoomName}
        titleAccessibilityLabel={roomRepoChoice.listOpen ? undefined : `Rename ${displayRoomName}`}
        titleTestID="room-actions-title"
        visible={roomActionsVisible}
      >
        {roomRepoChoice.listOpen ? (
          roomRepoChoice.list
        ) : (
          <>
            {roomRepoChoice.row}
            {!isCorner && canRenameTitle && renameEditing && (
              <View style={styles.roomRenameEditor} testID="rename-room-editor">
                <Text style={styles.roomRenameLabel}>New {ROOM_LABEL.toLowerCase()} name</Text>
                <HullDialogInput
                  accessibilityLabel={`New ${ROOM_LABEL} name`}
                  autoCapitalize="none"
                  autoCorrect={false}
                  editable={!renameBusy}
                  onChangeText={(value) => {
                    setRenameDraft(roomNameEntry(value));
                    if (value.trim()) setRenameError(null);
                  }}
                  onSubmitEditing={() => void handleRenameRoom()}
                  returnKeyType="done"
                  selectTextOnFocus
                  style={styles.roomRenameInput}
                  testID="rename-room-input"
                  value={renameDraft}
                />
                {!validRoomSlug(renameDraft.trim()) && (
                  <Text style={styles.roomRenameLabel}>{ROOM_SLUG_HINT}</Text>
                )}
                <HullDialogActions style={styles.roomRenameControls} actions={[{ disabled: renameBusy, label: "Cancel", onPress: () => {
                      setRenameEditing(false);
                      setRenameError(null);
                    }, variant: "quiet" }, { disabled: renameBusy || !validRoomSlug(renameDraft.trim()), label: renameBusy ? 'Renaming…' : 'Save', loading: renameBusy, onPress: () => void handleRenameRoom(), testID: "apply-room-rename", variant: 'primary' }]} />
              </View>
            )}
            <RoomReviewerActions
              agents={(roomSurface?.members ?? [])
                .filter((member) => member.identity.kind === 'agent')
                .map((member) => member.identity)}
              allowAutoMerge={roomRepository?.allowAutoMerge}
              canManage={canManageWorkspace}
              hasRepository={roomRepository !== null}
              onSaved={(reviewers) => applyRoomReviewers(reviewers[0], reviewers.slice(1))}
              reviewerAgentId={roomSurface?.room.reviewerAgentId}
              reviewerFallbackIds={roomSurface?.room.reviewerFallbackIds}
              roomId={decodedId}
              roomName={displayRoomName}
              updateRoom={(input) => monolithPhoneOperation('updateRoom', input)}
            />
            <HullActionSheetRow
              label="Mute notifications"
              accessibilityLabel={`Mute notifications in this ${ROOM_LABEL} and its ${CORNER_LABEL}s`}
              description="Tags and replies still notify you."
              disabled={pushMuteWorking}
              onPress={() => void togglePushMute()}
              toggle={{
                value: pushMuted,
                disabled: pushMuteWorking,
                onValueChange: () => void togglePushMute(),
              }}
              testID="room-push-mute"
            />
            <HullActionSheetRow
              accessibilityLabel={`View ${formatRoomParticipantTotal(roomParticipantTotal)}`}
              chevron="right"
              disabled={!memberManagement.canOpenRoster}
              label="Members"
              metadata={
                participantsHydrated ? formatRoomParticipantTotal(roomParticipantTotal) : 'Loading'
              }
              onPress={() => {
                setRoomActionsVisible(false);
                setRosterVisible(true);
              }}
              testID="room-participant-roster-trigger"
            />
            {canManageWorkspace && (
              <HullActionSheetRow
                accessibilityLabel={`View ${ROOM_LABEL} schedules and subscriptions`}
                chevron="right"
                label="Schedules and subscriptions"
                onPress={() => {
                  setRoomActionsVisible(false);
                  router.push({
                    pathname: '/beeline/settings/schedules',
                    params: { roomId: decodedId, workspaceId: activeCommunityId },
                  } as unknown as Href);
                }}
                testID="room-schedules-action"
              />
            )}
            {canManageWorkspace && (
              <HullActionSheetRow
                accessibilityLabel={`Delete ${ROOM_LABEL}`}
                destructive
                disabled={roomLifecycleBusy}
                label={roomLifecycleBusy ? 'Deleting…' : `Delete ${ROOM_LABEL}`}
                onPress={() => void handleRoomLifecycle('delete')}
                testID="delete-room-action"
              />
            )}
            <HullActionSheetRow
              accessibilityLabel={`Leave ${ROOM_LABEL}`}
              destructive
              disabled={roomLifecycleBusy}
              label={roomLifecycleBusy ? 'Leaving…' : `Leave ${ROOM_LABEL}`}
              onPress={() => void handleRoomLifecycle('leave')}
              testID="leave-room-action"
            />
            {(renameError || membershipError) && (
              <View accessibilityRole="alert" style={styles.membershipError}>
                <Text style={styles.membershipErrorText}>! {renameError ?? membershipError}</Text>
              </View>
            )}
          </>
        )}
      </HullActionSheetModal>

      <HullActionSheetModal
        accessibilityLabel="Close conversation actions"
        onClose={() => setDmActionsVisible(false)}
        testID="dm-actions-sheet"
        title={displayRoomName}
        visible={dmActionsVisible}
      >
        <HullActionSheetRow
          label="Mute notifications"
          accessibilityLabel="Mute notifications from this conversation"
          disabled={pushMuteWorking}
          onPress={() => void togglePushMute()}
          toggle={{
            value: pushMuted,
            disabled: pushMuteWorking,
            onValueChange: () => void togglePushMute(),
          }}
          testID="dm-push-mute"
        />
        {!viewerIsAgent && roomSurface?.viewer.permissions.send && (
          <HullActionSheetRow
            accessibilityLabel="View conversation schedules and subscriptions"
            chevron="right"
            label="Schedules and subscriptions"
            onPress={() => {
              setDmActionsVisible(false);
              router.push({
                pathname: '/beeline/settings/schedules',
                params: { roomId: decodedId, workspaceId: activeCommunityId },
              } as unknown as Href);
            }}
            testID="dm-schedules-action"
          />
        )}
        {membershipError && (
          <View accessibilityRole="alert" style={styles.membershipError}>
            <Text style={styles.membershipErrorText}>! {membershipError}</Text>
          </View>
        )}
        <HullActionSheetCancel
          onPress={() => setDmActionsVisible(false)}
          testID="dm-actions-close"
        />
      </HullActionSheetModal>

      <CornerActionsSheet
        title={headerTitle ?? cornerOwnerDisplay?.name ?? CORNER_LABEL}
        visible={cornerActionsVisible}
        locked={roomSurface?.cornerLocked === true}
        connected={Boolean(transport)}
        onClose={() => setCornerActionsVisible(false)}
        closeCorner={async () => {
          if (!transport) throw new Error('Still connecting. Try again in a moment.');
          await transport.closeCorner(decodedId);
        }}
        setLocked={async (locked) => {
          if (!transport) throw new Error('Still connecting. Try again in a moment.');
          await transport.setCornerLocked(decodedId, locked);
        }}
        onClosed={() => {
          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          handleBack();
        }}
        onSaved={() => refreshSignal.force()}
        onError={(error) => {
          refreshSignal.force();
          void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          Modal.alert('Could not complete request', error instanceof Error ? error.message : String(error));
        }}
      />

      <HullDialog
        actions={[
          {
            disabled: renameBusy,
            label: 'Cancel',
            onPress: () => {
              setRenameEditing(false);
              setRenameError(null);
            },
          },
          {
            busy: renameBusy,
            disabled: renameBusy || !renameDraft.trim(),
            label: renameBusy ? 'Renaming' : 'Apply',
            onPress: () => void handleRenameRoom(),
            testID: 'apply-corner-rename',
            variant: 'primary',
          },
        ]}
        dismissOnBackdrop={!renameBusy}
        onRequestClose={() => {
          if (renameBusy) return;
          setRenameEditing(false);
          setRenameError(null);
        }}
        testID="rename-corner-dialog"
        title={`Rename ${CORNER_LABEL}`}
        visible={isCorner && renameEditing}
      >
        <HullDialogInput
          accessibilityLabel={`New ${CORNER_LABEL} name`}
          autoCapitalize="none"
          autoCorrect={false}
          autoFocus
          editable={!renameBusy}
          maxLength={120}
          onChangeText={(value) => {
            setRenameDraft(roomNameEntry(value));
            if (value.trim()) setRenameError(null);
          }}
          onSubmitEditing={() => void handleRenameRoom()}
          returnKeyType="done"
          selectTextOnFocus
          testID="rename-corner-input"
          value={renameDraft}
        />
        {renameError ? (
          <Text accessibilityRole="alert" style={styles.membershipErrorText}>
            {renameError}
          </Text>
        ) : null}
      </HullDialog>

      <MemberPickerSheet
        busy={addingMembers || memberInviteBusy}
        canManage={roomSurface?.viewer.permissions.manage ?? false}
        canConnectAgent
        candidates={participantPickerCandidates}
        error={membershipError}
        kind={participantPickerKind}
        workspacePeerCount={participantPickerWorkspacePeers}
        onAdd={(pubkeys) => void handleAddRoomMembers(pubkeys)}
        onClose={() => setParticipantPickerVisible(false)}
        onConnectAgent={handleConnectAgent}
        onInvitePerson={() => void handleInvitePerson()}
        visible={memberManagement.pickerVisible}
      />
      <MemberPickerSheet
        agentConnectOnly
        busy={agentPairBusy}
        canManage={canManageWorkspace}
        canConnectAgent={!viewerIsAgent}
        candidates={undefined}
        error={agentConnectVisible ? agentPairError : null}
        onAdd={() => undefined}
        onClose={closeAgentConnect}
        onConnectAgent={() => void connectAgent()}
        onCopyPairCommand={(command) => void copyPairCommand(command)}
        onInvitePerson={() => undefined}
        pairCommand={agentPairCommand}
        testID="room-agent-connect-sheet"
        visible={agentConnectVisible}
      />
      <CreatePollSheet
        draftContext={decodedId}
        visible={createPollVisible}
        busy={createPollBusy}
        onClose={() => setCreatePollVisible(false)}
        onCreate={handleCreatePoll}
      />
    </BuzzCommunityShell>
  );
}

const styles = StyleSheet.create((theme) => {
  const groknight = theme.buzz;
  const bottomChrome = roomBottomChromeStyles(groknight);
  return {
    container: {
      flex: 1,
      backgroundColor: groknight.bgTerminal,
    },
    keyboardBody: {
      flex: 1,
    },
    starPrompt: { paddingTop: groknight.space.md },
    agentProfilePane: {
      width: 380,
      maxWidth: '50%',
      borderLeftWidth: StyleSheet.hairlineWidth,
      borderLeftColor: groknight.border,
    },
    desktopConversationFrame: {
      flex: 1,
      minWidth: 0,
      flexDirection: 'row',
      position: 'relative',
    },
    desktopStatusSlot: {
      // The shared thinking line is a 24px row plus the fixed 9px gap.
      // Holding that full box while idle keeps the desktop composer still.
      minHeight: TURN_LINE_BOX_HEIGHT,
      justifyContent: 'center',
    },
    desktopStatusText: {
      ...theme.buzz.type.machine,
      paddingHorizontal: groknight.space.md,
      color: groknight.dim,
    },
    desktopStatusFailed: {
      color: groknight.danger,
    },
    center: {
      alignItems: 'center',
      justifyContent: 'center',
    },
    hydrationErrorHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      minHeight: 60,
      paddingHorizontal: groknight.space.md,
      paddingBottom: 8,
      borderBottomWidth: 1,
      borderBottomColor: groknight.border,
      backgroundColor: groknight.bgBase,
    },
    hydrationErrorBody: {
      flex: 1,
      alignItems: 'flex-start',
      justifyContent: 'center',
      paddingHorizontal: groknight.space.xl,
    },
    errorLabel: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoSemibold,
      color: groknight.accent,
    },
    hydrationErrorText: {
      ...theme.buzz.type.body,
      marginTop: groknight.space.sm,
      color: groknight.textSecondary,
    },
    hydrationErrorRetry: { marginTop: groknight.space.md },
    loadingText: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoSemibold,
      marginTop: groknight.space.sm,
      color: groknight.textMuted,
    },

    // ── Header ──────────────────────────────────────────────────────
    header: {
      zIndex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: groknight.space.md,
      paddingBottom: 8,
      borderBottomWidth: 1,
      borderBottomColor: groknight.border,
      backgroundColor: groknight.bgBase,
    },
    // The leading gutter is 16 (header padding) + 44 + 8, so the title starts
    // on the SAME left axis as a Room-list row's name (16 + 40 tile slot + 12,
    // `channels.tsx`) and pushing a row open never shifts the name sideways.
    backButton: {
      width: 44,
      height: 44,
      marginRight: groknight.space.sm,
      alignItems: 'center',
      justifyContent: 'center',
    },
    backText: { color: groknight.muted },
    cornerBackText: { color: groknight.textMuted },
    // The single agent's faceted mark, stated once for the whole corner — the
    // slot itself is the shared HeaderIdentitySlot primitive.
    headerCenter: {
      flex: 1,
      minHeight: 44,
      minWidth: 0,
      justifyContent: 'center',
    },
    // Stands in for the name until the channel's own read lands, so the header
    // never has to guess between "Room" and a corner slug.
    channelNameSkeleton: {
      width: 132,
      height: 13,
      marginVertical: groknight.space.xs,
      backgroundColor: groknight.bgHover,
      borderRadius: groknight.radius,
    },
    cornerChannelNameSkeleton: { width: 108 },
    // The one thing on the corner's meta row with unbounded length, so it is
    // the one that gives: an unshrinkable name pushed the member count off
    // the right edge.
    cornerHeaderAgent: {
      ...theme.buzz.type.machine,
      fontFamily: groknight.monoSemibold,
      flexShrink: 1,
      minWidth: 0,
      color: groknight.textSecondary,
    },
    cornerHeaderWorking: { color: groknight.ledgerQuiet },
    cornerHeaderReview: { color: groknight.ledgerQuiet },
    cornerHeaderWaiting: { color: groknight.accent },
    cornerHeaderArchived: { color: groknight.ledgerGhost },
    // The title and its metadata keep a clear gap before the trailing action.
    // Corner overflow stays a lone 44pt edge control. The Room's pair does not
    // cluster: the corners door owns a 44pt-tall target of its own and the
    // overflow's box touches it, matching the Room-list pair.
    roomActionsButton: {
      minWidth: 44,
      minHeight: 44,
      marginLeft: groknight.space.sm,
      alignItems: 'center',
      justifyContent: 'center',
    },
    // Captain 2026-09-20: the door is the sigil alone — no word beside it. It
    // still owns a real 44pt target of its own rather than borrowing the
    // menu's.
    roomCornersButton: {
      minWidth: 44,
      minHeight: 44,
      marginLeft: groknight.space.sm,
      alignItems: 'center',
      justifyContent: 'center',
    },
    // Siblings, not a cluster: the same 44pt box as the corners door. The
    // boxes touch, so the 28 marks sit 16pt apart — the same ink gap the
    // Room-list pair already has.
    roomClusteredActionsButton: {
      minWidth: 44,
      minHeight: 44,
      marginLeft: 0,
      alignItems: 'center',
      justifyContent: 'center',
    },
    // Destination marks use the same theme brass as Bookmarks. Overflow stays
    // steel chrome.
    roomCornersGlyph: { color: groknight.accent },
    roomActionsGlyph: { color: groknight.steel },
    archivedBadge: {
      backgroundColor: groknight.bgHighlight,
      borderRadius: groknight.radius,
      marginLeft: groknight.space.sm,
      paddingHorizontal: groknight.space.sm,
      paddingVertical: groknight.space.xs,
    },
    archivedBadgeText: {
      ...theme.buzz.type.machine,
      fontFamily: groknight.monoSemibold,
      color: groknight.textMuted,
    },
    // ── Room / corner actions sheet ──────────────────────────────────
    // The sheet itself, its rows and its trailing vocabulary live in
    // `components/buzz/HullActionSheet.tsx`. What is left here is only what
    // hangs BETWEEN rows: the rename editor and the picker's inset.
    roomRenameEditor: {
      paddingHorizontal: HULL_SHEET_INSET,
      paddingVertical: groknight.space.sm,
      borderTopWidth: StyleSheet.hairlineWidth,
      borderTopColor: groknight.border,
    },
    roomRenameLabel: {
      ...Typography.default(),
      ...theme.buzz.type.meta,
      color: groknight.textMuted,
    },
    roomRenameInput: {
      ...Typography.default('semiBold'),
      ...theme.buzz.type.body,
      minHeight: 44,
      marginTop: groknight.space.xs,
      paddingHorizontal: 0,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: groknight.borderStrong,
      color: groknight.textPrimary,
    },
    roomRenameControls: {
      marginTop: groknight.space.sm,
      flexDirection: 'row',
      justifyContent: 'flex-end',
      gap: groknight.space.sm,
    },
    // The sheet's one box: a notice the reader must act on, held to the same
    // trailing axis as the rows above it (DESIGN.md → Shape).
    membershipError: {
      marginHorizontal: HULL_SHEET_INSET,
      marginTop: groknight.space.sm,
      padding: groknight.space.sm,
      borderWidth: 1,
      borderColor: groknight.borderStrong,
      backgroundColor: groknight.bgHighlight,
    },
    membershipErrorText: {
      ...Typography.default('semiBold'),
      ...theme.buzz.type.meta,
      color: groknight.textSecondary,
    },

    // ── Message blocks ──────────────────────────────────────────────
    transcriptViewport: {
      flex: 1,
      position: 'relative',
    },
    messageList: {
      flex: 1,
    },
    // Desktop transcript only: a plain scrollable View over real DOM (no
    // FlatList/VirtualizedList) — see `shouldFollowDesktopTail` in
    // `buzz/room-scroll-follow.ts`. Mirrors RN Web's own vertical ScrollView
    // overflow (overflowX hidden, overflowY auto).
    desktopScroll: {
      overflowX: 'hidden',
      overflowY: 'auto',
      overflowAnchor: 'none',
    } as any,
    cornerStatusInset: { paddingHorizontal: groknight.space.md },
    messageListContent: {
      paddingHorizontal: groknight.space.md,
      paddingVertical: groknight.space.md,
    },
    messageListContentDesktop: {
      width: '100%',
      maxWidth: 720,
      alignSelf: 'center',
      flexGrow: 1,
      justifyContent: 'flex-end',
    },
    messageListContentEmpty: {
      flexGrow: 1,
    },

    // ── Archived notice ─────────────────────────────────────────────
    archivedBubble: {
      paddingVertical: 8,
      marginBottom: groknight.space.md,
      alignSelf: 'center',
      maxWidth: '90%',
    },
    archivedText: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoRegular,
      color: groknight.ledgerQuiet,
      textAlign: 'center',
    },

    // ── Composer ────────────────────────────────────────────────────
    emptyState: {
      flexGrow: 1,
    },
    // The stack and the composer row are one measured column —
    // `buzz/room-bottom-chrome.ts` owns both. The turn line is an absolute
    // overlay on the stack's top edge, styled inside `TurnBandSlot`; it takes
    // no height in this column.
    desktopReadingColumn: { width: '100%', maxWidth: 720, alignSelf: 'center' },
    bottomChromeStack: bottomChrome.stack,
    inputBar: bottomChrome.composerRow,
    // No longer drawn. The UI component policy fingerprints the header's
    // `insets.top` through this file's last `top:` style, so removing this
    // entry would read as a changed legacy header.
    tagMenuBackdrop: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0 },
    // Under the composer's tag menu: a tap anywhere else closes the menu.
    repoPromptBanner: {
      minWidth: 0,
      marginBottom: groknight.space.sm,
      padding: groknight.space.sm,
      borderLeftWidth: 3,
      borderWidth: 1,
      borderColor: groknight.borderStrong,
      backgroundColor: groknight.bgHighlight,
    },
    repoPromptTitle: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoSemibold,
      color: groknight.textPrimary,
    },
    repoPromptHint: {
      ...theme.buzz.type.meta,
      marginTop: groknight.space.xs,
      color: groknight.textMuted,
    },
    repoPromptConnect: { minHeight: 40, justifyContent: 'center', marginTop: groknight.space.sm },
    repoPromptConnectText: {
      ...theme.buzz.type.meta,
      fontFamily: groknight.proseSemibold,
      color: groknight.accent,
    },
    repoPromptDismiss: { alignSelf: 'flex-end', minHeight: 32, justifyContent: 'center' },
    repoPromptDismissText: {
      ...theme.buzz.type.machine,
      color: groknight.textSecondary,
    },
    archivedInputBar: {
      paddingHorizontal: 16,
      paddingTop: groknight.space.md,
      paddingBottom: 8,
      borderTopWidth: 1,
      borderTopColor: groknight.border,
      backgroundColor: groknight.bgBase,
      alignItems: 'center',
    },
    archivedInputText: {
      ...theme.buzz.type.meta,
      color: groknight.muted,
    },
    cornerArchivedInputText: { ...Typography.mono('italic'), color: groknight.textMuted },
  outboxFailure: {
      marginTop: 4,
      marginHorizontal: 8,
      padding: 8,
      borderWidth: 1,
      borderColor: groknight.borderStrong,
      backgroundColor: groknight.bgHighlight,
    },
outboxFailureText: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoSemibold,
      color: groknight.textPrimary,
    },
outboxFailureActions: {
      flexDirection: 'row',
      gap: 8,
      marginTop: groknight.space.sm,
    },
replySwipeAction: {
      width: 78,
      marginBottom: 8,
      alignItems: 'center',
      justifyContent: 'center',
      borderLeftWidth: 1,
      borderLeftColor: groknight.borderStrong,
      backgroundColor: groknight.bgHighlight,
    },
replySwipeGlyph: {
      ...theme.buzz.type.body,
      fontFamily: groknight.proseSemibold,
      color: groknight.textPrimary,
    },
replySwipeLabel: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoSemibold,
      marginTop: groknight.space.xs,
      color: groknight.textMuted,
    },
replyReference: {
      minWidth: 0,
      marginBottom: groknight.space.xs,
    },
replyReferenceText: {
      ...theme.buzz.type.machine,
      color: groknight.ledgerGhost,
    },
attachmentCard: {
      minWidth: 0,
      width: '100%',
      minHeight: 58,
      marginTop: 8,
      paddingVertical: groknight.space.sm,
      flexDirection: 'row',
      alignItems: 'center',
      gap: groknight.space.sm,
    },
attachmentThumbnail: {
      width: 46,
      height: 46,
      backgroundColor: groknight.bgHighlight,
    },
attachmentFileGlyph: {
      width: 46,
      height: 46,
      alignItems: 'center',
      justifyContent: 'center',
    },
attachmentFileGlyphText: {
      ...theme.buzz.type.hero,
      color: groknight.steel,
    },
attachmentCopy: { flex: 1, minWidth: 0 },
attachmentName: {
      ...theme.buzz.type.body,
      fontSize: groknight.transcriptCard.rowTitleSize,
      color: groknight.textPrimary,
    },
attachmentMeta: {
      ...theme.buzz.type.machine,
      fontSize: groknight.transcriptCard.rowKindSize,
      marginTop: groknight.space.xs,
      color: groknight.textMuted,
    },
attachmentOpenGlyph: {
      ...theme.buzz.type.body,
      width: 22,
      color: groknight.steel,
      textAlign: 'center',
    },
activityGroup: {
      width: '100%',
      minWidth: 0,
      marginBottom: groknight.space.md,
    },
previewLinkRow: {
      marginTop: groknight.space.sm,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      minWidth: 0,
    },
previewLinkLabel: {
      ...theme.buzz.type.machine,
      fontFamily: groknight.monoSemibold,
      color: groknight.textPrimary,
      flexShrink: 0,
    },
previewLinkUrl: {
      ...theme.buzz.type.machine,
      color: groknight.textMuted,
      flexShrink: 1,
      minWidth: 0,
    },
targetBranchCard: {
      minWidth: 0,
      marginBottom: 8,
      paddingHorizontal: groknight.space.md,
      paddingVertical: groknight.space.md,
      borderWidth: 1,
      borderColor: groknight.borderStrong,
      gap: 8,
    },
targetBranchTitle: {
      ...theme.buzz.type.bodyStrong,
      color: groknight.textPrimary,
    },
targetBranchChange: {
      ...theme.buzz.type.machine,
      fontFamily: groknight.monoSemibold,
      color: groknight.textPrimary,
    },
targetBranchBoundary: {
      ...theme.buzz.type.meta,
      color: groknight.textSecondary,
    },
targetBranchActions: { flexDirection: 'row', gap: 8 },
targetBranchButton: { flex: 1, minWidth: 0 },
targetBranchStatus: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoSemibold,
      color: groknight.textSecondary,
    },
writePermissionCard: {
      minWidth: 0,
      marginBottom: 8,
      paddingHorizontal: groknight.space.md,
      paddingVertical: groknight.space.md,
      borderWidth: 1,
      borderColor: groknight.borderStrong,
      gap: groknight.space.sm,
    },
githubEventPressable: { marginBottom: 8 },
githubEventCard: {
      minWidth: 0,
      paddingHorizontal: groknight.space.md,
      paddingVertical: groknight.space.md,
      borderWidth: 1,
      borderColor: groknight.borderStrong,
      gap: groknight.space.sm,
    },
githubEventTitle: {
      ...theme.buzz.type.bodyStrong,
      color: groknight.textPrimary,
    },
githubEventLink: {
      ...theme.buzz.type.machine,
      fontFamily: groknight.monoSemibold,
      color: groknight.textSecondary,
    },
writePermissionHeading: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: groknight.space.sm,
    },
writePermissionCopy: { flex: 1, minWidth: 0 },
writePermissionTitle: {
      ...theme.buzz.type.bodyStrong,
      color: groknight.textPrimary,
    },
writePermissionIntent: {
      ...theme.buzz.type.meta,
      color: groknight.textMuted,
      marginTop: groknight.space.xs,
    },
writePermissionRepository: {
      ...theme.buzz.type.machine,
      fontFamily: groknight.monoSemibold,
      color: groknight.textPrimary,
    },
writePermissionBoundary: {
      ...theme.buzz.type.meta,
      color: groknight.textSecondary,
    },
writePermissionFailure: {
      ...theme.buzz.type.machine,
      color: groknight.textSecondary,
    },
writePermissionActions: { flexDirection: 'row', gap: 8 },
writePermissionButton: { flex: 1, minWidth: 0 },
writePermissionStatus: {
      ...theme.buzz.type.sectionHead,
      fontFamily: groknight.monoSemibold,
      color: groknight.textSecondary,
    },
};
});
