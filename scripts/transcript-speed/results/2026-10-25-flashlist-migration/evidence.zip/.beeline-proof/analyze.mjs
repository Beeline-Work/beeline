import { readFileSync, writeFileSync } from 'node:fs';
import { percentile } from '../scripts/transcript-speed/metrics.mjs';
const variant = process.argv[2] ?? 'candidate';
const read = path => JSON.parse(readFileSync(path, 'utf8'));
const range = values => ({ median: percentile(values,.5), min:Math.min(...values), max:Math.max(...values), values });
const result = {};
const captures = ['main',variant].flatMap(engine=>[1,2,3].map(block=>
  read(`.beeline-proof/${block===1 && engine==='candidate'?'preflight-candidate':`block-${block}-${engine}`}/capture.json`)));
const common = [...new Set(captures[0].samples.map(x=>x.scenario))].filter(s=>captures.every(c=>c.samples.some(x=>x.scenario===s)));
for (const engine of ['main', variant]) {
  const blocks = [1,2,3].map(block => ({
    capture:read(`.beeline-proof/${block===1 && engine==='candidate'?'preflight-candidate':`block-${block}-${engine}`}/capture.json`),
    opens:read(`.beeline-proof/block-${block}-${engine}-opens/capture.json`),
  }));
  const scenarios = {};
  for (const scenario of common) {
    const perBlock = blocks.map(b=> {
      const rows=b.capture.samples.filter(x=>x.scenario===scenario);
      const count=rows.reduce((s,x)=>s+x.uiFrames.count,0);
      const janky=rows.reduce((s,x)=>s+x.uiFrames.jankyFrames,0);
      return {p95:percentile(rows.flatMap(x=>x.raw.jsFrameIntervalsMs),.95),count,janky,rate:count?100*janky/count:0};
    });
    scenarios[scenario]={p95:range(perBlock.map(x=>x.p95)),jankPercent:range(perBlock.map(x=>x.rate)),perBlock};
  }
  result[engine]={warm:range(blocks.flatMap(b=>b.opens.samples.map(x=>x.firstFrameMarkerMs))),
    settlingAvailable:blocks.flatMap(b=>b.opens.samples).every(x=>x.settledMs!==null),
    overallP95:range(blocks.map(b=>percentile(b.capture.samples.filter(x=>common.includes(x.scenario)).flatMap(x=>x.raw.jsFrameIntervalsMs),.95))),scenarios};
}
result.definiteRegressions=Object.keys(result.main.scenarios).filter(name=>
  result[variant].scenarios[name].p95.min>result.main.scenarios[name].p95.max ||
  result[variant].scenarios[name].jankPercent.min>result.main.scenarios[name].jankPercent.max);
writeFileSync(`.beeline-proof/analysis-${variant}.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify({main:result.main.warm,candidate:result[variant].warm,mainP95:result.main.overallP95,candidateP95:result[variant].overallP95,definiteRegressions:result.definiteRegressions},null,2));
