import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, openSync, closeSync } from 'node:fs';
const env = { ...process.env,
  LATENCY_RIG_DATABASE_URL: 'postgresql://localhost/beeline_latency_rig_transcript_flashmigration?host=%2Fvar%2Frun%2Fpostgresql',
  LATENCY_RIG_DEVICE: 'emulator-5562', TRANSCRIPT_REPEAT_COUNT: '1',
};
const outcomes = JSON.parse(readFileSync('.beeline-proof/paired-outcomes.json','utf8'));
function run(cmd, args, log, extra = {}, preserveFailure = false) {
  const fd = openSync(log, 'w');
  const result = spawnSync(cmd, args, { env: { ...env, ...extra }, stdio: ['ignore', fd, fd] });
  closeSync(fd);
  if (result.status !== 0 && !preserveFailure) throw new Error(`${cmd} failed (${result.status}): ${log}`);
  return result.status;
}
for (const [block, engine] of [[2,'main'], [3,'candidate'], [3,'main']]) {
  const stem = `.beeline-proof/block-${block}-${engine}`;
  const artifact = `.beeline-proof/${engine}.apk`;
  console.log('Starting', stem);
  let scenarioExit = block===2 && engine==='main'?1:0;
  if (!(block === 2 && engine === 'main')) {
    run('node', ['scripts/transcript-speed/reset.mjs'], `${stem}-reset.log`);
    run('adb', ['-s', env.LATENCY_RIG_DEVICE, 'install', '-r', artifact], `${stem}-install.log`);
    scenarioExit=run('node', ['scripts/transcript-speed/capture-android.mjs', stem], `${stem}-scenarios.log`, { TRANSCRIPT_APK: artifact },engine==='main');
  }
  run('node', ['.beeline-proof/capture-warm.mjs', `${stem}-opens`], `${stem}-opens.log`, { TRANSCRIPT_APK: artifact });
  outcomes.push({ block, engine, completed: new Date().toISOString(), scenarioExit, scenarios: stem });
  writeFileSync('.beeline-proof/paired-outcomes.json', JSON.stringify(outcomes, null, 2));
  console.log('Completed', stem);
}
