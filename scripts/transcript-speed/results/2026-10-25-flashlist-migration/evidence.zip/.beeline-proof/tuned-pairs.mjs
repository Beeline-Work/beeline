import { spawnSync } from 'node:child_process';
import { writeFileSync, openSync, closeSync } from 'node:fs';
const env = { ...process.env,
  LATENCY_RIG_DATABASE_URL:'postgresql://localhost/beeline_latency_rig_transcript_flashmigration?host=%2Fvar%2Frun%2Fpostgresql',
  LATENCY_RIG_DEVICE:'emulator-5562',TRANSCRIPT_REPEAT_COUNT:'1',TRANSCRIPT_REGRESSION_ONLY:'1',
};
const outcomes=[];
function run(cmd,args,log,extra={}) {
  const fd=openSync(log,'w');
  const result=spawnSync(cmd,args,{env:{...env,...extra},stdio:['ignore',fd,fd]});closeSync(fd);
  if(result.status!==0) throw new Error(`${cmd} failed (${result.status}): ${log}`);
}
for(const block of [1,2,3]) for(const engine of ['main','tuned']) {
  const stem=`.beeline-proof/focused-${block}-${engine}`,artifact=`.beeline-proof/${engine}.apk`;
  console.log('Starting',stem);
  run('node',['scripts/transcript-speed/reset.mjs'],`${stem}-reset.log`);
  run('adb',['-s',env.LATENCY_RIG_DEVICE,'install','-r',artifact],`${stem}-install.log`);
  run('node',['.beeline-proof/focused.mjs',stem],`${stem}.log`,{TRANSCRIPT_APK:artifact});
  outcomes.push({block,engine,completed:new Date().toISOString()});
  writeFileSync('.beeline-proof/focused-outcomes.json',JSON.stringify(outcomes,null,2));
  console.log('Completed',stem);
}
