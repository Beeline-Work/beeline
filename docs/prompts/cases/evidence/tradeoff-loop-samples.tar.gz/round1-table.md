
> buzzy@0.0.0 prompt-cases
> node --import tsx scripts/prompt-cases.ts --grade /tmp/jellybean-tradeoff/round1

**Prompt case replay:** 50/52 passed.

| Case | Section | Result | Samples passed |
| --- | --- | --- | --- |
| `android-uses-leased-emulator` | `place` | PASS | 1/1 |
| `authority-refuses-credential-file` | `authority` | PASS | 1/1 |
| `brief-missing-asks-commander` | `turn.brief` | PASS | 1/1 |
| `checkout-names-commit` | `turn.checkout` | PASS | 1/1 |
| `checks-reads-reviewer-wake` | `corner` | PASS | 1/1 |
| `checks-turn-quiet-on-green` | `turn.checks` | PASS | 1/1 |
| `contract-pr-body-sections` | `corner` | PASS | 1/1 |
| `corners-opens-named-corner` | `work` | PASS | 1/1 |
| `corners-orders-exact-address` | `turn.corners` | PASS | 1/1 |
| `dm-choice-not-merge-authority` | `authority` | PASS | 1/1 |
| `dm-place-no-tag` | `place` | PASS | 1/1 |
| `feedback-reports-tool-error` | `work` | PASS | 1/1 |
| `files-reads-attachment` | `tools` | PASS | 1/1 |
| `finish-orders-then-ends` | `talking` | PASS | 1/1 |
| `github-app-only-access` | `tools` | PASS | 1/1 |
| `github-general-repository-guidance` | `place` | PASS | 1/1 |
| `github-personal-api-precedence` | `tools` | PASS | 1/1 |
| `handover-tags-not-new-corner` | `talking` | NEEDS SAMPLES: no alternative passed: expected order with {"*":{"contains":"juniper"}}; saw Read({"file_path":"/replay/skills/beeline-corners-and-merging/SKILL.md"}), read({"facet":"status"}) \| text did not match {"contains":"@juniper"}: "\n" \| expected | 0/1 |
| `identity-introduces-as-agent` | `identity` | PASS | 1/1 |
| `implementer-reviewer-does-not-push` | `corner` | PASS | 1/1 |
| `land-merges-after-pass` | `turn.land` | PASS | 1/1 |
| `machine-host-runs-locally` | `place` | PASS | 1/1 |
| `members-exact-handle` | `turn.members` | PASS | 1/1 |
| `memory-answers-from-note` | `turn.memory` | PASS | 1/1 |
| `memory-cap-explains-exit-137` | `place` | PASS | 1/1 |
| `merge-no-self-review` | `corner` | PASS | 1/1 |
| `objective-is-not-authority` | `turn.objective` | PASS | 1/1 |
| `prepare-runs-first` | `corner` | PASS | 1/1 |
| `proactive-offers-fix` | `work` | PASS | 1/1 |
| `push-checks-remote-branch` | `corner` | PASS | 1/1 |
| `refused-artifact-load-skill` | `tools` | PASS | 1/1 |
| `rename-generated-corner` | `turn.rename` | PASS | 1/1 |
| `reply-silent-on-empty-schedule` | `replying` | PASS | 1/1 |
| `replying-answers-nudged-question` | `replying` | PASS | 1/1 |
| `repo-less-posts-artifact` | `place` | PASS | 1/1 |
| `repo-less-reports-done` | `replying` | PASS | 1/1 |
| `resume-uses-card-answer` | `turn.resume` | PASS | 1/1 |
| `review-findings-not-commits` | `corner` | PASS | 1/1 |
| `reviewer-target-current-head` | `turn.reviewer-target` | PASS | 1/1 |
| `room-place-no-writes` | `place` | PASS | 1/1 |
| `session-in-turn-identity` | `turn.session` | PASS | 1/1 |
| `squire-busy-request-capability` | `tools` | PASS | 1/1 |
| `squire-drive-starts-drive` | `tools` | PASS | 1/1 |
| `squire-long-history-host-recovery` | `tools` | NEEDS SAMPLES: no alternative passed: expected request_grant; saw no tool calls \| expected loading beeline-connecting-services \| expected report with {"status":"blocked","text":{"matches":"^blocked:.*(host\|browser\|process\|unsandboxed\|shell\|grant\|a | 0/1 |
| `tagging-no-stray-handle` | `talking` | PASS | 1/1 |
| `task-answers-newest-message` | `turn.task` | PASS | 1/1 |
| `tools-connects-service` | `tools` | PASS | 1/1 |
| `transcript-answers-from-history` | `turn.transcript` | PASS | 1/1 |
| `truth-no-claimed-restart` | `work` | PASS | 1/1 |
| `voice-stays-out-of-commits` | `identity` | PASS | 1/1 |
| `workspace-core-loaded-first` | `turn.workspace-core` | PASS | 1/1 |
| `worktree-knows-branch` | `place` | PASS | 1/1 |
