import {spawnSync} from 'node:child_process';
const fixed='apps/mobile/android/app/build/outputs/apk/release/app-release.apk';
for(const args of [
 ['fixed4-warm',fixed,'warm'],
 ['fixed4-suite',fixed,'suite'],
 ['fixed4-transition',fixed,'transitions'],
]){
 const r=spawnSync(process.execPath,['.beeline-proof/capture-arm.mjs',...args],{stdio:'inherit'});
 if(r.status!==0)process.exit(r.status??1);
}
const env={...process.env,ANDROID_ADB_SERVER_PORT:'5766',LATENCY_RIG_DEVICE:'127.0.0.1:5555',
 LATENCY_RIG_DATABASE_URL:'postgresql://localhost/beeline_latency_rig_transcript_streamclip?host=%2Fvar%2Frun%2Fpostgresql',
 TRANSCRIPT_APK:fixed,TRANSCRIPT_CONTROL_PORT:'23886'};
const r=spawnSync(process.execPath,['scripts/transcript-speed/capture-row-updates.mjs','.beeline-proof/row-updates-final'],{stdio:'inherit',env});
process.exit(r.status??1);
