
> buzzy@0.0.0 prompt-cases
> node --import tsx scripts/prompt-cases.ts --grade /tmp/jellybean-tradeoff-v2/round8-skill/without --memory without

**Prompt case replay:** 10/12 passed.

| Case | Section | Result | Samples passed |
| --- | --- | --- | --- |
| `memory-rule-01` | `turn.memory` | PASS | 3/3 |
| `memory-rule-02` | `turn.memory` | PASS | 3/3 |
| `memory-rule-03` | `turn.memory` | PASS | 3/3 |
| `memory-rule-04` | `turn.memory` | PASS | 3/3 |
| `memory-rule-05` | `turn.memory` | PASS | 3/3 |
| `memory-rule-06` | `turn.memory` | PASS | 3/3 |
| `memory-rule-07` | `turn.memory` | PASS | 3/3 |
| `memory-rule-08` | `turn.memory` | FAIL: text did not match {"not":{"matches":"(?<!\\()(?:(?:PR\|pull request)\\s*)?#73\|(?<!\\()(?:PR\|pull request)\\s+73","flags":"i"}}: "Here's what shipped, based on your description: pull request 73, which makes expired tokens get a 401 respon | 0/3 |
| `memory-rule-09` | `turn.memory` | PASS | 2/3 |
| `memory-rule-10` | `turn.memory` | FAIL: text did not match {"matches":"revert\|remov\|roll.back","flags":"i"}: "@opal You're right that both of my search fixes merged before this crash, so I'm treating them as the likely cause. PR 61 (query normalization) runs on every keystroke, | 1/3 |
| `memory-rule-11` | `turn.memory` | PASS | 3/3 |
| `memory-rule-12` | `turn.memory` | PASS | 3/3 |
