import {spawnSync} from 'node:child_process';
import {openSync,closeSync,mkdirSync} from 'node:fs';
const [arm,apk,mode='suite']=process.argv.slice(2);
if(!arm||!apk)throw Error('arm and APK required');
const device='127.0.0.1:5555';
const env={...process.env,ANDROID_ADB_SERVER_PORT:'5766',LATENCY_RIG_DEVICE:device,
 LATENCY_RIG_DATABASE_URL:'postgresql://localhost/beeline_latency_rig_transcript_streamclip?host=%2Fvar%2Frun%2Fpostgresql',
 TRANSCRIPT_APK:apk,TRANSCRIPT_CONTROL_PORT:'23886',TRANSCRIPT_REPEAT_COUNT:'3',
 TRANSCRIPT_EXPERIMENT_KEEP_FAILURES:'1',STREAM_COLD:'1'};
const out=`.beeline-proof/${arm}`;
if(mode==='warm') { env.TRANSCRIPT_STREAM_COLD='0'; env.TRANSCRIPT_EXPERIMENT_KEEP_FAILURES='0'; }
if(arm.startsWith('fixed')) env.TRANSCRIPT_EXPERIMENT_KEEP_FAILURES='0';
mkdirSync(out,{recursive:true});
function run(cmd,args,log){
 const fd=openSync(`${out}/${log}`,'w');
 const r=spawnSync(cmd,args,{env,stdio:['ignore',fd,fd]}); closeSync(fd);
 if(r.status!==0)throw Error(`${cmd} failed (${r.status}), see ${out}/${log}`);
}
run('node',['scripts/transcript-speed/reset.mjs'],'reset.log');
const install=spawnSync('adb',['-s',device,'install','-r',apk],{env,encoding:'utf8'});
if(install.status!==0){
 if(!`${install.stdout}${install.stderr}`.includes('INSTALL_FAILED_UPDATE_INCOMPATIBLE'))throw Error(install.stderr);
 run('adb',['-s',device,'uninstall','app.usebeeline'],'uninstall.log');
 run('adb',['-s',device,'install',apk],'install.log');
}
run('adb',['-s',device,'shell','pm','clear','app.usebeeline'],'clear.log');
run('adb',['-s',device,'shell','pm','grant','app.usebeeline','android.permission.POST_NOTIFICATIONS'],'grant.log');
run('adb',['-s',device,'reverse','tcp:19882','tcp:19882'],'reverse.log');
run('adb',['-s',device,'shell','am','start','-a','android.intent.action.VIEW','-d','beeline://review/transcript-fixture-local-only-36bbb7b4','app.usebeeline/.MainActivity'],'signin.log');
await new Promise(r=>setTimeout(r,6000));
if(mode==='streams')run('node',['.beeline-proof/streams.mjs',`${out}/streams`],'streams.log');
else if(mode==='warm')run('node',['scripts/transcript-speed/capture-concurrent-streams.mjs',`${out}/streams`],'streams.log');
else if(mode==='transitions')run('node',['scripts/transcript-speed/capture-room-transitions.mjs',`${out}/transitions`],'transitions.log');
else if(mode==='switches')run('node',['.beeline-proof/room-switches.mjs',`${out}/switches`],'switches.log');
else if(mode==='diagnostic')run('node',['.beeline-proof/diagnostic-capture.mjs',`${out}/scenarios`],'scenarios.log');
else run('node',['scripts/transcript-speed/capture-android.mjs',`${out}/scenarios`],'scenarios.log');
console.log(`${arm} ${mode} completed`);
