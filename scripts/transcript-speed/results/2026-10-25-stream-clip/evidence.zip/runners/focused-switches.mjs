import {execFileSync} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
import {startControl} from '../scripts/transcript-speed/control.mjs';
import {androidArtifact} from '../scripts/transcript-speed/android-artifact.mjs';
import {fixtureStimulus} from '../scripts/transcript-speed/stimulus.mjs';
import {rooms,workspace,fixtureFingerprint} from '../scripts/transcript-speed/fixture.mjs';
import {summarize} from '../scripts/transcript-speed/metrics.mjs';
const device=process.env.LATENCY_RIG_DEVICE,output=process.argv[2];
const adb=(...args)=>execFileSync('adb',['-s',device,...args],{encoding:'utf8',maxBuffer:32000000});
if(adb('shell','getprop','ro.kernel.qemu').trim()!=='1')throw Error('Owned emulator required');
await mkdir(output,{recursive:true});
const artifact=androidArtifact(adb),control=startControl(),stimulus=await fixtureStimulus();
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const open=room=>adb('shell','am','start','-W','-a','android.intent.action.VIEW','-d',`beeline://beeline/chat/${room}?communityId=${workspace}`,'app.usebeeline/.MainActivity');
const samples=[];
try{
 for(const room of [rooms[0],rooms[1],rooms[0]]){open(room);await pause(2000);}
 await control.ready();
 for(let trial=0;trial<3;trial++){
  adb('shell','dumpsys','gfxinfo','app.usebeeline','reset');
  const raw=await control.capture('warm-room-switches',30000,async()=>{
   for(let i=0;i<20;i++){open(rooms[i%2]);await pause(900);}
  });
  const gfx=adb('shell','dumpsys','gfxinfo','app.usebeeline','framestats');
  const sample={...summarize(raw,60),raw,gfx};samples.push(sample);
  await writeFile(`${output}/capture.json`,JSON.stringify({completed:trial===2,...artifact,fixtureFingerprint,samples},null,2));
  console.log(trial,sample.jsFrameIntervalP95Ms,sample.jsFrameIntervalMaxMs,sample.rowCommits);
 }
}finally{control.close();await stimulus.close();}
