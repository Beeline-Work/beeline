# Long-context case admission

Five redacted adaptations use invented people, items, session IDs and dialogue. They retain the failure mechanisms recorded in the existing incident-driven prompt rules and proof documents; they are not quotations of private transcripts.

| Candidate | Incident source | Main admission samples | Admission |
| --- | --- | --- | --- |
| Exhausted browser recovery | Original browser ownership / sandbox incident specified in the brief | 3/3 | Excluded |
| Progress reminder after a long turn | `docs/claude-silent-wake-proof.md`, native reminder reproduction; memory rule 05 | 3/3 | Excluded |
| Unsupported sign-in handback | `surface.squire-drive` incident rationale in `prompt-assembly.ts` | 3/3 | Excluded |
| Blaming a change before checking existing fixes | Memory rules 07 and 10 and their recorded replay evidence | 3/3 | Excluded |
| Shipped status reduced to request numbers | Memory rule 08 and its recorded paired replay evidence | 0/3 | Kept |

Admission uses exactly three main samples per candidate. The subsequent whole-suite baseline uses fresh samples, so the admission responses are not reused to inflate the baseline comparison. A predicate initially mistook a sentence denying that an animation shipped for a positive claim; the predicate now matches a positive shipped-animation claim. Both baseline and candidates are graded with that same repaired predicate. No prompts or samples were changed by that matcher repair.

The suite is the existing 52 cases plus all 12 cases and harness changes cherry-picked from PR #2645, plus the one admitted long-context case. All 65 cases are run with their supplied context. The 12 memory-rule cases also run without their note: 77 scored scenarios, three samples each. This extra slice prevents a remembered copy of candidate A from masking the value of adding it to the always-loaded prompt. The 65-case default slice and 12-case no-note slice are also reported separately.

Main prompt source is 9be1ae2b17609b5b3bf91ebe50371f2ff0e5792b. The previous eight-word cut was reset before testing. A, B and C are separate single-addition comparisons against that main prompt, not a batch. Main and each candidate use the same controller and model parameters. Every raw response is saved before parsing and contains the CLI model metadata. Invalid JSON, timeout or tool-call formatting remains a failed sample, without replacement.

Additional fixture corrections apply identically to all comparisons:

- Memory rule 03's positive acknowledgment matcher accepts “merge” as well as “merged”; its owner-tag prohibitions are unchanged. A reply about the merge outcome was not a DM-tag violation.
- Memory rule 07 accepts either one all-state pull-request query or both open/merged queries before opening work. It still rejects checking after the corner opens.
- Memory rule 09 now supplies its dispatching message ID and Room address, so the scope test does not demand inventing a missing approval ID. Its three with-note and three without-note samples were rerun for main and A; original-context responses are retained separately. B and later candidates use the fixed context from their first sample.

These repairs are not credited as prompt improvements. All other case criteria are unchanged.

## Model identity audit

The native CLI's `--model` flag and a matching `--fallback-model` flag did not disable its separate automatic model switch on flagged sessions. CLI metadata revealed Opus 4.8 responses in 18 attempted samples. These attempts were excluded based solely on model identity, before rescoring, and preserved in `off-model/`. They were replaced using the CLI's session-only `switchModelsOnFlag:false` setting and an explicit same-model fallback. This keeps the requested model's own refusal instead of switching to a different model. Refusals, invalid JSON and tool-call formatting errors on Opus 5.5 remain failed samples, with no replacement. Every scored raw envelope is audited for model identity; the audit found no off-model response in the scored directories after replacement. The original narrow-suite rounds lacked this per-sample metadata audit and are historical, not evidence for the final keep.

After the audit, expanded main scores71/77 (209/231 samples). A-only71/77 (210/231) and C-only71/77 (210/231) are dropped as one-sample-only gains; B-only69/77 (208/231) is dropped. The reporting-propagation addition scores72/77 (214/231), including both previously failing memory06 slices now passing, for17 always-loaded words. It is provisionally kept. The next experiment moves the same reporting mechanic into the existing brief-writing skill, where dispatch already loads it, to remove that always-loaded cost.

## Word-count context correction

The initial word counter's code-corner fixture had no brief, so it measured an unassigned corner's runtime instructions (721 words on main). The final counter supplies an explicit repository-work brief and configured reviewer, so it measures the repository author's always-loaded rules (1061 words on main). The same context is used to recalculate every round; global sentence deltas are unchanged. Room789, DM599 and repository-free642 are unchanged. This is a measurement correction, not a prompt improvement.

## Rule 08 offline regrade

The parenthesis matcher was repaired after independent review blocked scoring. All 48 rule 08 samples were regraded; only round4-A with/without sample grades change (2/3 to 3/3 each). Standalone A now scores 71/77 and 212/231; the earlier paragraph above records the pre-repair result. Main and selected round nine remain 71/77, 209/231 and 75/77, 220/231. Selection unchanged; no model calls or raw replies changed. Current scores/tables and case-library use the new matcher. Previous scores and both matcher definitions are retained.
