
> buzzy@0.0.0 prompt-cases
> node --import tsx scripts/prompt-cases.ts --grade /tmp/jellybean-tradeoff-v2/round9-A-skill/without --memory without

**Prompt case replay:** 11/12 passed.

| Case | Section | Result | Samples passed |
| --- | --- | --- | --- |
| `memory-rule-01` | `turn.memory` | PASS | 3/3 |
| `memory-rule-02` | `turn.memory` | PASS | 3/3 |
| `memory-rule-03` | `turn.memory` | PASS | 3/3 |
| `memory-rule-04` | `turn.memory` | PASS | 3/3 |
| `memory-rule-05` | `turn.memory` | PASS | 3/3 |
| `memory-rule-06` | `turn.memory` | PASS | 3/3 |
| `memory-rule-07` | `turn.memory` | PASS | 3/3 |
| `memory-rule-08` | `turn.memory` | PASS | 3/3 |
| `memory-rule-09` | `turn.memory` | PASS | 3/3 |
| `memory-rule-10` | `turn.memory` | FAIL: text did not match {"matches":"query normalization","flags":"i"}: "@opal Sorry about that. My two search changes are the prime suspects: one cleans up the query before searching (PR 61) and one handles searches with no results (PR 66). Both | 0/3 |
| `memory-rule-11` | `turn.memory` | PASS | 3/3 |
| `memory-rule-12` | `turn.memory` | PASS | 3/3 |
