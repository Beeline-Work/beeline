import {execFileSync} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
import {fixtureStimulus} from '../scripts/transcript-speed/stimulus.mjs';
import {corner,workspace,fixtureFingerprint} from '../scripts/transcript-speed/fixture.mjs';
import {androidArtifact} from '../scripts/transcript-speed/android-artifact.mjs';
const device=process.env.LATENCY_RIG_DEVICE??'emulator-5554';
const adb=(...args)=>execFileSync('adb',['-P','5766','-s',device,...args],{encoding:'utf8',maxBuffer:32000000});
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const output=process.argv[2]??'.beeline-proof/main-streams';
await mkdir(output,{recursive:true});
const artifact=androidArtifact(adb);
const stimulus=await fixtureStimulus();
const trials=[];
try {
 for(let trial=0;trial<10;trial++){
  if(process.env.STREAM_COLD==='1') adb('shell','am','force-stop','app.usebeeline');
  adb('shell','am','start','-W','-a','android.intent.action.VIEW','-d',`beeline://beeline/chat/${corner}?communityId=${workspace}`,'app.usebeeline/.MainActivity');
  await pause(2500);
  await stimulus.stream(async()=>{
   const screenshot=`${output}/stream-${trial}.png`;
   await writeFile(screenshot,execFileSync('adb',['-P','5766','-s',device,'exec-out','screencap','-p']));
   const ocr=execFileSync('tesseract',[screenshot,'stdout'],{encoding:'utf8'});
   await writeFile(`${output}/stream-${trial}.txt`,ocr);
   const both=/Stream [0O]:/.test(ocr)&&/Stream 1:/.test(ocr);
   trials.push({trial,both,at:new Date().toISOString(),screenshot});
   console.log(JSON.stringify(trials.at(-1)));
  });
  await writeFile(`${output}/results.json`,JSON.stringify({reproduction:'STREAM-CLIP-1',cold:process.env.STREAM_COLD==='1',fixtureFingerprint,...artifact,trials},null,2));
  await pause(1000);
 }
}finally{await stimulus.close();}
