**Prompt case replay:** 11/12 passed.

| Case | Section | Result | Samples passed |
| --- | --- | --- | --- |
| `memory-rule-01` | `turn.memory` | PASS | 3/3 |
| `memory-rule-02` | `turn.memory` | PASS | 3/3 |
| `memory-rule-03` | `turn.memory` | PASS | 3/3 |
| `memory-rule-04` | `turn.memory` | PASS | 3/3 |
| `memory-rule-05` | `turn.memory` | PASS | 3/3 |
| `memory-rule-06` | `turn.memory` | PASS | 3/3 |
| `memory-rule-07` | `turn.memory` | PASS | 3/3 |
| `memory-rule-08` | `turn.memory` | FAIL: text did not match {"not":{"matches":"(?<![\\w#])(?:(?:PR\|pull request)\\s*#?\\s*\|#)?73\\b(?![^()]*\\))","flags":"i"}}: "Here is what you've told me about pull request 73: after it merged, requests with expired tokens get a 401 response.  | 0/3 |
| `memory-rule-09` | `turn.memory` | PASS | 3/3 |
| `memory-rule-10` | `turn.memory` | PASS | 3/3 |
| `memory-rule-11` | `turn.memory` | PASS | 3/3 |
| `memory-rule-12` | `turn.memory` | PASS | 3/3 |
