
> buzzy@0.0.0 prompt-cases
> node --import tsx scripts/prompt-cases.ts --grade /tmp/jellybean-tradeoff-v2/round4-A/without --memory without

**Prompt case replay:** 10/12 passed.

| Case | Section | Result | Samples passed |
| --- | --- | --- | --- |
| `memory-rule-01` | `turn.memory` | PASS | 3/3 |
| `memory-rule-02` | `turn.memory` | PASS | 3/3 |
| `memory-rule-03` | `turn.memory` | PASS | 3/3 |
| `memory-rule-04` | `turn.memory` | PASS | 3/3 |
| `memory-rule-05` | `turn.memory` | PASS | 3/3 |
| `memory-rule-06` | `turn.memory` | FAIL: expected open_corner with {"brief.spec":{"matches":"(?:no\|never\|only\|do not).{0,100}progress\|progress.{0,100}(?:stay\|only\|never\|not)","flags":"i"},"implementer":{"matches":"^@?fern$"}}; saw Read({"file_path":"/replay/skills/beeline-t | 0/3 |
| `memory-rule-07` | `turn.memory` | PASS | 3/3 |
| `memory-rule-08` | `turn.memory` | PASS | 2/3 |
| `memory-rule-09` | `turn.memory` | PASS | 2/3 |
| `memory-rule-10` | `turn.memory` | FAIL: text did not match {"matches":"query normalization","flags":"i"}: "\n\n@opal Sorry about this. Two of my changes landed shortly before the crash, so they're the likely cause: how search cleans up what you type (PR 61), and what search shows | 0/3 |
| `memory-rule-11` | `turn.memory` | PASS | 3/3 |
| `memory-rule-12` | `turn.memory` | PASS | 3/3 |
